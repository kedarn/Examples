package upi.client;

public interface UpiUriService {

	String URI = "/urn:txnid:";
	
	String DELIMETER = "/";
	
	String getUpiServerUrl(String key);
}
