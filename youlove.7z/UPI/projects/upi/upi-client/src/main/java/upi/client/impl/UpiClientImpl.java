package upi.client.impl;

import java.util.Arrays;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

import upi.client.UpiClient;
import upi.client.UpiUriService;

@Component("upiClient")
public class UpiClientImpl implements UpiClient {
	
	@Autowired
	private UpiUriService upiUriService;

	@Autowired
	private RestTemplate restTemplate;

	public UpiClientImpl(){
	}

	/*static {
	    HttpsURLConnection.setDefaultHostnameVerifier(new HostnameVerifier()
	        {
	            public boolean verify(String hostname, SSLSession session)
	            {
	                // ip address of the service URL(like.23.28.244.244)
	                if (hostname.equals("103.14.161.149"))//TODO need to get from properties.
	                    return true;
	                return false;
	            }
	        });
	}*/
	
	@Override
	public String reqUpi(String req, String api, String ver, String txnId) {
		String str = upiUriService.getUpiServerUrl(UpiUriService.DELIMETER + api + UpiUriService.DELIMETER + ver + UpiUriService.URI + txnId );
		HttpHeaders headers = new HttpHeaders();
		headers.setAccept(Arrays.asList(MediaType.APPLICATION_XML));
		headers.setContentType(MediaType.APPLICATION_XML);
		HttpEntity<String> entity = new HttpEntity<String>(req, headers);
		String response = restTemplate.postForObject(str, entity, String.class);
		return response;
	}
	
}