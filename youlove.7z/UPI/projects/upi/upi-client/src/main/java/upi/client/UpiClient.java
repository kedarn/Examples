package upi.client;


public interface UpiClient {

	String reqUpi(String req, String api, String ver, String txnId);
	
}