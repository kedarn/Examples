package upi.client.impl;

import upi.client.UpiUriService;

public class UpiUriServiceImpl implements UpiUriService {
	
	private String upiServerUrl;
	
	public UpiUriServiceImpl(String upiServerUrl){
		this.upiServerUrl = upiServerUrl;
	}

	@Override
	public String getUpiServerUrl(String key) {
		return upiServerUrl + key;
	}
	
}