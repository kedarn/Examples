package upi.client.impl;

import java.util.Arrays;
import org.apache.log4j.Logger;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

import upi.client.PspClient;

@Component("pspClient")
public class PspClientImpl implements PspClient {
	
	private static final Logger LOGGER = Logger.getLogger(PspClientImpl.class.getName());

	@Autowired
	private RestTemplate restTemplate;

	public PspClientImpl(){
	}

	@Override
	public String reqPsp(String req, String refUrl, String api, String ver, String txnId) {
		String str = null;
		if(refUrl.endsWith("/")){
			str = refUrl;
		}
		else {
			str = refUrl + DELIMETER;
		}
		str = str + api + DELIMETER + ver + PSP_URI + txnId;
		LOGGER.debug("PSP URL: " + str);
		LOGGER.debug("Request data to PSP: " + req);
		HttpHeaders headers = new HttpHeaders();
		headers.setAccept(Arrays.asList(MediaType.APPLICATION_XML));
		headers.setContentType(MediaType.APPLICATION_XML);
		HttpEntity<String> entity = new HttpEntity<String>(req, headers);
		String response = restTemplate.postForObject(str, entity, String.class);
		LOGGER.debug("Response data from PSP: " + response);
		return response;
	}
		
}