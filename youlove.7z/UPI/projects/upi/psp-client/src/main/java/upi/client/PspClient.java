package upi.client;


public interface PspClient {

	String PSP_URI = "/urn:txnid:";
	
	String DELIMETER = "/";

	String reqPsp(String req, String refUrl, String api, String ver, String txnId);
	
}