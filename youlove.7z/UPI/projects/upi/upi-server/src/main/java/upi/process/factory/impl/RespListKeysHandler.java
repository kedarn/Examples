/**
 * 
 */
package upi.process.factory.impl;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.upi.system_1_2.RespListKeys;

import upi.process.factory.UpiCoreHandler;
import upi.server.constants.ServiceNames;
import upi.server.process.UpiClientService;
import upi.server.util.PspClientTool;

/**
 * @author prasadj
 *
 */
@Component("respListKeysHandler")
public class RespListKeysHandler extends UpiCoreHandler {

	private static final Logger LOGGER = Logger.getLogger(RespListKeysHandler.class.getName());
	
	@Autowired
	private UpiClientService upiClientService;

	public RespListKeysHandler(){
	}
	
	@Override
	public String handleProcess(String upiData) {
		LOGGER.debug("RespListKeysHandler.handleProcess");
		RespListKeys rpr = PspClientTool.convertUpiRequest(upiData, RespListKeys.class);
		return upiClientService.requestToString(prepareAckObject(ServiceNames.RESP_LIST_KEYS, rpr.getHead().getMsgId(), null));
	}

}