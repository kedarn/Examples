/**
 * 
 */
package upi.sender.impl;

import org.upi.system_1_2.RespListAccount;

import upi.sender.UpiSender;
import upi.server.process.UpiClientService;

/**
 * @author prasadj
 *
 */
public class RespListAccountSenderImpl implements UpiSender {

	private RespListAccount respListAccount;
	
	public RespListAccountSenderImpl(RespListAccount respListAccount){
		this.respListAccount = respListAccount;
	}
	
	@Override
	public void send(UpiClientService upiClientService) {
		// TODO Nothing to do
	}

}