/**
 * 
 */
package upi.sender.impl;

import org.upi.system_1_2.RespManageVae;

import upi.sender.UpiSender;
import upi.server.process.UpiClientService;

/**
 * @author prasadj
 *
 */
public class RespManageVaeSenderImpl implements UpiSender {

	private RespManageVae respManageVae;
	
	public RespManageVaeSenderImpl(RespManageVae respManageVae){
		this.respManageVae = respManageVae;
	}

	@Override
	public void send(UpiClientService upiClientService) {
		// TODO Need to do R & D
	}

}