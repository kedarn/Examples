/**
 * 
 */
package upi.process.factory.impl;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.upi.system_1_2.ReqOtp;

import upi.process.factory.UpiCoreHandler;
import upi.sender.UpiSender;
import upi.sender.impl.ReqOtpSenderImpl;
import upi.server.constants.ServiceNames;
import upi.server.process.UpiClientService;
import upi.server.util.PspClientTool;
import upi.server.util.ScheduleTask;

/**
 * @author prasadj
 *
 */
@Component("reqOtpHandler")
public class ReqOtpHandler extends UpiCoreHandler {

	private static final Logger LOGGER = Logger.getLogger(ReqOtpHandler.class.getName());
	
	@Autowired
	private UpiClientService upiClientService;

	public ReqOtpHandler(){
	}
	
	@Override
	public String handleProcess(String upiData) {
		LOGGER.debug("ReqOtpHandler.handleProcess");
		ReqOtp rpr = PspClientTool.convertUpiRequest(upiData, ReqOtp.class);
		UpiSender upiSender = new ReqOtpSenderImpl(rpr);
		new Thread( new ScheduleTask(upiSender, upiClientService)).start();
		return upiClientService.requestToString(prepareAckObject(ServiceNames.REQ_OTP, rpr.getHead().getMsgId(), null));
	}

}