package upi.server.process.impl;

import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.util.Properties;

import upi.server.constants.PropertyName;
import upi.server.process.PropertyReader;
/**
 * @author prasadj
 *
 */
public class PropertyReaderImpl implements PropertyReader {

	private Properties projectProp = new Properties();

	private String filePath;
	
	PropertyReaderImpl(String filePath){
		this.filePath = filePath;
		load();
	}
	
	@Override
	public void load() {
		try {
	        final InputStream is = new FileInputStream(new File(filePath));
	        try {
	        	projectProp.load(is);
	        } finally {
	        	if(is != null){
	        		is.close();
	        	}
	        }
	    } 
		catch (Exception asd) {
	    	throw new RuntimeException("Error while reading from properties file.");
	    }
	}
	
	@Override
	public String getValue(String propKey) {
		return projectProp.getProperty(propKey);
	}
	
	@Override
	public String getSignerFilePath() {
		return getValue(PropertyName.SIGNER_FILE_PATH);
	}

	@Override
	public String getCertificateFilePath() {
		return getValue(PropertyName.CERTIFIATE_FILE_PATH);
	}

	@Override
	public String getAccountProviderPath() {
		return getValue(PropertyName.ACCOUNT_PROVIDERS_PATH);
	}

	@Override
	public String getBankAccountsPath() {
		return getValue(PropertyName.BANK_ACCOUNTS_PATH);
	}

	private int getIntValue(String intValue){
		try{
			return Integer.parseInt(intValue);
		}
		catch(Exception ex){
			return 0;
		}
	}

}