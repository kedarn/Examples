/**
 * 
 */
package upi.sender.impl;

import org.upi.system_1_2.RespListAccPvd;

import upi.sender.UpiSender;
import upi.server.process.UpiClientService;

/**
 * @author prasadj
 *
 */
public class RespListAccPvdSenderImpl implements UpiSender {

	private RespListAccPvd respListAccPvd;
	
	public RespListAccPvdSenderImpl(RespListAccPvd respListAccPvd){
		this.respListAccPvd = respListAccPvd;
	}

	@Override
	public void send(UpiClientService upiClientService) {
		// TODO Nothing to do
	}

}