/**
 * 
 */
package upi.sender.impl;

import org.upi.system_1_2.RespListKeys;

import upi.sender.UpiSender;
import upi.server.process.UpiClientService;

/**
 * @author prasadj
 *
 */
public class RespListKeysSenderImpl implements UpiSender {

	private RespListKeys respListKeys;
	
	public RespListKeysSenderImpl(RespListKeys respListKeys){
		this.respListKeys = respListKeys;
	}

	@Override
	public void send(UpiClientService upiClientService) {
		// TODO Nothing to do
	}

}