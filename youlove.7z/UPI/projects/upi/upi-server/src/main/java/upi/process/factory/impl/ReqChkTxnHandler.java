/**
 * 
 */
package upi.process.factory.impl;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.upi.system_1_2.ReqChkTxn;

import upi.process.factory.UpiCoreHandler;
import upi.sender.UpiSender;
import upi.sender.impl.ReqChkTxnSenderImpl;
import upi.server.constants.ServiceNames;
import upi.server.process.UpiClientService;
import upi.server.util.PspClientTool;
import upi.server.util.ScheduleTask;

/**
 * @author prasadj
 *
 */
@Component("reqChkTxnHandler")
public class ReqChkTxnHandler extends UpiCoreHandler {

	private static final Logger LOGGER = Logger.getLogger(ReqChkTxnHandler.class.getName());
	
	@Autowired
	private UpiClientService upiClientService;

	public ReqChkTxnHandler(){
	}
	
	@Override
	public String handleProcess(String upiData) {
		LOGGER.debug("ReqChkTxnHandler.handleProcess");
		ReqChkTxn rpr = PspClientTool.convertUpiRequest(upiData, ReqChkTxn.class);
		UpiSender upiSender = new ReqChkTxnSenderImpl(rpr);
		new Thread( new ScheduleTask(upiSender, upiClientService)).start();
		return upiClientService.requestToString(prepareAckObject(ServiceNames.REQ_CHK_TXN, rpr.getHead().getMsgId(), null));
	}

}