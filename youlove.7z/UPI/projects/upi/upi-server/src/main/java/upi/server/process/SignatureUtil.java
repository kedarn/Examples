/**
 * 
 */
package upi.server.process;

import java.util.List;

import org.upi.system_1_2.RespListAccPvd.AccPvdList.AccPvd;
import org.upi.system_1_2.RespListAccount.AccountList.Account;
import org.w3c.dom.Document;

/**
 * @author prasadj
 *
 */
public interface SignatureUtil {

	boolean isDigitalSignatureValid(String data) throws Exception;
	
	Document signdoc(Document unsignedXML) throws Exception;
	
	String requestToString(Object object);
	
	List<AccPvd> getAccountProviders();
	
	List<Account> getAccounts(String ifsc, String customerName);
	
}