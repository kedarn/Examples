/**
 * 
 */
package upi.sender.impl;

import org.upi.system_1_2.ReqTxnConfirmation;

import upi.sender.UpiSender;
import upi.server.process.UpiClientService;

/**
 * @author prasadj
 *
 */
public class ReqTxnConfirmationSenderImpl implements UpiSender {

	private ReqTxnConfirmation reqTxnConfirmation;
	
	public ReqTxnConfirmationSenderImpl(ReqTxnConfirmation reqTxnConfirmation){
		this.reqTxnConfirmation = reqTxnConfirmation;
	}

	@Override
	public void send(UpiClientService upiClientService) {
		// TODO Nothing to do
	}

}