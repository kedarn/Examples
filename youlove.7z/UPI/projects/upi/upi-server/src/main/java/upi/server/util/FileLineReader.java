/**
 * 
 */
package upi.server.util;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;
import org.upi.system_1_2.ActiveType;
import org.upi.system_1_2.AebaType;
import org.upi.system_1_2.CredDataTypeConstant;
import org.upi.system_1_2.CredSubType;
import org.upi.system_1_2.CredType;
import org.upi.system_1_2.CredsAllowedType;
import org.upi.system_1_2.ListedAccountType;
import org.upi.system_1_2.RespListAccPvd.AccPvdList.AccPvd;
import org.upi.system_1_2.RespListAccount.AccountList.Account;

/**
 * @author prasadj
 *
 */
public class FileLineReader {

	private static final Logger LOGGER = Logger.getLogger(FileLineReader.class.getName());
	
	private String bankProvidersPath;
	
	private String bankAccountsPath;
	
	private List<AccPvd> accountProviders;
	
	private Map<String, List<Account>> accountsMap;
	
	public FileLineReader(String bankProvidersPath, String bankAccountsPath){
		this.bankProvidersPath = bankProvidersPath;
		this.bankAccountsPath = bankAccountsPath;
		initiate();
	}

	public List<AccPvd> getAccountProviders(){
		return accountProviders;
	}
	
	public List<Account> getAccounts(String ifsc, String customerName){
		Iterator<String> iter = accountsMap.keySet().iterator();
		List<Account> accounts = null;
		while(iter.hasNext()){
			String dbifsc = iter.next();
			if( dbifsc.startsWith(ifsc.substring(0, 3)) ){
				List<Account> dbacs = accountsMap.get(dbifsc);
				accounts = new ArrayList<Account>();
				if(dbacs != null){
					for(Account dbac: dbacs){
						Account ac = cloneAccount(dbac);
						ac.setName(customerName);
						accounts.add(ac);
					}
				}
				break;
			}
		}
		return accounts;
	}
	
	private void initiate(){
		LOGGER.debug("initializing bank providers with " + bankProvidersPath + "and bank accounts with" + bankAccountsPath);
		accountProviders = getAccountProviders(getLines(bankProvidersPath));
		accountsMap = getListAccountsMap(getLines(bankAccountsPath));
	}
	
	private List<String> getLines(String filepath){
		List<String> lines = new ArrayList<String>();
		BufferedReader br = null;
		try {
			File file = new File(filepath);
			br = new BufferedReader(new FileReader(file));
			String line = br.readLine();
		    while ((line = br.readLine()) != null) {
		    	lines.add(line);
		    }
		}
		catch (Exception ex){
			ex.printStackTrace();
		}
		finally{
			if(br != null){
				try {
					br.close();
				}
				catch(Exception ex){
					ex.printStackTrace();
				}
			}
		}
		return lines;
	}
	
	private List<AccPvd> getAccountProviders(List<String> lines){
		List<AccPvd> accPvdList = new ArrayList<AccPvd>();
		for(String line: lines){
			LOGGER.debug("Record: " + line);
			if(line != null && !line.isEmpty()){
				try {
					AccPvd accPvd = new AccPvd();
					String[] values = line.split(",");
					accPvd.setName(values[0].trim());
					accPvd.setIin(values[1].trim());
					if(ActiveType.Y.name().equalsIgnoreCase(values[2].trim())){
						accPvd.setActive(ActiveType.Y);
					}
					else {
						accPvd.setActive(ActiveType.N);
					}
					accPvd.setSpocName(values[3].trim());
					accPvd.setSpocEmail(values[4].trim());
					accPvd.setSpocPhone(values[5].trim());
					accPvd.setProds(values[6].trim());
					accPvd.setLastModifedTs(values[7].trim());
					accPvdList.add(accPvd);
				}
				catch(Exception ex){
					LOGGER.info(line + " is not valid");
				}
			}
		}
		return accPvdList;
	}
	
	private Map<String, List<Account>> getListAccountsMap(List<String> lines){
		Map<String, List<Account>> accounts = new HashMap<String, List<Account>>();
		for(String line: lines){
			LOGGER.debug("Record: " + line);
			if(line != null && !line.isEmpty()){
				try {
					String[] values = line.split(",");
					String bn = values[0].trim();
					List<Account> list = accounts.get(bn);
					if(list == null){
						list = new ArrayList<Account>();
						accounts.put(bn, list);
					}
					list.add(getAccount(values));
				}
				catch(Exception ex){
					LOGGER.info(line + " is not valid");
				}
			}
		}
		return accounts;
	}
	
	private Account getAccount(String[] values){
		Account account = new Account();
		
		account.setAccRefNumber(values[1].trim());
		account.setAccType(getListedAccountType(values[2].trim()));
		account.setAeba(getAebaType(values[3].trim()));
		account.setIfsc(values[4].trim());
		account.setMaskedAccnumber(values[5].trim());
		account.setMbeba(getAebaType(values[6].trim()));
		account.setMmid(values[7].trim());
		return account;
	}
	
	private Account cloneAccount(Account dbAccount){
		Account account = new Account();
		
		account.setAccRefNumber(dbAccount.getAccRefNumber());
		account.setAccType(dbAccount.getAccType());
		account.setAeba(dbAccount.getAeba());
		account.setIfsc(dbAccount.getIfsc());
		account.setMaskedAccnumber(dbAccount.getMaskedAccnumber());
		account.setMbeba(dbAccount.getMbeba());
		account.setMmid(dbAccount.getMmid());
		
		List<CredsAllowedType> allowedTypes = account.getCredsAllowed();
		CredsAllowedType credsAllowedType = new CredsAllowedType();
		credsAllowedType.setDLength(6);
		credsAllowedType.setDType(CredDataTypeConstant.ALPHANUMERIC);
		credsAllowedType.setType(CredType.PIN);
		credsAllowedType.setSubType(CredSubType.MPIN);
		allowedTypes.add(credsAllowedType);
		return account;
	}

	public ListedAccountType getListedAccountType(String value){
		if(ListedAccountType.SAVINGS.name().equals(value)){
			return ListedAccountType.SAVINGS;
		}
		else if(ListedAccountType.CURRENT.name().equals(value)){
			return ListedAccountType.CURRENT;
		}
		else {
			return null;
		}
	}
	
	public AebaType getAebaType(String value){
		if(AebaType.Y.name().endsWith(value)){
			return AebaType.Y;
		}
		else {
			return AebaType.N;
		}
	}
	
	public static void main(String args[]){
		FileLineReader fr = new FileLineReader("D:/npci/projects/props/upi-simulator/accpvd.csv", "D:/npci/projects/props/upi-simulator/bankaccounts.csv");
		List<String> apLines = fr.getLines("D:/npci/projects/props/upi-simulator/accpvd.csv");
		List<AccPvd> accpvdList = fr.getAccountProviders(apLines);
		System.out.println("list size: " + accpvdList.size());
		
		List<String> baLines = fr.getLines("D:/npci/projects/props/upi-simulator/bankaccounts.csv");
		Map<String, List<Account>> banksList = fr.getListAccountsMap(baLines);
		System.out.println("list size: " + banksList.size());
		
		Iterator<String> iter = banksList.keySet().iterator();
		while(iter.hasNext()){
			String key = iter.next();
			List<Account> accounts = banksList.get(key);
			for(Account ac: accounts){
				System.out.println();
				System.out.print("A/C Reference: " + ac.getAccRefNumber());
				System.out.print(", AccountType: " + ac.getAccType());
				System.out.print(", Aeba: " + ac.getAeba());
				System.out.print(", Ifsc: " + ac.getIfsc());
				System.out.print(", Mask A/C No: " + ac.getMaskedAccnumber());
				System.out.print(", Mbeba: " + ac.getMbeba());
				System.out.print(", MMID: " + ac.getMmid());
			}
		}
	}
}