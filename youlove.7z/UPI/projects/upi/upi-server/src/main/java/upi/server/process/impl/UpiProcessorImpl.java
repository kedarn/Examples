/**
 * 
 */
package upi.server.process.impl;

import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.upi.system_1_2.Ack;

import upi.process.factory.UpiCoreHandler;
import upi.process.factory.UpiHandlerFactory;
import upi.server.constants.StatusCode;
import upi.server.process.UpiClientService;
import upi.server.process.UpiProcessor;
import upi.server.util.DtoObjectUtil;
import upi.server.util.UpiProcessUtility;

/**
 * @author manasp
 *
 */
@Component("pspRequestProcessor")
public class UpiProcessorImpl implements UpiProcessor {

	@Autowired
	private UpiHandlerFactory upiHandlerFactory;

	@Autowired
	private UpiClientService upiClientService;

	private static final Logger LOGGER = Logger.getLogger(UpiProcessorImpl.class.getName());
	
	@Override
	public String processRequest(String serviceName, String data) {
		LOGGER.info("service Name : " + serviceName);
		String beanName = UpiProcessUtility.getProcessBeanName(serviceName);
		UpiCoreHandler process = upiHandlerFactory.getHandler(beanName);
		boolean isSignatureValid = false;
		List<StatusCode> scList = new ArrayList<>();
		LOGGER.debug("Request: \n" + data);
		String output = "";
		try {
			isSignatureValid = upiClientService.isDigitalSignatureValid(data);
			if (isSignatureValid) {//validate if signature is valid or not
				output = process.handleProcess(data);
			}
			else {
				scList.add(StatusCode.SIGNATURE_ERROR);
				Ack ack = process.prepareAckObject(serviceName, UpiProcessUtility.getMsgId(data, serviceName), scList);
				output = upiClientService.requestToString(ack);
			}
		} catch (Exception e) {
			e.printStackTrace();
			scList.add(StatusCode.INTERNAL_SERVER_ERROR_MSG);
			Ack ack = process.prepareAckObject(serviceName, DtoObjectUtil.constructMessageId(), scList);
			output = upiClientService.requestToString(ack);
		}
		LOGGER.debug("Respone: \n" + output);
		return output;
	}

}