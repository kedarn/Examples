/**
 * 
 */
package upi.process.factory.impl;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.upi.system_1_2.RespPay;

import upi.process.factory.UpiCoreHandler;
import upi.server.constants.ServiceNames;
import upi.server.process.UpiClientService;
import upi.server.util.PspClientTool;

/**
 * @author prasadj
 *
 */
@Component("respPayHandler")
public class RespPayHandler extends UpiCoreHandler {

	private static final Logger LOGGER = Logger.getLogger(RespPayHandler.class.getName());
	
	@Autowired
	private UpiClientService upiClientService;

	public RespPayHandler(){
	}
	
	@Override
	public String handleProcess(String pspData) {
		LOGGER.debug("RespPayHandler.handleProcess");
		RespPay rpr = PspClientTool.convertUpiRequest(pspData, RespPay.class);
		return upiClientService.requestToString(prepareAckObject(ServiceNames.RESP_PAY, rpr.getHead().getMsgId(), null));
	}

}