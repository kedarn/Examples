/**
 * 
 */
package upi.server.process.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.upi.system_1_2.RespListAccPvd.AccPvdList.AccPvd;
import org.upi.system_1_2.RespListAccount.AccountList.Account;

import upi.client.PspClient;
import upi.server.process.SignatureUtil;
import upi.server.process.UpiClientService;

/**
 * @author prasadj
 *
 */
@Component("upiClientService")
public class UpiClientServiceImpl implements UpiClientService {

	@Autowired
	private PspClient pspClient;

	@Autowired
	private SignatureUtil signatureUtil;

	public UpiClientServiceImpl(){
	}

	@Override
	public String callPsp(String data, String refUrl, String api, String version, String txnId) {
		return pspClient.reqPsp(data, refUrl, api, version, txnId);
	}
	
	@Override
	public boolean isDigitalSignatureValid(String data) throws Exception {
		return signatureUtil.isDigitalSignatureValid(data);
	}

	@Override
	public String requestToString(Object object) {
		return signatureUtil.requestToString(object);
	}

	@Override
	public List<AccPvd> getAccountProviders() {
		return signatureUtil.getAccountProviders();
	}

	@Override
	public List<Account> getAccounts(String ifsc, String customerName) {
		return signatureUtil.getAccounts(ifsc, customerName);
	}

}