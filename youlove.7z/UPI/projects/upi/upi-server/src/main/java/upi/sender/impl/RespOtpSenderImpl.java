/**
 * 
 */
package upi.sender.impl;

import org.upi.system_1_2.RespOtp;

import upi.sender.UpiSender;
import upi.server.process.UpiClientService;

/**
 * @author prasadj
 *
 */
public class RespOtpSenderImpl implements UpiSender {

	private RespOtp respOtp;
	
	public RespOtpSenderImpl(RespOtp respOtp){
		this.respOtp = respOtp;
	}

	@Override
	public void send(UpiClientService upiClientService) {
		// TODO Nothing to do
	}

}