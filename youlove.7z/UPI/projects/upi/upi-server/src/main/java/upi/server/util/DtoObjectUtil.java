/**
 * 
 */
package upi.server.util;

import org.upi.system_1_2.AddressType;
import org.upi.system_1_2.CredSubType;
import org.upi.system_1_2.CredType;
import org.upi.system_1_2.IdentityConstant;
import org.upi.system_1_2.LinkType;
import org.upi.system_1_2.PayConstant;
import org.upi.system_1_2.PayerConstant;
import org.upi.system_1_2.ReqMsgType;
import org.upi.system_1_2.WhiteListedConstant;

import upi.server.constants.ServiceNames;
import upi.server.constants.VirtualPayerType;


/**
 * @author prasadj
 *
 */
public class DtoObjectUtil {

	private DtoObjectUtil(){
	}

	public static String constructMessageId(){
		return "TARAGUPI" + String.valueOf(System.currentTimeMillis());
	}
	
	public static PayConstant getPayConstant(String type) {
		PayConstant constant = null;
		if (type.equals(ServiceNames.REQ_LIST_ACC_PVD)) {
			constant = PayConstant.LIST_ACC_PVD;
		}
		else if (type.equals(ServiceNames.REQ_HBT)) {
			constant = PayConstant.HBT;
		}
		else if (type.equals(ServiceNames.REQ_OTP)) {
			constant = PayConstant.OTP;
		}
		else if (type.equals(ServiceNames.REQ_LIST_ACCOUNT)) {
			constant = PayConstant.LIST_ACCOUNT;
		}
		else if (type.equals(ServiceNames.REQ_SET_CRE)) {
			constant = PayConstant.SET_CRE;
		}
		else if (type.equals(PayConstant.LIST_KEYS.name())) {
			constant = PayConstant.LIST_KEYS;
		}
		else if (type.equals(PayConstant.GET_TOKEN.name())) {
			constant = PayConstant.GET_TOKEN;
		}
		else if (type.equals(PayConstant.PAY.name())) {
			constant = PayConstant.PAY;
		}
		else if (type.equals(PayConstant.COLLECT.name())) {
			constant = PayConstant.COLLECT;
		}
		else if (type.equals(PayConstant.TXN_CONFIRMATION.name())) {
			constant = PayConstant.TXN_CONFIRMATION;
		}
		else if (type.equals(ServiceNames.REQ_REG_MOB)) {//TODO As per spec type is RegMob
			constant = PayConstant.REQ_REG_MOB;
		}
		else if (type.equals(PayConstant.CREDIT.name())) {
			constant = PayConstant.CREDIT;
		}
		else if (type.equals(PayConstant.DEBIT.name())) {
			constant = PayConstant.DEBIT;
		}
		else if (type.equals(ServiceNames.REQ_LIST_ACCOUNT)) {
			constant = PayConstant.LIST_ACCOUNT;
		}
		else if (type.equals(ServiceNames.REQ_BAL_ENQ)) {
			constant = PayConstant.BAL;
		}
		
		return constant;
	}
	
	public static PayerConstant getPayerConstant(String type) {
		PayerConstant constant = null;
		if (type.equals(VirtualPayerType.PERSON.name())) {
			constant = PayerConstant.PERSON;
		}
		else {
			constant = PayerConstant.ENTITY;
		}
		return constant;
	}
	
	public static IdentityConstant getIdentityConstant(String type) {
		IdentityConstant constant = null;
		if (type.equals(IdentityConstant.BANK.name())) {//TODO need to check
			constant = IdentityConstant.BANK;
		}
		else if (type.equals(IdentityConstant.AADHAAR.name())) {//TODO need to check
			constant = IdentityConstant.AADHAAR;
		} 
		else if (type.equals(IdentityConstant.ACCOUNT.name())) {//TODO need to check
			constant = IdentityConstant.ACCOUNT;
		}
		else {
			constant = IdentityConstant.PAN;
		}
		return constant;
	}
	
	public static WhiteListedConstant getWhiteListedConstant(Boolean type){
		WhiteListedConstant constant = null;
		if (type.equals(WhiteListedConstant.TRUE.name())) {
			constant = WhiteListedConstant.TRUE;
		}
		else {
			constant = WhiteListedConstant.FALSE;
		}
		return constant;
	}
	
	public static AddressType getAddressType(String type){
		AddressType constant = null;
		if (type.equals(AddressType.AADHAAR.name())) {
			constant = AddressType.AADHAAR;
		}
		else if (type.equals(AddressType.ACCOUNT.name())) {
			constant = AddressType.ACCOUNT;
		}
		else if (type.equals(AddressType.CARD.name())) {
			constant = AddressType.CARD;
		}
		else if (type.equals(AddressType.MOBILE.name())) {
			constant = AddressType.MOBILE;
		}
		return constant;
	}
	
	public static CredType getCredType(String type){
		CredType constant = null;
		if (type.equals(CredType.AADHAAR.name())) {
			constant = CredType.AADHAAR;
		}
		else if (type.equals(CredType.CARD.name())) {
			constant = CredType.CARD;
		}
		else if (type.equals(CredType.CHALLENGE.name())) {
			constant = CredType.CHALLENGE;
		}
		else if (type.equals(CredType.OTP.name())) {
			constant = CredType.OTP;
		}
		else if (type.equals(CredType.PIN.name())) {
			constant = CredType.PIN;
		}
		else if (type.equals(CredType.PRE_APPROVED.name())) {
			constant = CredType.PRE_APPROVED;
		}
		return constant;
	}
	
	public static CredSubType getCredSubType(String type){
		CredSubType constant = null;
		if (type.equals(CredSubType.CVV_1.name())) {
			constant = CredSubType.CVV_1;
		}
		else if (type.equals(CredSubType.CVV_2.name())) {
			constant = CredSubType.CVV_2;
		}
		else if (type.equals(CredSubType.EMAIL.name())) {
			constant = CredSubType.EMAIL;
		}
		else if (type.equals(CredSubType.EMV.name())) {
			constant = CredSubType.EMV;
		}
		else if (type.equals(CredSubType.FIR.name())) {
			constant = CredSubType.FIR;
		}
		else if (type.equals(CredSubType.FMR.name())) {
			constant = CredSubType.FMR;
		}
		else if (type.equals(CredSubType.HOTP.name())) {
			constant = CredSubType.HOTP;
		}
		else if (type.equals(CredSubType.IIR.name())) {
			constant = CredSubType.IIR;
		}
		else if (type.equals(CredSubType.INITIAL.name())) {
			constant = CredSubType.INITIAL;
		}
		else if (type.equals(CredSubType.MPIN.name())) {
			constant = CredSubType.MPIN;
		}
		else if (type.equals(CredSubType.NA.name())) {
			constant = CredSubType.NA;
		}
		else if (type.equals(CredSubType.OTP.name())) {
			constant = CredSubType.OTP;
		}
		else if (type.equals(CredSubType.RESET.name())) {
			constant = CredSubType.RESET;
		}
		else if (type.equals(CredSubType.ROTATE.name())) {
			constant = CredSubType.ROTATE;
		}
		else if (type.equals(CredSubType.SMS.name())) {
			constant = CredSubType.SMS;
		}
		else if (type.equals(CredSubType.TOTP.name())) {
			constant = CredSubType.TOTP;
		}
		return constant;
	}
	
	public static ReqMsgType getReqMsgType(String type) {
		ReqMsgType msgType = null;
		if (type.equals(ReqMsgType.AADHAAR.name())) {
			msgType = ReqMsgType.AADHAAR;
		}
		else if (type.equals(ReqMsgType.MOBILE.name())) {
			msgType = ReqMsgType.MOBILE;
		}
		return msgType;
	}
	
	public static LinkType getLinkType(String type) {
		LinkType linkType = null;
		if (type.equals(LinkType.AADHAAR.name())) {
			linkType = LinkType.AADHAAR;
		}
		else if (type.equals(LinkType.MOBILE.name())) {
			linkType = LinkType.MOBILE;
		}
		return linkType;
	}
	
}