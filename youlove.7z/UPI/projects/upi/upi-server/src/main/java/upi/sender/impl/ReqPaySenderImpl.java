/**
 * 
 */
package upi.sender.impl;

import org.upi.system_1_2.Ack;
import org.upi.system_1_2.ReqAuthDetails;
import org.upi.system_1_2.ReqPay;

import upi.sender.UpiSender;
import upi.server.constants.ServiceNames;
import upi.server.process.UpiClientService;
import upi.server.util.PspClientTool;

/**
 * @author prasadj
 *
 */
public class ReqPaySenderImpl implements UpiSender {

	private ReqPay reqPay;
	
	public ReqPaySenderImpl(ReqPay reqPay){
		this.reqPay = reqPay;
	}
	
	@Override
	public void send(UpiClientService upiClientService) {
		ReqAuthDetails reqAuthDetails = prepareReqAuthDetails(reqPay);
		String reqAuthDetailsStr = upiClientService.requestToString(reqAuthDetails);
		String ackStr = upiClientService.callPsp(reqAuthDetailsStr, reqPay.getTxn().getRefUrl(), ServiceNames.REQ_AUTH_DETAILS, 
				reqAuthDetails.getHead().getVer(), reqAuthDetails.getTxn().getId());
		Ack ack = PspClientTool.convertUpiRequest(ackStr, Ack.class);
		if(ack.getErr() == null) {
		}
	}
	
	private ReqAuthDetails prepareReqAuthDetails(ReqPay reqPay) {
		ReqAuthDetails reqAuthDetails = new ReqAuthDetails();
		reqAuthDetails.setHead(reqPay.getHead());
		reqAuthDetails.setPayees(reqPay.getPayees());
		reqAuthDetails.setPayer(reqPay.getPayer());
		reqAuthDetails.setTxn(reqPay.getTxn());
		return reqAuthDetails;
	}

}