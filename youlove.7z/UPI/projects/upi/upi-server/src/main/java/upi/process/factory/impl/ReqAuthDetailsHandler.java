/**
 * 
 */
package upi.process.factory.impl;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.upi.system_1_2.ReqAuthDetails;

import upi.process.factory.UpiCoreHandler;
import upi.sender.UpiSender;
import upi.sender.impl.ReqAuthDetailsSenderImpl;
import upi.server.constants.ServiceNames;
import upi.server.process.UpiClientService;
import upi.server.util.PspClientTool;
import upi.server.util.ScheduleTask;

/**
 * @author prasadj
 *
 */
@Component("reqAuthDetailsHandler")
public class ReqAuthDetailsHandler extends UpiCoreHandler {

	private static final Logger LOGGER = Logger.getLogger(ReqAuthDetailsHandler.class.getName());

	@Autowired
	private UpiClientService upiClientService;
	
	public ReqAuthDetailsHandler(){
	}
	
	@Override
	public String handleProcess(String pspData) {
		LOGGER.debug("ReqAuthDetailsHandler.handleProcess");
		ReqAuthDetails rpr = PspClientTool.convertUpiRequest(pspData, ReqAuthDetails.class);
		UpiSender upiSender = new ReqAuthDetailsSenderImpl(rpr);
		new Thread( new ScheduleTask(upiSender, upiClientService)).start();
		return upiClientService.requestToString(prepareAckObject(ServiceNames.REQ_AUTH_DETAILS, rpr.getHead().getMsgId(), null));
	}
	
}