/**
 * 
 */
package upi.process.factory.impl;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.upi.system_1_2.RespPendingMsg;

import upi.process.factory.UpiCoreHandler;
import upi.server.constants.ServiceNames;
import upi.server.process.UpiClientService;
import upi.server.util.PspClientTool;

/**
 * @author prasadj
 *
 */
@Component("respPendingMsgHandler")
public class RespPendingMsgHandler extends UpiCoreHandler {

	private static final Logger LOGGER = Logger.getLogger(RespPendingMsgHandler.class.getName());
	
	@Autowired
	private UpiClientService upiClientService;

	public RespPendingMsgHandler(){
	}
	
	@Override
	public String handleProcess(String upiData) {
		LOGGER.debug("RespPendingMsgHandler.handleProcess");
		RespPendingMsg rpr = PspClientTool.convertUpiRequest(upiData, RespPendingMsg.class);
		return upiClientService.requestToString(prepareAckObject(ServiceNames.RESP_PENDING_MSG, rpr.getHead().getMsgId(), null));
	}

}