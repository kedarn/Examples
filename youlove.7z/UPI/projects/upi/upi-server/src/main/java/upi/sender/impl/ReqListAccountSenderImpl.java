/**
 * 
 */
package upi.sender.impl;

import java.util.List;

import org.upi.system_1_2.AccountType.Detail;
import org.upi.system_1_2.Ack;
import org.upi.system_1_2.ReqListAccount;
import org.upi.system_1_2.RespListAccount;
import org.upi.system_1_2.RespListAccount.AccountList;
import org.upi.system_1_2.RespListAccount.AccountList.Account;
import org.upi.system_1_2.RespType;

import upi.sender.UpiSender;
import upi.server.constants.ServiceNames;
import upi.server.process.UpiClientService;
import upi.server.util.PspClientTool;

/**
 * @author prasadj
 *
 */
public class ReqListAccountSenderImpl implements UpiSender {

	private ReqListAccount reqListAccount;
	
	public ReqListAccountSenderImpl(ReqListAccount reqListAccount){
		this.reqListAccount = reqListAccount;
	}
	
	@Override
	public void send(UpiClientService upiClientService) {
		RespListAccount respListAcc = prepareRespListAccount(reqListAccount, upiClientService);
		String respListAccStr = upiClientService.requestToString(respListAcc);
		String ackStr = upiClientService.callPsp(respListAccStr, reqListAccount.getTxn().getRefUrl(), ServiceNames.RESP_LIST_ACCOUNT, 
				respListAcc.getHead().getVer(), respListAcc.getTxn().getId());
		Ack ack = PspClientTool.convertUpiRequest(ackStr, Ack.class);
		if(ack.getErr() == null) {
		}
	}
	
	private RespListAccount prepareRespListAccount(ReqListAccount reqListAccount, UpiClientService upiClientService) {	
		RespListAccount respListAcc = new RespListAccount();
		respListAcc.setHead(reqListAccount.getHead());
		respListAcc.setTxn(reqListAccount.getTxn());
		RespType respType = new RespType();
		AccountList accountList = new AccountList();
		List<Account> accounts = upiClientService.getAccounts( getIfsc(reqListAccount.getPayer().getAc().getDetail()), reqListAccount.getPayer().getName() );
		if(accounts != null){
			accountList.getAccount().addAll(accounts);
			respType.setResult("SUCCESS");
		} else {
			respType.setResult("FAILURE");
		}
		respListAcc.setAccountList(accountList);
		respType.setReqMsgId(reqListAccount.getHead().getMsgId());
		respListAcc.setResp(respType);
		return respListAcc;
	}
	
	private String getIfsc(List<Detail> details){
		for(Detail detail: details){
			if(detail.getName().name().equals("IFSC")){
				return detail.getValue();
			}
		}
		return null;
	}
	
}