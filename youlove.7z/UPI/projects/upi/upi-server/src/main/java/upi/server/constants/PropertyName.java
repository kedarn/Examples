/**
 * 
 */
package upi.server.constants;

/**
 * @author prasadj
 *
 */
public interface PropertyName {

	String SIGNER_FILE_PATH = "signer.file.path";
	
	String CERTIFIATE_FILE_PATH = "certificate.file.path";
	
	String ACCOUNT_PROVIDERS_PATH = "account.providers.path";
	
	String BANK_ACCOUNTS_PATH = "bank.accounts.path";
	
}