/**
 * 
 */
package upi.sender.impl;

import org.upi.system_1_2.RespListPsp;

import upi.sender.UpiSender;
import upi.server.process.UpiClientService;

/**
 * @author prasadj
 *
 */
public class RespListPspSenderImpl implements UpiSender {

	private RespListPsp respListPsp;
	
	public RespListPspSenderImpl(RespListPsp respListPsp){
		this.respListPsp = respListPsp;
	}

	@Override
	public void send(UpiClientService upiClientService) {
		// TODO Nothing to do
	}

}