/**
 * 
 */
package upi.server.util;

/**
 * @author manasp
 *
 */
public class SampleData {

	public static String HEAD = "<Head ver='1.0' ts='2015-02-16T22:02:28+05:30' orgId='400001' msgId='HENSVVR4QOS7X1UGPY7JGZZ444PL9T2C3QM'/>";
	
	public static String RESP = "<Resp reqMsgId='HENZVVR4QOS7X1UGPY7JGZZ444PL9T2C3QM' result='SUCCESS' errCode=''/>";
	
	public static String ACK_RESPONSE = "<upi:Ack api='ReqPay' err='SUCCESS' reqMsgId='MSG1001' xmlns:upi='http://npci.org/upi/schema/' ts='TXN1002'/>";
	
	public static String BALANCE_RESPONSE = "<upi:RespBalEnq xmlns:upi='http://npci.org/upi/schema/'>" + HEAD + prepareTxn("Balance Enquiry","BalEnq") + RESP 
			+ "<Payer addr='Zeeshan.khan@hdfc' name='Mohd Zeeshan Khan' seqNum='1' type='PERSON' code='4814'><Bal><Data code='' ki=''> base-64 encoded/encrypted data </Data></Bal></Payer>"
			+ "</upi:RespBalEnq>";
	
	public static String CHK_TXN_RESPONSE = "<upi:RespChkTxn xmlns:upi='http://npci.org/upi/schema/'>"+ HEAD + prepareTxn("Restaurant Bill","ChkTxn") + RESP +  "</upi:RespChkTxn>";
	
	public static  String HEART_BEAT_RESPONSE = "<upi:RespHbt xmlns:upi='http://npci.org/upi/schema/'>"+ HEAD + prepareTxn("Heart Beat","Hbt") + RESP +  "</upi:RespHbt>";
	
	public static String PSP_LIST_RESPONSE = "<upi:RespListPsp xmlns:upi='http://npci.org/upi/schema/'>"+ HEAD + prepareTxn("Listing PSP’s","ListPSP") + RESP + "<PspList><Psp name='HDFC' codes='hdfcgold,hdfcsliver' active='Y' url='www.psphdfc.com' spocName='Rohit' spocEmail='rohit@hdfc.com' spocPhone='9561595903' lastModifedTs='2015-01-16T22:02:40+05:30'/><Psp name='ICICI' codes='icici,iciciwallet' active='Y' url='www.psp.icici.com' spocName='Amit' spocEmail='amit@icici.com' spocPhone='9561595903' lastModifedTs='2015-01-16T22:02:40+05:30'/><Psp name='State Bank of India' codes='sbi' active='Y' url='www.sbipsp.co.in' spocName='Shruti' spocEmail='Shruti@sbi.co.in' spocPhone='9561595903' lastModifedTs='2015-01-16T22:02:40+05:30'/></PspList></upi:RespListPsp>";
	
	public static  String ACCOUNT_LIST_RESPONSE = "<upi:RespListAccount xmlns:upi='http://npci.org/upi/schema/'>"+ HEAD + prepareTxn("Account Listing","ListAccount") + RESP 
														+  "<AccountList>"
														+ "<Account accRefNumber='' maskedAccNumber='**********55743' ifsc='HDFC0000101' mmid='' name='Rohit Patkar' aeba='N'/>"
														+ "<Account accRefNumber='' maskedAccNumber='**********55787' ifsc='HDFC0000105' mmid='' name='Rohit Patkar' aeba='Y'/>"
														+ "</AccountList></upi:RespListAccount>";
	
	public static String ACCOUNT_PROVIDER_LIST_RESPONSE = "<upi:RespListAccPvd xmlns:upi='http://npci.org/upi/schema/'>"+ HEAD + prepareTxn("Account provider Listing","ListAccPvd") + RESP 
																+ "<AccPvdList>"
																+ "<AccPvd name='HDFC' iin='901345' active='Y' spocPhone='9561595903' spocEmail='rohit@hdfc.com' spocName='Rohit' url='www.psphdfc.com' prods='AEPS,IMPS,CARD,NFS,UPI' lastModifedTs='2015-01-16T22:02:40+05:30'/>"
																+ "<AccPvd name='ICICI' iin='901346' active='Y' spocPhone='7646379722' spocEmail='amit@icici.com' spocName='Amit Sonkar' url='www.psp.icici.com' prods='AEPS,UPI,IMPS,CARD,NFS' lastModifedTs='2015-01-17T22:02:40+05:30'/>"
																+ "<AccPvd name='Axis' iin='901347' active='Y' spocPhone='7646379722' spocEmail='amit@axis.com' spocName='Amit Sonkar' url='www.psp.axis.com' prods='AEPS,UPI,IMPS,CARD,NFS' lastModifedTs='2015-01-17T22:02:40+05:30'/>"
																+ "</AccPvdList>"
																+ "</upi:RespListAccPvd>";
	
	public static String KEY_LIST_RESPONSE = "<upi:RespListKeys xmlns:upi='http://npci.org/upi/schema/'>"+ HEAD + prepareTxn("Account provider Listing","ListKeys") + RESP +  ""
			+ "<keyList><key code='NPCI' owner='NPCI' type='PKI' ki='20150828'><keyValue> base64 encoded certificate </keyValue></key>"
			+ "<key code='NPCI1' owner='NPCI' type='PKI' ki='20150828'><keyValue> base64 encoded certificate </keyValue></key>"
			+ "<key code='NPCI2' owner='NPCI' type='PKI' ki='20150828'><keyValue> base64 encoded certificate </keyValue></key>"
			+ "<key code='NPCI3' owner='NPCI' type='PKI' ki='20150828'><keyValue> base64 encoded certificate </keyValue></key>"
			+ "<key code='NPCI4' owner='NPCI' type='PKI' ki='20150828'><keyValue> base64 encoded certificate </keyValue></key>"
			+ "</keyList></upi:RespListKeys>";
	
	public static final String VERIFIED_ADDRESS_LIST_RESPONSE = "<upi:RespListVae xmlns:upi='http://npci.org/upi/schema/'>"+ HEAD + prepareTxn("Account provider Listing","ListVae") + 
			"<Resp reqMsgId='HENZVVR4QOS7X1UGPY7JGZZ444PL9T2C3QM' result='SUCCESS' errCode=''><VaeList>"
			+ "<Vae name='LIC' addr='lic@hdfc' logo='image' url='www.lic.com'/>"
			+ "<Vae name='IRCTC' addr='irctc@icici' logo='image' url='www.irctc.co.in'/>"
			+ "</VaeList></Resp></upi:RespListVae>";
	public static final String MANAGED_VERIFIED_ADDRESS_LIST_RESPONSE = "<upi:RespManageVae xmlns:upi='http://npci.org/upi/schema/'>"+ HEAD + prepareTxn("Account provider Listing","ManageVae") + RESP +  "</upi:RespManageVae>";
	
	public static final String OTP_RESPONSE = "<upi:RespOtp xmlns:upi='http://npci.org/upi/schema/'>"+ HEAD + prepareTxn("Account provider Listing","ReqOtp") + RESP +  "</upi:RespOtp>";
	
	public static final String PENDING_MSG_RESPONSE = "<upi:RespPendingMsg xmlns:upi='http://npci.org/upi/schema/'>"+ HEAD + prepareTxn("Request pending Msg","ReqPendingMsg") + RESP +  ""
			+ "<RespMsg>"
			+ "<PenTxn id='HENSVVR4QZS7X1UGZY7JGZZ414PL9T2C3QM' note='Restaurant Bill' refId='' refUrl='' ts='2015-02-16T22:02:27+05:30' type='COLLECT' orgTxnId=''/>"
			+ "<PenTxn id='HENSVVR4QZS7X1UGZY7JGZZ414PL9T2C3QM' note='Birthday Party contribution' refId='' refUrl='' ts='2015-02-16T22:02:27+05:30' type='COLLECT' orgTxnId=''/>"
			+ "</RespMsg></upi:RespPendingMsg>";
	
	public static final String VERIFIED_ADDRESS_RESPONSE = "<upi:RespValAdd xmlns:upi='http://npci.org/upi/schema/'>"+ HEAD + prepareTxn("validating Address","ValAdd") + RESP +  "</upi:RespValAdd>";
	
	public static final String SET_CRED_RESPONSE = "<upi:RespSetCre xmlns:upi='http://npci.org/upi/schema/'>"+ HEAD + prepareTxn("setting credentials","SetCre") + RESP +  "</upi:RespSetCre>";
	
	public static final String MOBILE_REG_RESPONSE = "<upi:RespRegMob xmlns:upi='http://npci.org/upi/schema/'>"+ HEAD + prepareTxn("Mobile registration","RegMob") + RESP +  "</upi:RespRegMob>";
	
	public static final String TXN_CONFIRM_RESPONSE = "<upi:RespTxnConfirmation xmlns:upi='http://npci.org/upi/schema/'>"+ HEAD + prepareTxn("Birthday Party contribution","TxnConfirmation") + RESP +  "</upi:RespTxnConfirmation>";
		
	private static String prepareTxn(String note, String type) {
		return "<Txn id='HENZVVR4QOS7X1UGPY7JGZZ444PL9T2C3QM' note='"+ note +"' refId='' refUrl='' ts='2015-02-16T22:02:25+05:30' type='"+ type +"'/>";
	}
	
}
