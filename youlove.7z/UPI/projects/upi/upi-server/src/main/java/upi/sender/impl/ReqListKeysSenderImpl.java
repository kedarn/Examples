/**
 * 
 */
package upi.sender.impl;

import org.upi.system_1_2.Ack;
import org.upi.system_1_2.HeadType;
import org.upi.system_1_2.ReqListKeys;
import org.upi.system_1_2.RespListKeys;
import org.upi.system_1_2.RespListKeys.KeyList;
import org.upi.system_1_2.RespListKeys.KeyList.Key;
import org.upi.system_1_2.RespType;

import upi.sender.UpiSender;
import upi.server.constants.ServiceNames;
import upi.server.process.UpiClientService;
import upi.server.util.PspClientTool;

/**
 * @author prasadj
 *
 */
public class ReqListKeysSenderImpl implements UpiSender {

	private ReqListKeys reqListKeys;
	
	public ReqListKeysSenderImpl(ReqListKeys reqListKeys){
		this.reqListKeys = reqListKeys;
	}

	@Override
	public void send(UpiClientService upiClientService) {
		RespListKeys respListkeys = prepareRespListkeys(reqListKeys);
		String respListAccStr = upiClientService.requestToString(respListkeys);
		String ackStr = upiClientService.callPsp(respListAccStr, reqListKeys.getTxn().getRefUrl(), ServiceNames.RESP_LIST_KEYS, 
				respListkeys.getHead().getVer(), respListkeys.getTxn().getId());
		Ack ack = PspClientTool.convertUpiRequest(ackStr, Ack.class);
		if(ack.getErr() == null) {
		}
	}
	
	private RespListKeys prepareRespListkeys(ReqListKeys reqListKeys ){
		RespListKeys  respListKeys = new RespListKeys();
		HeadType headType = reqListKeys.getHead();
		headType.setOrgId("NPCI");
		respListKeys.setHead(headType);
		respListKeys.setTxn(reqListKeys.getTxn());
		RespType respType = new RespType();
		respType.setResult("SUCCESS");
		respType.setReqMsgId(reqListKeys.getHead().getMsgId());
		respListKeys.setResp(respType);
		respListKeys.setKeyList(preparekeyLists());
		return respListKeys;
	}
	
	private KeyList preparekeyLists(){
		KeyList keylist = new KeyList();
		 Key keyval1 = new Key();
		 keyval1.setCode("NCPI");
		 keyval1.setType("PKI");
		 keyval1.setKi("20150822");
		 keyval1.setOwner("NPCI");
		 keyval1.setKeyValue(sampledata);
		 keylist.getKey().add(keyval1);
		return keylist;
	}

	String sampledata = "<?xml version=\"1.0\" encoding=\"UTF-8\"?><ns2:RespListKeys xmlns:ns2=\"http://npci.org/upi/schema/\">"
			+ "<Head msgId=\"1GRDBknXpxwnbeCLiPlF\" orgId=\"NPCI\" ts=\"2016-04-25T13:24:08+05:30\" ver=\"1.0\"/>"
			+ "<Resp reqMsgId=\"TARANG1461570419785\" result=\"SUCCESS\"/>"
			+ "<Txn id=\"TARANG1461570420230\" note=\"Account provider Listing\" refId=\"TARANG01\" refUrl=\"https://121.244.157.134/\" ts=\"2016-04-25T13:16:59Z\" type=\"ListKeys\"/>"
			+ "<keyList>"
			+ "<key code=\"NPCI\" ki=\"20150822\" owner=\"NPCI\" type=\"PKI\">"
			+ "<keyValue xmlns:xs=\"http://www.w3.org/2001/XMLSchema\" xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" xsi:type=\"xs:string\">"
			+ "MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEA4rIIEHkJ2TYgO/JUJQI/sxDgbDEAIuy9uTf4DItWeIMsG9AuilOj9R+dwAv8S6/9No/z0cwsw4UnsHQG1ALVIxFznLizMjaVJ7TJ+yTS9C9bYEFakRqH8b4jje7SC7rZ9/DtZGsaWaCaDTyuZ9dMHrgcmJjeklRKxl4YVmQJpzYLrK4zOpyY+lNPBqs+aiwJa53ZogcUGBhx/nIXfDDvVOtKzNb/08U7dZuXoiY0/McQ7xEiFcEtMpEJw5EB4o3RhE9j/IQOvc7l/BfD85+YQ5rJGk4HUb6GrQXHzfHvIOf53l1Yb0IX4v9q7HiAyOdggO+PVzXMSbrcFBrEjGZD7QIDAQAB"
			+ "</keyValue>"
			+ "</key>"
			+ "</keyList>"
			+ "<Signature xmlns=\"http://www.w3.org/2000/09/xmldsig#\">"
			+ "<SignedInfo>"
			+ "<CanonicalizationMethod Algorithm=\"http://www.w3.org/TR/2001/REC-xml-c14n-20010315\"/>"
			+ "<SignatureMethod Algorithm=\"http://www.w3.org/2001/04/xmldsig-more#rsa-sha256\"/>"
			+ "<Reference URI=\"\"><Transforms><Transform Algorithm=\"http://www.w3.org/2000/09/xmldsig#enveloped-signature\"/></Transforms>"
			+ "<DigestMethod Algorithm=\"http://www.w3.org/2001/04/xmlenc#sha256\"/><DigestValue>9yAgCmtsMqfvm9ONudm8CT01FTzaEzEQPlu56SMzwsI=</DigestValue></Reference>"
			+ "</SignedInfo>"
			+ "<SignatureValue>JYhXs0zWdZULGphB9MOw1ypZQMDb7xZURvq1oCzhLkNm7G8vxFnwT66ItVzs5EWiJL2MD33BMxBdZc9j5Ed+ZqftYSOVB9Fqox+UJkrLKNCM5XpQ76Kd9163wX5xtDK3I0Sg7ZR0ljvOD+8aBzjH49CCj1Mkly/XITI557RkG79cNUa6dwBXMhHH3malAxsm938Dt7jia4Qm0DoH9S57hX4CgDFu7zG2QlGZL806Y05ErGgEdyfoXmxATYLVmbQmhsv9vSUOik4StI8seBHMFGqeWOjkfriF5fQdLT/xzmIBH1DfG0yswZS03Ljf3MZitbC5fmfSYHQck3NlsgA1Pg==</SignatureValue>"
			+ "<KeyInfo><KeyValue><RSAKeyValue><Modulus>01DqzBsJTyMHT2S9MK5AIyFXNU646kwiOK3uymXIy9EW0nRKNKRkeIRTlGwX4wEnymGtGgX5B/Ij1elkLN4VJ9GplDV+wf0Lp2i2q4E6uRiWIzsqq42MCQgv8Fq/IPqjqPbeP9yh/8YPmBiMehBmhQd3qzl77C03k6d0yBIO5q/zXneTK9uFBNEL5yNpukrLGBcf3b9VHsjXpEaQrxGSMHCgNWpQgXpEcBr5OJ0/XxWbgMCZMlkYe1d6gswjuCRZ/xxJwEfbSO5AsnPtyqxSIjyhgEi9REtYnzaWwOBN4JCqt0pML0ja23lUwVJuNwkwNGKBXvkGoXUln8Sf7PIv7w==</Modulus><Exponent>AQAB</Exponent></RSAKeyValue></KeyValue></KeyInfo>"
			+ "</Signature></ns2:RespListKeys>";
}