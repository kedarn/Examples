/**
 * 
 */
package upi.sender.impl;

import org.upi.system_1_2.RespValAdd;

import upi.sender.UpiSender;
import upi.server.process.UpiClientService;

/**
 * @author prasadj
 *
 */
public class RespValAddSenderImpl implements UpiSender {

	private RespValAdd respValAdd;
	
	public RespValAddSenderImpl(RespValAdd respValAdd){
		this.respValAdd = respValAdd;
	}

	@Override
	public void send(UpiClientService upiClientService) {
		// TODO Nothing to do
	}

}