/**
 * 
 */
package upi.sender.impl;

import org.upi.system_1_2.Ack;
import org.upi.system_1_2.ReqOtp;
import org.upi.system_1_2.RespOtp;
import org.upi.system_1_2.RespType;

import upi.sender.UpiSender;
import upi.server.constants.ServiceNames;
import upi.server.process.UpiClientService;
import upi.server.util.PspClientTool;

/**
 * @author prasadj
 *
 */
public class ReqOtpSenderImpl implements UpiSender {

	private ReqOtp reqOtp;
	
	public ReqOtpSenderImpl(ReqOtp reqOtp){
		this.reqOtp = reqOtp;
	}

	@Override
	public void send(UpiClientService upiClientService) {
		RespOtp respOtp = prepareRespOtp(reqOtp);
		String respOtpStr = upiClientService.requestToString(respOtp);
		String ackStr = upiClientService.callPsp(respOtpStr, reqOtp.getTxn().getRefUrl(), ServiceNames.RESP_OTP, respOtp.getHead().getVer(), respOtp.getTxn().getId());
		Ack ack = PspClientTool.convertUpiRequest(ackStr, Ack.class);
		if(ack.getErr() == null) {
		}
	}
	
	private RespOtp prepareRespOtp(ReqOtp reqOtp) {
		RespOtp respOtp = new RespOtp();
		respOtp.setHead(reqOtp.getHead());
		respOtp.setTxn(reqOtp.getTxn());
		RespType respType = new RespType();
		respType.setResult("SUCCESS");
		respType.setReqMsgId(reqOtp.getHead().getMsgId());
		respOtp.setResp(respType);
		return respOtp;
	}

}