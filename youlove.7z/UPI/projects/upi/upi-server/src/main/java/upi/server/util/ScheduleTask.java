/**
 * 
 */
package upi.server.util;

import java.util.Date;

import org.upi.system_1_2.Ack;

import upi.sender.UpiSender;
import upi.server.process.UpiClientService;

/**
 * @author prasadj
 *
 */
public class ScheduleTask implements Runnable {

	private UpiSender upiSender;
	
	private UpiClientService upiClientService;
	
	public ScheduleTask(){
	}
	
	public ScheduleTask(UpiSender upiSender, UpiClientService upiClientService){
		this.upiSender = upiSender;
		setUpiClientService(upiClientService);
	}
	
	@Override
	public void run() {
		
		try {
			Thread.sleep(500);
		} catch (InterruptedException e) {
			throw new RuntimeException(e.getMessage());
		}
		upiSender.send(upiClientService);
	}

	public Ack prepareAckData(String serviceName, String msgId) {
		Ack ack = new Ack();
		ack.setApi(serviceName);
		ack.setReqMsgId(msgId);
		ack.setTs(DateUtil.getUpiDateStrFormat(new Date()));
		return ack;
	}
	
	public UpiClientService getUpiClientService() {
		return upiClientService;
	}

	public void setUpiClientService(UpiClientService upiClientService) {
		this.upiClientService = upiClientService;
	}

}