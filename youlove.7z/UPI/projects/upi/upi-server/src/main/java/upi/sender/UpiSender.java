/**
 * 
 */
package upi.sender;

import upi.server.process.UpiClientService;

/**
 * @author prasadj
 *
 */
public interface UpiSender {

	void send(UpiClientService upiClientService);
	
}