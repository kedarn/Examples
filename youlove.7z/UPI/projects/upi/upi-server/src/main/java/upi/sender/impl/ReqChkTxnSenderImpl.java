/**
 * 
 */
package upi.sender.impl;

import org.upi.system_1_2.Ack;
import org.upi.system_1_2.ReqChkTxn;
import org.upi.system_1_2.RespChkTxn;
import org.upi.system_1_2.RespType;

import upi.sender.UpiSender;
import upi.server.constants.ServiceNames;
import upi.server.process.UpiClientService;
import upi.server.util.PspClientTool;

/**
 * @author prasadj
 *
 */
public class ReqChkTxnSenderImpl implements UpiSender {

	private ReqChkTxn reqChkTxn;
	
	public ReqChkTxnSenderImpl(ReqChkTxn reqChkTxn){
		this.reqChkTxn = reqChkTxn;
	}
	
	@Override
	public void send(UpiClientService upiClientService) {
		RespChkTxn respChkTxn = prepareRespchkTxn(reqChkTxn);
		String respListAccStr = upiClientService.requestToString(respChkTxn);
		String ackStr = upiClientService.callPsp(respListAccStr, reqChkTxn.getTxn().getRefUrl(), ServiceNames.RESP_LIST_KEYS, 
				respChkTxn.getHead().getVer(), respChkTxn.getTxn().getId());
		Ack ack = PspClientTool.convertUpiRequest(ackStr, Ack.class);
		if(ack.getErr() == null) {
		}
	}
	
	private RespChkTxn prepareRespchkTxn(ReqChkTxn reqChkTxn){
		RespChkTxn  respChkTxn = new RespChkTxn(); 
		respChkTxn.setHead(reqChkTxn.getHead());
		respChkTxn.setTxn(reqChkTxn.getTxn());
		RespType respType = new RespType();
		respType.setResult("SUCCESS");
		respType.setReqMsgId(reqChkTxn.getHead().getMsgId());
		respChkTxn.setResp(respType);
		return 	respChkTxn;
	}

}