/**
 * 
 */
package upi.process.factory.impl;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.upi.system_1_2.RespListAccPvd;

import upi.process.factory.UpiCoreHandler;
import upi.server.constants.ServiceNames;
import upi.server.process.UpiClientService;
import upi.server.util.PspClientTool;

/**
 * @author prasadj
 *
 */
@Component("respListAccPvdHandler")
public class RespListAccPvdHandler extends UpiCoreHandler {

	private static final Logger LOGGER = Logger.getLogger(RespListAccPvdHandler.class.getName());
	
	@Autowired
	private UpiClientService upiClientService;
	
	public RespListAccPvdHandler(){
	}
	
	@Override
	public String handleProcess(String upiData) {
		LOGGER.debug("RespListAccPvdHandler.handleProcess");
		RespListAccPvd rpr = PspClientTool.convertUpiRequest(upiData, RespListAccPvd.class);
		return upiClientService.requestToString(prepareAckObject(ServiceNames.RESP_LIST_ACC_PVD, rpr.getHead().getMsgId(), null));
	}

}