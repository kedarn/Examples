/**
 * 
 */
package upi.process.factory.impl;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.upi.system_1_2.RespListAccount;

import upi.process.factory.UpiCoreHandler;
import upi.server.constants.ServiceNames;
import upi.server.process.UpiClientService;
import upi.server.util.PspClientTool;

/**
 * @author prasadj
 *
 */
@Component("respListAccountHandler")
public class RespListAccountHandler extends UpiCoreHandler {

	private static final Logger LOGGER = Logger.getLogger(RespListAccountHandler.class.getName());
	
	@Autowired
	private UpiClientService upiClientService;

	public RespListAccountHandler(){
	}
	
	@Override
	public String handleProcess(String upiData) {
		LOGGER.debug("RespListAccountHandler.handleProcess");
		RespListAccount rpr = PspClientTool.convertUpiRequest(upiData, RespListAccount.class);
		return upiClientService.requestToString(prepareAckObject(ServiceNames.RESP_LIST_ACCOUNT, rpr.getHead().getMsgId(), null));
	}

}