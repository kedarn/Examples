package upi.server.process;

import java.util.List;

import org.upi.system_1_2.RespListAccPvd.AccPvdList.AccPvd;
import org.upi.system_1_2.RespListAccount.AccountList.Account;


public interface UpiClientService {

	boolean isDigitalSignatureValid(String data) throws Exception;
	
	String requestToString(Object object);

	String callPsp(String data, String refUrl, String api, String version, String txnId);
	
	List<AccPvd> getAccountProviders();
	
	List<Account> getAccounts(String ifsc, String customerName);
	
}