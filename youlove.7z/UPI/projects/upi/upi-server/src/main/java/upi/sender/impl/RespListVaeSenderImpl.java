/**
 * 
 */
package upi.sender.impl;

import org.upi.system_1_2.RespListVae;

import upi.sender.UpiSender;
import upi.server.process.UpiClientService;

/**
 * @author prasadj
 *
 */
public class RespListVaeSenderImpl implements UpiSender {

	private RespListVae respListVae;
	
	public RespListVaeSenderImpl(RespListVae respListVae){
		this.respListVae = respListVae;
	}

	@Override
	public void send(UpiClientService upiClientService) {
		// TODO Need to do R & D
	}

}