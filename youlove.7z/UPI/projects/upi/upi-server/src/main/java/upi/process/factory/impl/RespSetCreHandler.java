/**
 * 
 */
package upi.process.factory.impl;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.upi.system_1_2.RespSetCre;

import upi.process.factory.UpiCoreHandler;
import upi.server.constants.ServiceNames;
import upi.server.process.UpiClientService;
import upi.server.util.PspClientTool;

/**
 * @author prasadj
 *
 */
@Component("respSetCreHandler")
public class RespSetCreHandler extends UpiCoreHandler {

	private static final Logger LOGGER = Logger.getLogger(RespSetCreHandler.class.getName());
	
	@Autowired
	private UpiClientService upiClientService;

	public RespSetCreHandler(){
	}
	
	@Override
	public String handleProcess(String upiData) {
		LOGGER.debug("RespSetCreHandler.handleProcess");
		RespSetCre rpr = PspClientTool.convertUpiRequest(upiData, RespSetCre.class);
		return upiClientService.requestToString(prepareAckObject(ServiceNames.RESP_SET_CRE, rpr.getHead().getMsgId(), null));
	}

}