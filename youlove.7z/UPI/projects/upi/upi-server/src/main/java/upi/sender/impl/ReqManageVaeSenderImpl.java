/**
 * 
 */
package upi.sender.impl;

import org.upi.system_1_2.ReqManageVae;

import upi.sender.UpiSender;
import upi.server.process.UpiClientService;

/**
 * @author prasadj
 *
 */
public class ReqManageVaeSenderImpl implements UpiSender {

	private ReqManageVae reqManageVae;
	
	public ReqManageVaeSenderImpl(ReqManageVae reqManageVae){
		this.reqManageVae = reqManageVae;
	}

	@Override
	public void send(UpiClientService upiClientService) {
		// TODO Need to do R & D
	}

}