package upi.server.constants;

public enum VirtualPayerType {

	PERSON,
	ENTITY;
	
	public static VirtualPayerType getPayerType(String payerType){
		if(payerType == null){
			return null;
		}
		else if (PERSON.name().equals(payerType)){
			return PERSON;
		}
		else if (ENTITY.name().equals(payerType)){
			return ENTITY;
		}		
		else {
			return null;
		}
	}
}