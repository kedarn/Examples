/**
 * 
 */
package upi.sender.impl;

import java.util.List;

import org.upi.system_1_2.Ack;
import org.upi.system_1_2.ReqListAccPvd;
import org.upi.system_1_2.RespListAccPvd;
import org.upi.system_1_2.RespListAccPvd.AccPvdList;
import org.upi.system_1_2.RespListAccPvd.AccPvdList.AccPvd;
import org.upi.system_1_2.RespType;

import upi.sender.UpiSender;
import upi.server.constants.ServiceNames;
import upi.server.process.UpiClientService;
import upi.server.util.PspClientTool;

/**
 * @author prasadj
 *
 */
public class ReqListAccPvdSenderImpl implements UpiSender {

	private ReqListAccPvd reqListAccPvd;
	
	public ReqListAccPvdSenderImpl(ReqListAccPvd reqListAccPvd){
		this.reqListAccPvd = reqListAccPvd;
	}

	@Override
	public void send(UpiClientService upiClientService) {
		RespListAccPvd respListAccPvd = prepareRespListAccPvd(reqListAccPvd, upiClientService);
		String respListAccStr = upiClientService.requestToString(respListAccPvd);
		String ackStr = upiClientService.callPsp(respListAccStr, reqListAccPvd.getTxn().getRefUrl(), ServiceNames.RESP_LIST_ACC_PVD, respListAccPvd.getHead().getVer(), respListAccPvd.getTxn().getId());
		Ack ack = PspClientTool.convertUpiRequest(ackStr, Ack.class);
		if(ack.getErr() == null) {
		}
	}
	
	private RespListAccPvd prepareRespListAccPvd(ReqListAccPvd reqListAccPvd, UpiClientService upiClientService){
		RespListAccPvd respListAccPvd = new RespListAccPvd();
		respListAccPvd.setHead(reqListAccPvd.getHead());
		respListAccPvd.setTxn(reqListAccPvd.getTxn());
		RespType respType = new RespType();
		respType.setResult("SUCCESS");
		respType.setReqMsgId(reqListAccPvd.getHead().getMsgId());
		respListAccPvd.setResp(respType);
		AccPvdList accPvdList = new AccPvdList();
		List<AccPvd> providers = upiClientService.getAccountProviders();
		accPvdList.getAccPvd().addAll(providers);
		respListAccPvd.setAccPvdList(accPvdList);
		return respListAccPvd;
	}
	
}