/**
 * 
 */
package upi.process.factory.impl;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.upi.system_1_2.ReqListAccPvd;

import upi.process.factory.UpiCoreHandler;
import upi.sender.UpiSender;
import upi.sender.impl.ReqListAccPvdSenderImpl;
import upi.server.constants.ServiceNames;
import upi.server.process.UpiClientService;
import upi.server.util.PspClientTool;
import upi.server.util.ScheduleTask;

/**
 * @author prasadj
 *
 */
@Component("reqListAccPvdHandler")
public class ReqListAccPvdHandler extends UpiCoreHandler {

	private static final Logger LOGGER = Logger.getLogger(ReqListAccPvdHandler.class.getName());
	
	@Autowired
	private UpiClientService upiClientService;
	
	public ReqListAccPvdHandler(){
	}
	
	@Override
	public String handleProcess(String upiData) {
		LOGGER.debug("ReqListAccPvdHandler.handleProcess");
		ReqListAccPvd rpr = PspClientTool.convertUpiRequest(upiData, ReqListAccPvd.class);
		UpiSender upiSender = new ReqListAccPvdSenderImpl(rpr);
		new Thread( new ScheduleTask(upiSender, upiClientService)).start();
		return upiClientService.requestToString(prepareAckObject(ServiceNames.REQ_LIST_ACC_PVD, rpr.getHead().getMsgId(), null));
	}

}