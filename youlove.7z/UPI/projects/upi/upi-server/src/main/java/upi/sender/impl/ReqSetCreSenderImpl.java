/**
 * 
 */
package upi.sender.impl;

import org.upi.system_1_2.Ack;
import org.upi.system_1_2.ReqSetCre;
import org.upi.system_1_2.RespSetCre;
import org.upi.system_1_2.RespType;

import upi.sender.UpiSender;
import upi.server.constants.ServiceNames;
import upi.server.process.UpiClientService;
import upi.server.util.PspClientTool;

/**
 * @author prasadj
 *
 */
public class ReqSetCreSenderImpl implements UpiSender {

	private ReqSetCre reqSetCre;
	
	public ReqSetCreSenderImpl(ReqSetCre reqSetCre){
		this.reqSetCre = reqSetCre;
	}

	@Override
	public void send(UpiClientService upiClientService) {
		// TODO Send RespSetCre to Initiator
		RespSetCre respSetCre = prepareRespSetCre(reqSetCre);
		String respSetCreStr = upiClientService.requestToString(respSetCre);
		String ackStr = upiClientService.callPsp(respSetCreStr, reqSetCre.getTxn().getRefUrl(), ServiceNames.RESP_LIST_ACCOUNT, 
				respSetCre.getHead().getVer(), respSetCre.getTxn().getId());
		Ack ack = PspClientTool.convertUpiRequest(ackStr, Ack.class);
		if(ack.getErr() == null) {
		}
	}
	
	private RespSetCre prepareRespSetCre(ReqSetCre reqSetCre){
		RespSetCre respSetCre = new RespSetCre();
		respSetCre.setHead(reqSetCre.getHead());
		respSetCre.setTxn(reqSetCre.getTxn());
		RespType respType = new RespType();
		respType.setResult("SUCCESS");
		respType.setReqMsgId(reqSetCre.getHead().getMsgId());
		respSetCre.setResp(respType);
		return respSetCre;
	}

}