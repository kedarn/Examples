/**
 * 
 */
package upi.process.factory.impl;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.upi.system_1_2.RespValAdd;

import upi.process.factory.UpiCoreHandler;
import upi.server.constants.ServiceNames;
import upi.server.process.UpiClientService;
import upi.server.util.PspClientTool;

/**
 * @author prasadj
 *
 */
@Component("respValAddHandler")
public class RespValAddHandler extends UpiCoreHandler {

	private static final Logger LOGGER = Logger.getLogger(RespValAddHandler.class.getName());
	
	@Autowired
	private UpiClientService upiClientService;

	public RespValAddHandler(){
	}
	
	@Override
	public String handleProcess(String upiData) {
		LOGGER.debug("RespValAddHandler.handleProcess");
		RespValAdd rpr = PspClientTool.convertUpiRequest(upiData, RespValAdd.class);
		return upiClientService.requestToString(prepareAckObject(ServiceNames.RESP_VAL_ADD, rpr.getHead().getMsgId(), null));
	}

}