/**
 * 
 */
package upi.process.factory.impl;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.upi.system_1_2.RespChkTxn;

import upi.process.factory.UpiCoreHandler;
import upi.server.constants.ServiceNames;
import upi.server.process.UpiClientService;
import upi.server.util.PspClientTool;

/**
 * @author prasadj
 *
 */
@Component("respChkTxnHandler")
public class RespChkTxnHandler extends UpiCoreHandler {

	private static final Logger LOGGER = Logger.getLogger(RespChkTxnHandler.class.getName());
	
	@Autowired
	private UpiClientService upiClientService;

	public RespChkTxnHandler(){
	}
	
	@Override
	public String handleProcess(String upiData) {
		LOGGER.debug("RespChkTxnHandler.handleProcess");
		RespChkTxn rpr = PspClientTool.convertUpiRequest(upiData, RespChkTxn.class);
		return upiClientService.requestToString(prepareAckObject(ServiceNames.RESP_CHK_TXN, rpr.getHead().getMsgId(), null));
	}

}