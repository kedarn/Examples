/**
 * 
 */
package upi.sender.impl;

import org.upi.system_1_2.Ack;
import org.upi.system_1_2.ReqHbt;
import org.upi.system_1_2.RespHbt;
import org.upi.system_1_2.RespType;

import upi.sender.UpiSender;
import upi.server.constants.ServiceNames;
import upi.server.process.UpiClientService;
import upi.server.util.PspClientTool;

/**
 * @author prasadj
 *
 */
public class ReqHbtSenderImpl implements UpiSender {

	private ReqHbt reqHbt;
	
	public ReqHbtSenderImpl(ReqHbt reqHbt){
		this.reqHbt = reqHbt;
	}
	
	@Override
	public void send(UpiClientService upiClientService) {
		RespHbt respHbt = prepareRespHbt(reqHbt);
		String respHbtStr = upiClientService.requestToString(respHbt);
		String ackStr = upiClientService.callPsp(respHbtStr, reqHbt.getTxn().getRefUrl(), ServiceNames.RESP_HBT, respHbt.getHead().getVer(), respHbt.getTxn().getId());
		Ack ack = PspClientTool.convertUpiRequest(ackStr, Ack.class);
		if(ack.getErr() == null) {
		}		
	}

	private RespHbt prepareRespHbt(ReqHbt reqHbt) {
		RespHbt respHbt = new RespHbt();
		RespType respType = new RespType();
		respType.setResult("SUCCESS");
		respType.setReqMsgId(reqHbt.getHead().getMsgId());
		respHbt.setHead(reqHbt.getHead());
		respHbt.setTxn(reqHbt.getTxn());
		respHbt.setResp(respType);
		return respHbt;
	}
	
}