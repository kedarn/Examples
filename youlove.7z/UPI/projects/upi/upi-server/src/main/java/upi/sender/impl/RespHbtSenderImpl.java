/**
 * 
 */
package upi.sender.impl;

import org.upi.system_1_2.RespHbt;

import upi.sender.UpiSender;
import upi.server.process.UpiClientService;

/**
 * @author prasadj
 *
 */
public class RespHbtSenderImpl implements UpiSender {

	private RespHbt respHbt;
	
	public RespHbtSenderImpl(RespHbt respHbt){
		this.respHbt = respHbt;
	}
	
	@Override
	public void send(UpiClientService upiClientService) {
		// TODO Nothing to do
	}

}