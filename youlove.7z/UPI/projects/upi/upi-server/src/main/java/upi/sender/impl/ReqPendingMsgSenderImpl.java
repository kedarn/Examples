/**
 * 
 */
package upi.sender.impl;

import org.upi.system_1_2.ReqPendingMsg;

import upi.sender.UpiSender;
import upi.server.process.UpiClientService;

/**
 * @author prasadj
 *
 */
public class ReqPendingMsgSenderImpl implements UpiSender {

	private ReqPendingMsg reqPendingMsg;
	
	public ReqPendingMsgSenderImpl(ReqPendingMsg reqPendingMsg){
		this.reqPendingMsg = reqPendingMsg;
	}

	@Override
	public void send(UpiClientService upiClientService) {
		// TODO Send RespPendingMsg to Initiator 
		//TODO: we can do it later(less priority)
	}

}