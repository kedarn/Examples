/**
 * 
 */
package upi.sender.impl;

import org.upi.system_1_2.Ack;
import org.upi.system_1_2.ReqRegMob;
import org.upi.system_1_2.RespRegMob;
import org.upi.system_1_2.RespType;

import upi.sender.UpiSender;
import upi.server.constants.ServiceNames;
import upi.server.process.UpiClientService;
import upi.server.util.PspClientTool;

/**
 * @author prasadj
 *
 */
public class ReqRegMobSenderImpl implements UpiSender {

	private ReqRegMob reqRegMob;
	
	public ReqRegMobSenderImpl(ReqRegMob reqRegMob){
		this.reqRegMob = reqRegMob;
	}

	@Override
	public void send(UpiClientService upiClientService) {
		RespRegMob respRegMobile = prepareRespRegMob(reqRegMob);
		String respRegMobileStr = upiClientService.requestToString(respRegMobile);
		String ackStr = upiClientService.callPsp(respRegMobileStr, reqRegMob.getTxn().getRefUrl(), ServiceNames.RESP_REG_MOB, 
				respRegMobile.getHead().getVer(), respRegMobile.getTxn().getId());
		Ack ack = PspClientTool.convertUpiRequest(ackStr, Ack.class);
		if(ack.getErr() == null) {
		}
	}
	
	private RespRegMob prepareRespRegMob(ReqRegMob reqRegMob) {	
		RespRegMob respRegMob = new RespRegMob();
		respRegMob.setHead(reqRegMob.getHead());
		respRegMob.setTxn(reqRegMob.getTxn());
		RespType respType = new RespType();
		respType.setResult("SUCCESS");
		respType.setReqMsgId(reqRegMob.getHead().getMsgId());
		respRegMob.setResp(respType);
		return respRegMob;
	}

}