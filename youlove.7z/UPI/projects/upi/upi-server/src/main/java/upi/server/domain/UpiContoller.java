/**
 * 
 */
package upi.server.domain;

import javax.servlet.http.HttpServletRequest;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import upi.server.process.UpiProcessor;
import upi.server.util.JsonUtil;

/**
 * @author manasp
 *
 */
@RestController
@RequestMapping("/")
public class UpiContoller {

	private static final Logger LOGGER = Logger.getLogger(UpiContoller.class.getName());
	
	@Autowired
	private UpiProcessor pspRequestProcessor;
	
	@RequestMapping(value = "/{api}/{version}/urn:txnid:{txnId}", method = RequestMethod.POST, headers = "Accept=application/xml", produces = "application/xml")
	@ResponseBody 
	public String processUpiClientRequest(HttpServletRequest request, @PathVariable String api, @PathVariable String version, @PathVariable String txnId) {
		LOGGER.info("Service request from PSP: " + api);
		return pspRequestProcessor.processRequest(api, JsonUtil.readJsonData(request));
	}
	
}