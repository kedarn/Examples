/**
 * 
 */
package upi.server.util;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

import javax.xml.bind.DatatypeConverter;

/**
 * @author prasadj
 *
 */
public class DateUtil {

	private DateUtil(){
	}
	
	public static String getUpiDateStrFormat(Date date){
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'");
		return sdf.format(date);
	}
	
	public static Date getUpiDateStrFormat(String dateString){
		Calendar cal = DatatypeConverter.parseDateTime(dateString);
		return cal.getTime();
	}
	
	public static String convertDateToString(Date date){
		String reportDate = null;
		DateFormat df = new SimpleDateFormat("MM/dd/yyyy");
		if(date != null) {
			reportDate = df.format(date);
		}
		return reportDate;
	}
	
	public static Date convertStringToDate(String dateStr){
		
		SimpleDateFormat formatter = new SimpleDateFormat("MM/dd/yyyy");
	 
		try {
			if(dateStr != null && !"".equals(dateStr)){
				return formatter.parse(dateStr);
			}
		} 
		catch (Exception e) {
			return null;
		}
		return null;
	}
	
}