/**
 * 
 */
package upi.sender.impl;

import java.util.List;

import org.upi.system_1_2.Ack;
import org.upi.system_1_2.PayeeType;
import org.upi.system_1_2.PayeesType;
import org.upi.system_1_2.PayerType;
import org.upi.system_1_2.Ref;
import org.upi.system_1_2.RefType;
import org.upi.system_1_2.ReqTxnConfirmation;
import org.upi.system_1_2.RespAuthDetails;
import org.upi.system_1_2.RespPay;
import org.upi.system_1_2.RespPay.Resp;
import org.upi.system_1_2.ResultType;
import org.upi.system_1_2.TxnConfDtl;

import upi.sender.UpiSender;
import upi.server.constants.ServiceNames;
import upi.server.process.UpiClientService;
import upi.server.util.PspClientTool;

/**
 * @author prasadj
 *
 */
public class RespAuthDetailsSenderImpl implements UpiSender {

	private RespAuthDetails respAuthDetails;
	
	public RespAuthDetailsSenderImpl(RespAuthDetails respAuthDetails){
		this.respAuthDetails = respAuthDetails;
	}
	
	@Override
	public void send(UpiClientService upiClientService) {
		// TODO has to send the RespPay to Initiator and ReqTxnConfirmation to reciver psp
		RespPay respPay = prepareRespPay(respAuthDetails);
		String respPayStr = upiClientService.requestToString(respPay);
		String ackStr = upiClientService.callPsp(respPayStr, respAuthDetails.getTxn().getRefUrl(), ServiceNames.RESP_PAY, 
				respPay.getHead().getVer(), respPay.getTxn().getId());
		Ack ack = PspClientTool.convertUpiRequest(ackStr, Ack.class);
		if(ack.getErr() == null) {
		}
		
		ReqTxnConfirmation reqTxnConfirmation = prepareReqTxnConfirmation(respAuthDetails);
		String respRegMobileStr = upiClientService.requestToString(reqTxnConfirmation);
		String ackStrForConf = upiClientService.callPsp(respRegMobileStr, respAuthDetails.getTxn().getRefUrl(), ServiceNames.REQ_TXN_CONFIRMATION, 
				reqTxnConfirmation.getHead().getVer(), reqTxnConfirmation.getTxn().getId());
		Ack ackForTxnCon = PspClientTool.convertUpiRequest(ackStrForConf, Ack.class);
		if(ackForTxnCon.getErr() == null) {
		}
	}
	
	private RespPay prepareRespPay(RespAuthDetails respAuthDetails) {	
		
		Resp resp = new Resp();
		resp.setReqMsgId(respAuthDetails.getHead().getMsgId());
		resp.setResult(ResultType.SUCCESS);
		
		List<Ref> refs = resp.getRef();
		refs.add(preparePayerRefData(respAuthDetails.getPayer()));
		refs.add(preparePayeeRefData(respAuthDetails.getPayees()));
		
		RespPay respPay = new RespPay();
		respPay.setHead(respAuthDetails.getHead());
		respPay.setTxn(respAuthDetails.getTxn());
		respPay.setResp(resp);
		return respPay;
	}
	
	//TODO need to remove hardcoded values
	private Ref preparePayeeRefData(PayeesType payeesType){
		PayeeType payeeType = payeesType.getPayee().get(0);
		Ref ref = new Ref();
		ref.setAddr(payeeType.getAddr());
		ref.setType(RefType.PAYEE);
		ref.setRespCode("00");
		ref.setSeqNum(payeeType.getSeqNum());
		ref.setSettAmount(payeeType.getAmount().getValue());
		ref.setSettCurrency(payeeType.getAmount().getCurr());
		ref.setRegName(payeeType.getName());
		ref.setApprovalNum("9399389827");
		return ref;
	}
	
	//TODO need to remove hardcoded values
	private Ref preparePayerRefData(PayerType payerType){
		Ref ref = new Ref();
		ref.setAddr(payerType.getAddr());
		ref.setType(RefType.PAYER);
		ref.setRespCode("00");
		ref.setSeqNum(payerType.getSeqNum());
		ref.setSettAmount(payerType.getAmount().getValue());
		ref.setSettCurrency(payerType.getAmount().getCurr());
		ref.setRegName(payerType.getName());
		ref.setApprovalNum("9399389827");
		return ref;
	}
	
	private ReqTxnConfirmation prepareReqTxnConfirmation(RespAuthDetails respAuthDetails) {		
		TxnConfDtl txnConfDtl = new TxnConfDtl();
		txnConfDtl.setNote(respAuthDetails.getTxn().getNote());
		txnConfDtl.setOrgErrCode("");
		txnConfDtl.setOrgStatus("SUCCESS");
		txnConfDtl.setType(respAuthDetails.getTxn().getType());
		
		ReqTxnConfirmation reqTxnCon = new ReqTxnConfirmation();
		reqTxnCon.setHead(respAuthDetails.getHead());
		reqTxnCon.setTxn(respAuthDetails.getTxn());
		reqTxnCon.setTxnConfirmation(txnConfDtl);
		return reqTxnCon;
	}
	
}