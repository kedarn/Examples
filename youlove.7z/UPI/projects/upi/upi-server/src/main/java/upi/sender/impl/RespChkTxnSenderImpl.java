/**
 * 
 */
package upi.sender.impl;

import org.upi.system_1_2.RespChkTxn;

import upi.sender.UpiSender;
import upi.server.process.UpiClientService;

/**
 * @author prasadj
 *
 */
public class RespChkTxnSenderImpl implements UpiSender {

	private RespChkTxn respChkTxn;
	
	public RespChkTxnSenderImpl(RespChkTxn respChkTxn){
		this.respChkTxn = respChkTxn;
	}
	
	@Override
	public void send(UpiClientService upiClientService) {
		// TODO Nothing to do
	}

}