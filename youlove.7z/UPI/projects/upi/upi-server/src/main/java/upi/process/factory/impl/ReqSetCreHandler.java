/**
 * 
 */
package upi.process.factory.impl;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.upi.system_1_2.ReqSetCre;

import upi.process.factory.UpiCoreHandler;
import upi.sender.UpiSender;
import upi.sender.impl.ReqSetCreSenderImpl;
import upi.server.constants.ServiceNames;
import upi.server.process.UpiClientService;
import upi.server.util.PspClientTool;
import upi.server.util.ScheduleTask;

/**
 * @author prasadj
 *
 */
@Component("reqSetCreHandler")
public class ReqSetCreHandler extends UpiCoreHandler {

	private static final Logger LOGGER = Logger.getLogger(ReqSetCreHandler.class.getName());
	
	@Autowired
	private UpiClientService upiClientService;

	public ReqSetCreHandler(){
	}
	
	@Override
	public String handleProcess(String upiData) {
		LOGGER.debug("ReqSetCreHandler.handleProcess");
		ReqSetCre rpr = PspClientTool.convertUpiRequest(upiData, ReqSetCre.class);
		UpiSender upiSender = new ReqSetCreSenderImpl(rpr);
		new Thread( new ScheduleTask(upiSender, upiClientService)).start();
		return upiClientService.requestToString(prepareAckObject(ServiceNames.REQ_SET_CRE, rpr.getHead().getMsgId(), null));
	}

}