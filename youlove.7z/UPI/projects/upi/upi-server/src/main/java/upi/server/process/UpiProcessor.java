/**
 * 
 */
package upi.server.process;


/**
 * @author manasp
 *
 */
public interface UpiProcessor {

	String processRequest(String api, String data);
	
}