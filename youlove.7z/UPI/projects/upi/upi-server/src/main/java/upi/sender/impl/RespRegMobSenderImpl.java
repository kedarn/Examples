/**
 * 
 */
package upi.sender.impl;

import org.upi.system_1_2.RespRegMob;

import upi.sender.UpiSender;
import upi.server.process.UpiClientService;

/**
 * @author prasadj
 *
 */
public class RespRegMobSenderImpl implements UpiSender {

	private RespRegMob respRegMob;
	
	public RespRegMobSenderImpl(RespRegMob respRegMob){
		this.respRegMob = respRegMob;
	}

	@Override
	public void send(UpiClientService upiClientService) {
		// TODO Nothing to do
	}

}