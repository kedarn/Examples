/**
 * 
 */
package upi.server.util;

import java.lang.reflect.Field;
import java.util.HashMap;
import java.util.Map;

import org.upi.system_1_2.HeadType;
import org.upi.system_1_2.ReqAuthDetails;
import org.upi.system_1_2.ReqBalEnq;
import org.upi.system_1_2.ReqChkTxn;
import org.upi.system_1_2.ReqHbt;
import org.upi.system_1_2.ReqListAccPvd;
import org.upi.system_1_2.ReqListAccount;
import org.upi.system_1_2.ReqListKeys;
import org.upi.system_1_2.ReqListPsp;
import org.upi.system_1_2.ReqListVae;
import org.upi.system_1_2.ReqManageVae;
import org.upi.system_1_2.ReqOtp;
import org.upi.system_1_2.ReqPay;
import org.upi.system_1_2.ReqPendingMsg;
import org.upi.system_1_2.ReqRegMob;
import org.upi.system_1_2.ReqSetCre;
import org.upi.system_1_2.ReqTxnConfirmation;
import org.upi.system_1_2.ReqValAdd;
import org.upi.system_1_2.RespAuthDetails;
import org.upi.system_1_2.RespBalEnq;
import org.upi.system_1_2.RespChkTxn;
import org.upi.system_1_2.RespHbt;
import org.upi.system_1_2.RespListAccPvd;
import org.upi.system_1_2.RespListAccount;
import org.upi.system_1_2.RespListKeys;
import org.upi.system_1_2.RespListPsp;
import org.upi.system_1_2.RespListVae;
import org.upi.system_1_2.RespManageVae;
import org.upi.system_1_2.RespOtp;
import org.upi.system_1_2.RespPay;
import org.upi.system_1_2.RespPendingMsg;
import org.upi.system_1_2.RespRegMob;
import org.upi.system_1_2.RespSetCre;
import org.upi.system_1_2.RespTxnConfirmation;
import org.upi.system_1_2.RespValAdd;

import upi.server.constants.ServiceNames;

/**
 * @author prasadj
 *
 */
public class UpiProcessUtility {

	private static final Map<String, String> upiHandlerBeanMap = new HashMap<String, String>();

	private static final  Map<String, Class<?>> upiRequestClassMap = new HashMap<>();
	
	static {

		upiHandlerBeanMap.put(ServiceNames.REQ_AUTH_DETAILS, "ReqAuthDetailsHandler");
		upiHandlerBeanMap.put(ServiceNames.REQ_BAL_ENQ, "ReqBalEnqHandler");
		upiHandlerBeanMap.put(ServiceNames.REQ_CHK_TXN, "ReqChkTxnHandler");
		upiHandlerBeanMap.put(ServiceNames.REQ_HBT, "ReqHbtHandler");
		upiHandlerBeanMap.put(ServiceNames.REQ_LIST_ACCOUNT, "ReqListAccountHandler");
		upiHandlerBeanMap.put(ServiceNames.REQ_LIST_ACC_PVD, "ReqListAccPvdHandler");
		upiHandlerBeanMap.put(ServiceNames.REQ_LIST_KEYS, "ReqListKeysHandler");
		upiHandlerBeanMap.put(ServiceNames.REQ_LIST_PSP, "ReqListPspHandler");
		upiHandlerBeanMap.put(ServiceNames.REQ_LIST_VAE, "ReqListVaeHandler");
		upiHandlerBeanMap.put(ServiceNames.REQ_MANAGE_VAE, "ReqManageVaeHandler");
		upiHandlerBeanMap.put(ServiceNames.REQ_OTP, "ReqOtpHandler");
		upiHandlerBeanMap.put(ServiceNames.REQ_PAY, "ReqPayHandler");
		upiHandlerBeanMap.put(ServiceNames.REQ_PENDING_MSG, "ReqPendingMsgHandler");
		upiHandlerBeanMap.put(ServiceNames.REQ_REG_MOB, "ReqRegMobHandler");
		upiHandlerBeanMap.put(ServiceNames.REQ_SET_CRE, "ReqSetCreHandler");
		upiHandlerBeanMap.put(ServiceNames.REQ_TXN_CONFIRMATION, "ReqTxnConfirmationHandler");
		upiHandlerBeanMap.put(ServiceNames.REQ_VAL_ADD, "ReqValAddHandler");
		
		upiRequestClassMap.put(ServiceNames.REQ_AUTH_DETAILS, ReqAuthDetails.class);
		upiRequestClassMap.put(ServiceNames.REQ_BAL_ENQ, ReqBalEnq.class);
		upiRequestClassMap.put(ServiceNames.REQ_CHK_TXN, ReqChkTxn.class);
		upiRequestClassMap.put(ServiceNames.REQ_HBT, ReqHbt.class);
		upiRequestClassMap.put(ServiceNames.REQ_LIST_ACCOUNT, ReqListAccount.class);
		upiRequestClassMap.put(ServiceNames.REQ_LIST_ACC_PVD, ReqListAccPvd.class);
		upiRequestClassMap.put(ServiceNames.REQ_LIST_KEYS, ReqListKeys.class);
		upiRequestClassMap.put(ServiceNames.REQ_LIST_PSP, ReqListPsp.class);
		upiRequestClassMap.put(ServiceNames.REQ_LIST_VAE, ReqListVae.class);
		upiRequestClassMap.put(ServiceNames.REQ_MANAGE_VAE, ReqManageVae.class);
		upiRequestClassMap.put(ServiceNames.REQ_OTP, ReqOtp.class);
		upiRequestClassMap.put(ServiceNames.REQ_PAY, ReqPay.class);
		upiRequestClassMap.put(ServiceNames.REQ_PENDING_MSG, ReqPendingMsg.class);
		upiRequestClassMap.put(ServiceNames.REQ_REG_MOB, ReqRegMob.class);
		upiRequestClassMap.put(ServiceNames.REQ_SET_CRE, ReqSetCre.class);
		upiRequestClassMap.put(ServiceNames.REQ_TXN_CONFIRMATION, ReqTxnConfirmation.class);
		upiRequestClassMap.put(ServiceNames.REQ_VAL_ADD, ReqValAdd.class);
		
		upiHandlerBeanMap.put(ServiceNames.RESP_AUTH_DETAILS, "RespAuthDetailsHandler");
		upiHandlerBeanMap.put(ServiceNames.RESP_BAL_ENQ, "RespBalEnqHandler");
		upiHandlerBeanMap.put(ServiceNames.RESP_CHK_TXN, "RespChkTxnHandler");
		upiHandlerBeanMap.put(ServiceNames.RESP_HBT, "RespHbtHandler");
		upiHandlerBeanMap.put(ServiceNames.RESP_LIST_ACCOUNT, "RespListAccountHandler");
		upiHandlerBeanMap.put(ServiceNames.RESP_LIST_ACC_PVD, "RespListAccPvdHandler");
		upiHandlerBeanMap.put(ServiceNames.RESP_LIST_KEYS, "RespListKeysHandler");
		upiHandlerBeanMap.put(ServiceNames.RESP_LIST_PSP, "RespListPspHandler");
		upiHandlerBeanMap.put(ServiceNames.RESP_LIST_VAE, "RespListVaeHandler");
		upiHandlerBeanMap.put(ServiceNames.RESP_MANAGE_VAE, "RespManageVaeHandler");
		upiHandlerBeanMap.put(ServiceNames.RESP_OTP, "RespOtpHandler");
		upiHandlerBeanMap.put(ServiceNames.RESP_PAY, "RespPayHandler");
		upiHandlerBeanMap.put(ServiceNames.RESP_PENDING_MSG, "RespPendingMsgHandler");
		upiHandlerBeanMap.put(ServiceNames.RESP_REG_MOB, "RespRegMobHandler");
		upiHandlerBeanMap.put(ServiceNames.RESP_SET_CRE, "RespSetCreHandler");
		upiHandlerBeanMap.put(ServiceNames.RESP_TXN_CONFIRMATION, "RespTxnConfirmationHandler");
		upiHandlerBeanMap.put(ServiceNames.RESP_VAL_ADD, "RespValAddHandler");
		
		upiRequestClassMap.put(ServiceNames.RESP_AUTH_DETAILS, RespAuthDetails.class);
		upiRequestClassMap.put(ServiceNames.RESP_BAL_ENQ, RespBalEnq.class);
		upiRequestClassMap.put(ServiceNames.RESP_CHK_TXN, RespChkTxn.class);
		upiRequestClassMap.put(ServiceNames.RESP_HBT, RespHbt.class);
		upiRequestClassMap.put(ServiceNames.RESP_LIST_ACCOUNT, RespListAccount.class);
		upiRequestClassMap.put(ServiceNames.RESP_LIST_ACC_PVD, RespListAccPvd.class);
		upiRequestClassMap.put(ServiceNames.RESP_LIST_KEYS, RespListKeys.class);
		upiRequestClassMap.put(ServiceNames.RESP_LIST_PSP, RespListPsp.class);
		upiRequestClassMap.put(ServiceNames.RESP_LIST_VAE, RespListVae.class);
		upiRequestClassMap.put(ServiceNames.RESP_MANAGE_VAE, RespManageVae.class);
		upiRequestClassMap.put(ServiceNames.RESP_OTP, RespOtp.class);
		upiRequestClassMap.put(ServiceNames.RESP_PAY, RespPay.class);
		upiRequestClassMap.put(ServiceNames.RESP_PENDING_MSG, RespPendingMsg.class);
		upiRequestClassMap.put(ServiceNames.RESP_REG_MOB, RespRegMob.class);
		upiRequestClassMap.put(ServiceNames.RESP_SET_CRE, RespSetCre.class);
		upiRequestClassMap.put(ServiceNames.RESP_TXN_CONFIRMATION, RespTxnConfirmation.class);
		upiRequestClassMap.put(ServiceNames.RESP_VAL_ADD, RespValAdd.class);

	}
	
	public static String getProcessBeanName(String serviceName){
		return upiHandlerBeanMap.get(serviceName);
	}
	
	public static String getMsgId(String data, String serviceName){
		Class<?> upiRequestClass = upiRequestClassMap.get(serviceName);
		HeadType headType = null;
		try {
			Object obj = PspClientTool.convertUpiRequest(data, Class.forName(upiRequestClass.getName()));
			Field field = obj.getClass().getDeclaredField("head");
			Class<?> targetType = field.getType();
			headType = (HeadType)targetType.newInstance();
		} catch (Exception e) {
			throw new RuntimeException(e.getMessage());
		}
		return headType.getMsgId();
	}
	
}