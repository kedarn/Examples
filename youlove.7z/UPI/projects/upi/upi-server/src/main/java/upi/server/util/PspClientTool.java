package upi.server.util;

import java.io.StringReader;

import javax.xml.bind.JAXB;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import org.w3c.dom.Document;
import org.xml.sax.InputSource;

/**
 * @author manasp
 *
 */
public class PspClientTool {

	private PspClientTool(){
	}
	
	public static <T> T convertUpiRequest(String response, Class<T> className){
		return JAXB.unmarshal(new StringReader(response), className);
	}
	
	 public static Document convertStringToDocument(String xmlStr) {
    	 DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
    	 factory.setNamespaceAware(true); 
         DocumentBuilder builder;
         try  {
             builder = factory.newDocumentBuilder();
             return builder.parse( new InputSource( new StringReader( xmlStr ) ) );
         } catch (Exception e) {
        	 throw new RuntimeException(e.getMessage());
         }
    }
	
}