package upi.server.process;


/**
 * @author prasadj
 *
 */
public interface PropertyReader {

	void load(); 
	
	String getValue(String propKey);
	
	String getSignerFilePath();
	
	String getCertificateFilePath();
	
	String getAccountProviderPath();
	
	String getBankAccountsPath();
	
}