/**
 * 
 */
package upi.process.factory.impl;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.upi.system_1_2.ReqBalEnq;

import upi.process.factory.UpiCoreHandler;
import upi.sender.UpiSender;
import upi.sender.impl.ReqBalEnqSenderImpl;
import upi.server.constants.ServiceNames;
import upi.server.process.UpiClientService;
import upi.server.util.PspClientTool;
import upi.server.util.ScheduleTask;

/**
 * @author prasadj
 *
 */
@Component("reqBalEnqHandler")
public class ReqBalEnqHandler extends UpiCoreHandler {

	private static final Logger LOGGER = Logger.getLogger(ReqBalEnqHandler.class.getName());

	@Autowired
	private UpiClientService upiClientService;
	
	public ReqBalEnqHandler(){
	}

	@Override
	public String handleProcess(String pspData) {
		LOGGER.debug("ReqBalEnqHandler.handleProcess");
		ReqBalEnq rpr = PspClientTool.convertUpiRequest(pspData, ReqBalEnq.class);
		UpiSender upiSender = new ReqBalEnqSenderImpl(rpr);
		new Thread( new ScheduleTask(upiSender, upiClientService)).start();
		return upiClientService.requestToString(prepareAckObject(ServiceNames.REQ_BAL_ENQ, rpr.getHead().getMsgId(), null));

	}

}