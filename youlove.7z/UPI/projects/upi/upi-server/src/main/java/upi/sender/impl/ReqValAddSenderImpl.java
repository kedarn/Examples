/**
 * 
 */
package upi.sender.impl;

import org.upi.system_1_2.ReqValAdd;

import upi.sender.UpiSender;
import upi.server.process.UpiClientService;

/**
 * @author prasadj
 *
 */
public class ReqValAddSenderImpl implements UpiSender {

	private ReqValAdd reqValAdd;
	
	public ReqValAddSenderImpl(ReqValAdd reqValAdd){
		this.reqValAdd = reqValAdd;
	}

	@Override
	public void send(UpiClientService upiClientService) {
		// TODO Nothing to do
	}

}