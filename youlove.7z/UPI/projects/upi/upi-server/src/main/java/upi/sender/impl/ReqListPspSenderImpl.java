/**
 * 
 */
package upi.sender.impl;

import org.upi.system_1_2.Ack;
import org.upi.system_1_2.ActiveType;
import org.upi.system_1_2.ReqListPsp;
import org.upi.system_1_2.RespListPsp;
import org.upi.system_1_2.RespListPsp.PspList;
import org.upi.system_1_2.RespListPsp.PspList.Psp;
import org.upi.system_1_2.RespType;

import upi.sender.UpiSender;
import upi.server.constants.ServiceNames;
import upi.server.process.UpiClientService;
import upi.server.util.PspClientTool;

/**
 * @author prasadj
 *
 */
public class ReqListPspSenderImpl implements UpiSender {

	private ReqListPsp reqListPsp;
	
	public ReqListPspSenderImpl(ReqListPsp reqListPsp){
		this.reqListPsp = reqListPsp;
	}

	@Override
	public void send(UpiClientService upiClientService) {
		RespListPsp respListPsp = prepareRespListPsp(reqListPsp);
		String respListpspStr = upiClientService.requestToString(respListPsp);
		String ackStr = upiClientService.callPsp(respListpspStr, reqListPsp.getTxn().getRefUrl(), ServiceNames.RESP_LIST_ACCOUNT, 
				respListPsp.getHead().getVer(), respListPsp.getTxn().getId());
		Ack ack = PspClientTool.convertUpiRequest(ackStr, Ack.class);
		if(ack.getErr() == null) {
		}
	}
	
	private RespListPsp prepareRespListPsp(ReqListPsp reqListPsp ){
		RespListPsp repsListPsp = new RespListPsp();
		repsListPsp.setHead(reqListPsp.getHead());
		repsListPsp.setTxn(reqListPsp.getTxn());
		RespType respType = new RespType();
		respType.setResult("SUCCESS");
		respType.setReqMsgId(reqListPsp.getHead().getMsgId());
		repsListPsp.setResp(respType);
		repsListPsp.setPspList(preparePspList(reqListPsp.getHead().getOrgId()));
		return repsListPsp;
	}
	
	//TODO need to move into file
	private PspList preparePspList(String orgID){
		PspList pspList =  new PspList();
		 Psp psp = new Psp();
		 psp.setName("HDFC");
		 psp.setCodes("hdfcgold,hdfcsliver");
		 psp.setActive(ActiveType.Y);
		 pspList.getPsp().add(psp);
		 Psp psp2 = new Psp();
		 psp2.setName("ICICI");
		 psp2.setCodes("icici,iciciwallet");
		 psp2.setActive(ActiveType.Y);
		 pspList.getPsp().add(psp2);
		return pspList;
	}

}