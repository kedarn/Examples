/**
 * 
 */
package upi.sender.impl;

import org.upi.system_1_2.ReqAuthDetails;

import upi.sender.UpiSender;
import upi.server.process.UpiClientService;

/**
 * @author prasadj
 *
 */
public class ReqAuthDetailsSenderImpl implements UpiSender {

	private ReqAuthDetails reqAuthDetails;
	
	public ReqAuthDetailsSenderImpl(ReqAuthDetails reqAuthDetails){
		this.reqAuthDetails = reqAuthDetails;
	}
	
	@Override
	public void send(UpiClientService upiClientService) {
		// TODO Nothing to do
	}
	
	
	
	

}