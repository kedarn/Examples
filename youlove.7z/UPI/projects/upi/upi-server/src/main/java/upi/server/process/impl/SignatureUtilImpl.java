/**
 * 
 */
package upi.server.process.impl;

import java.io.StringWriter;
import java.util.List;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.Marshaller;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMResult;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.upi.system_1_2.RespListAccPvd.AccPvdList.AccPvd;
import org.upi.system_1_2.RespListAccount.AccountList.Account;
import org.w3c.dom.Document;

import upi.server.process.PropertyReader;
import upi.server.process.SignatureUtil;
import upi.server.util.FileLineReader;
import upi.server.util.SignatureGenUtil;

/**
 * @author prasadj
 *
 */
@Component("signatureUtil")
public class SignatureUtilImpl implements SignatureUtil {

	@Autowired
	private PropertyReader propertyReader;

	private SignatureGenUtil signatureGenUtil;
	
	private FileLineReader fr;
	
	public SignatureUtilImpl(){
	}
	
	private void initiateFlr(){
		if(fr == null){
			this.fr = new FileLineReader(propertyReader.getAccountProviderPath(), propertyReader.getBankAccountsPath());
		}
	}
	
	private void initiateSgu(){
		if(this.signatureGenUtil == null){
			this.signatureGenUtil = new SignatureGenUtil(propertyReader.getSignerFilePath(), propertyReader.getCertificateFilePath());
		}
	}
	
	@Override
	public boolean isDigitalSignatureValid(String data) throws Exception {
		initiateSgu();
		return signatureGenUtil.isXmlDigitalSignatureValid(data);
	}

	@Override
	public Document signdoc(Document unsignedXML) throws Exception {
		initiateSgu();
		return signatureGenUtil.signdoc(unsignedXML);
	}

	@Override
	public String requestToString(Object object) {
		String response = null;
		DOMResult result;
		Document doc = null;
		try {
			JAXBContext jaxbContext = JAXBContext.newInstance(object.getClass());
			Marshaller jaxbMarshaller = jaxbContext.createMarshaller();
			jaxbMarshaller.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, true);
			result= new DOMResult();
			jaxbMarshaller.marshal(object, result);
			doc = (Document)result.getNode();
			doc = signdoc(doc);
			response = convertDocumentToString(doc);
		} catch ( Exception e) {
			throw new RuntimeException("Exception while preparing to xml.");
		}
		return response;
	}
	
	@Override
	public List<AccPvd> getAccountProviders() {
		initiateFlr();
		return fr.getAccountProviders();
	}

	@Override
	public List<Account> getAccounts(String ifsc, String customerName) {
		initiateFlr();
		return fr.getAccounts(ifsc, customerName);
	}

	private String convertDocumentToString(Document doc) {
        TransformerFactory tf = TransformerFactory.newInstance();
        Transformer transformer;
        try {
            transformer = tf.newTransformer();
            // below code to remove XML declaration
            // transformer.setOutputProperty(OutputKeys.OMIT_XML_DECLARATION, "yes");
            StringWriter writer = new StringWriter();
            transformer.transform(new DOMSource(doc), new StreamResult(writer));
            String output = writer.getBuffer().toString();
            return output;
        } catch (TransformerException e) {
        	throw new RuntimeException(e.getMessage());
        }
    }

}