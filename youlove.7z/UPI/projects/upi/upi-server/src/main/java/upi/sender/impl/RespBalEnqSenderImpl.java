/**
 * 
 */
package upi.sender.impl;

import org.upi.system_1_2.RespBalEnq;

import upi.sender.UpiSender;
import upi.server.process.UpiClientService;

/**
 * @author prasadj
 *
 */
public class RespBalEnqSenderImpl implements UpiSender {

	private RespBalEnq respBalEnq;
	
	public RespBalEnqSenderImpl(RespBalEnq respBalEnq){
		this.respBalEnq = respBalEnq;
	}
	
	@Override
	public void send(UpiClientService upiClientService) {
		// TODO Nothing to do

	}

}
