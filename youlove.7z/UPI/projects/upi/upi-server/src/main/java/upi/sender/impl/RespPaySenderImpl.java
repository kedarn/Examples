/**
 * 
 */
package upi.sender.impl;

import org.upi.system_1_2.RespPay;

import upi.sender.UpiSender;
import upi.server.process.UpiClientService;

/**
 * @author prasadj
 *
 */
public class RespPaySenderImpl implements UpiSender {

	private RespPay respPay;
	
	public RespPaySenderImpl(RespPay respPay){
		this.respPay = respPay;
	}
	
	@Override
	public void send(UpiClientService upiClientService){
		// TODO Nothing to do
	}

}