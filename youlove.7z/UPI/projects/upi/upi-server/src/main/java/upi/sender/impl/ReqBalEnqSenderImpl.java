/**
 * 
 */
package upi.sender.impl;

import org.upi.system_1_2.Ack;
import org.upi.system_1_2.PayerType;
import org.upi.system_1_2.ReqBalEnq;
import org.upi.system_1_2.RespBalEnq;
import org.upi.system_1_2.RespBalEnq.Payer;
import org.upi.system_1_2.RespBalEnq.Payer.Bal;
import org.upi.system_1_2.RespBalEnq.Payer.Bal.Data;
import org.upi.system_1_2.RespType;

import upi.sender.UpiSender;
import upi.server.constants.ServiceNames;
import upi.server.process.UpiClientService;
import upi.server.util.PspClientTool;

/**
 * @author prasadj
 *
 */
public class ReqBalEnqSenderImpl implements UpiSender {

	private ReqBalEnq reqBalEnq;
	
	public ReqBalEnqSenderImpl(ReqBalEnq reqBalEnq){
		this.reqBalEnq = reqBalEnq;
	}
	
	@Override
	public void send(UpiClientService upiClientService) {
		RespBalEnq resBalEnq = prepareRespBalEnq(reqBalEnq);
		String resBalEnqStr = upiClientService.requestToString(resBalEnq);
		String ackStr = upiClientService.callPsp(resBalEnqStr, resBalEnq.getTxn().getRefUrl(), ServiceNames.RESP_BAL_ENQ, resBalEnq.getHead().getVer(), resBalEnq.getTxn().getId());
		Ack ack = PspClientTool.convertUpiRequest(ackStr, Ack.class);
		if(ack.getErr() == null) {
		}		
	}
	
	private RespBalEnq prepareRespBalEnq(ReqBalEnq reqBalEnq) {
		
		RespType respType = new RespType();
		respType.setResult("SUCCESS");
		respType.setReqMsgId(reqBalEnq.getHead().getMsgId());
		
		Payer payer = new Payer();
		PayerType payerType = reqBalEnq.getPayer();
		payer.setAddr(payerType.getAddr());
		payer.setName(payerType.getName());
		payer.setSeqNum(payerType.getSeqNum());
		payer.setType(payerType.getType().name());
		
		Bal bal = new Bal();
		Data data = new Data();
		data.setValue("5000");
		bal.setData(data);
		payer.setBal(bal);
		
		RespBalEnq respBal = new RespBalEnq();
		respBal.setHead(reqBalEnq.getHead());
		respBal.setTxn(reqBalEnq.getTxn());
		respBal.setResp(respType);
		respBal.setPayer(payer);		
		return respBal;
	}

}