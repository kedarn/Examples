/**
 * 
 */
package upi.sender.impl;

import org.upi.system_1_2.RespTxnConfirmation;

import upi.sender.UpiSender;
import upi.server.process.UpiClientService;

/**
 * @author prasadj
 *
 */
public class RespTxnConfirmationSenderImpl implements UpiSender {

	private RespTxnConfirmation respTxnConfirmation;
	
	public RespTxnConfirmationSenderImpl(RespTxnConfirmation respTxnConfirmation){
		this.respTxnConfirmation = respTxnConfirmation;
	}

	@Override
	public void send(UpiClientService upiClientService) {
		// TODO Nothing to do
	}

}