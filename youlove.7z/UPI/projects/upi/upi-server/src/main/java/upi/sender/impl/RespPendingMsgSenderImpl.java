/**
 * 
 */
package upi.sender.impl;

import org.upi.system_1_2.RespPendingMsg;

import upi.sender.UpiSender;
import upi.server.process.UpiClientService;

/**
 * @author prasadj
 *
 */
public class RespPendingMsgSenderImpl implements UpiSender {

	private RespPendingMsg respPendingMsg;
	
	public RespPendingMsgSenderImpl(RespPendingMsg respPendingMsg){
		this.respPendingMsg = respPendingMsg;
	}

	@Override
	public void send(UpiClientService upiClientService) {
		// TODO Nothing to do
	}

}