package psp.mobile.client;

import psp.common.model.constants.ServiceUris;

public interface PspUriService extends ServiceUris {

	String CONTROLLER = "/mobile";
	
	String getPspServerUrl(String key);
	
}