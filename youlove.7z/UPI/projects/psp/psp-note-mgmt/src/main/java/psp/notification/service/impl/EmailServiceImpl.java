/**
 * 
 */
package psp.notification.service.impl;

import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.ObjectMessage;
import javax.jms.Session;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jms.core.JmsTemplate;
import org.springframework.jms.core.MessageCreator;
import org.springframework.stereotype.Component;

import psp.notification.model.EmailMessage;
import psp.notification.service.EmailService;

/**
 * @author prasadj
 *
 */
@Component
public class EmailServiceImpl implements EmailService {

	@Autowired
	private JmsTemplate jmsTemplate;
	
	public EmailServiceImpl(){
	}
	
	public void sendEmail(final EmailMessage message){
		System.out.println("email message" + message);
		jmsTemplate.send(new MessageCreator() {
			public Message createMessage(Session session) throws JMSException {
		        ObjectMessage objectMessage = session.createObjectMessage();
		        objectMessage.setObject(message);
		        return objectMessage;
			}
		});
	}
	
}