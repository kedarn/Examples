/**
 * 
 */
package psp.notification.service;

import psp.notification.model.EmailMessage;

/**
 * @author prasadj
 *
 */
public interface EmailService {

	public void sendEmail(final EmailMessage message);
	
}