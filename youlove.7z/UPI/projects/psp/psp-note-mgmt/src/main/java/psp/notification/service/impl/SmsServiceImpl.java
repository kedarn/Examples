/**
 * 
 */
package psp.notification.service.impl;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

import org.springframework.stereotype.Component;

import psp.notification.service.SmsService;

/**
 * @author prasadj
 *
 */
@Component
public class SmsServiceImpl implements SmsService {
	
	String URL_STR = "http://info.bulksms-service.com/WebServiceSMS.aspx?";
	String USER_STR = "User=";
	String PASSWORD_STR = "&passwd=";
	String MOBILENUMBER_STR = "&mobilenumber=";
	String MESSAGE_STR = "&message=";
	String SID_STR = "&sid=";
	String MTYPE_STR = "&mtype=N";

	String USER_VAL = "T20160401803";
	String PASSWORD_VAL = "Ghfr5Se34";
	String SID_VAL = "PSPUPI";

	public SmsServiceImpl(){
	}

	@Override
	public void sendSms(String mobileNumber, String message) {
		try{
			String urlStr = URL_STR + USER_STR + USER_VAL + PASSWORD_STR + PASSWORD_VAL 
					+ MOBILENUMBER_STR + mobileNumber + MESSAGE_STR + message + SID_STR + SID_VAL + MTYPE_STR;
			urlStr = urlStr.replaceAll(" ", "%20");
			URL url = new URL(urlStr);
			HttpURLConnection conn =(HttpURLConnection)url.openConnection();
			conn.setRequestMethod("GET");
			conn.setDoOutput(true);
			conn.setDoInput(true);
			conn.setUseCaches(false);
			conn.connect();
			BufferedReader rd =new BufferedReader(new InputStreamReader(conn.getInputStream()));
			String line;
			StringBuffer buffer =new StringBuffer();
			while ((line =rd.readLine()) != null){
				buffer.append(line).append("\n");
			}
			System.out.println(buffer.toString());
			rd.close();
			conn.disconnect();
		}
		catch(Exception e){
			e.printStackTrace();
		}
	}

}