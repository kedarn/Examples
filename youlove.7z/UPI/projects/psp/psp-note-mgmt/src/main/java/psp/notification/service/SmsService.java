/**
 * 
 */
package psp.notification.service;

/**
 * @author prasadj
 *
 */
public interface SmsService {

	void sendSms(String mobileNumber, String message);
	
}