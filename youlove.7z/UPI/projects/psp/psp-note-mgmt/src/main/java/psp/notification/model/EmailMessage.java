package psp.notification.model;

import java.io.Serializable;

/**
 * The Class EmailMessage.
 */
public class EmailMessage implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	/** The from email. */
	private String fromEmail;
	
	/** The to email. */
	private String toEmail;
	
	/** The message body. */
	private String messageBody;
	
	/** The message subject. */
	private String messageSubject;
 	
	/**
	 * Instantiates a new email message.
	 */
	public EmailMessage(){
	}

	public EmailMessage(String toEmail, String messageBody, String messageSubject){
		this.toEmail = toEmail;
		this.messageBody = messageBody;
		this.messageSubject = messageSubject;
	}

	/**
	 * Gets the from email.
	 *
	 * @return the from email
	 */
	public String getFromEmail() {
		return fromEmail;
	}

	/**
	 * Sets the from email.
	 *
	 * @param fromEmail the new from email
	 */
	public void setFromEmail(String fromEmail) {
		this.fromEmail = fromEmail;
	}

	/**
	 * Gets the to email.
	 *
	 * @return the to email
	 */
	public String getToEmail() {
		return toEmail;
	}

	/**
	 * Sets the to email.
	 *
	 * @param toEmail the new to email
	 */
	public void setToEmail(String toEmail) {
		this.toEmail = toEmail;
	}

	/**
	 * Gets the message body.
	 *
	 * @return the message body
	 */
	public String getMessageBody() {
		return messageBody;
	}

	/**
	 * Sets the message body.
	 *
	 * @param messageBody the new message body
	 */
	public void setMessageBody(String messageBody) {
		this.messageBody = messageBody;
	}

	/**
	 * Gets the message subject.
	 *
	 * @return the message subject
	 */
	public String getMessageSubject() {
		return messageSubject;
	}

	/**
	 * Sets the message subject.
	 *
	 * @param messageSubject the new message subject
	 */
	public void setMessageSubject(String messageSubject) {
		this.messageSubject = messageSubject;
	}
    
	
	@Override
	public String toString() {
		return "EmailMessage [fromEmail=" + fromEmail + ", toEmail=" + toEmail
				+ ", messageBody=" + messageBody + ", messageSubject="
				+ messageSubject
				+ "]";
	}
    
}