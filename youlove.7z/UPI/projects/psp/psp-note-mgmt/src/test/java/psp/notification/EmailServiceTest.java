package psp.notification;

import org.junit.Test;
/**
 * 
 */
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.util.Assert;

import psp.db.test.AbstractServiceTest;
import psp.notification.model.EmailMessage;
import psp.notification.service.EmailService;

/**
 * @author prasadj
 *
 */
public class EmailServiceTest extends AbstractServiceTest {

	@Autowired
	EmailService emailService;

	@Test
	public void sampleTest(){
		EmailMessage message = new EmailMessage();
		Assert.notNull(message);
	}	
	
	//@Test
	public void emailNotificationSendingTest(){
		EmailMessage message = new EmailMessage();
		message.setToEmail("sample@sample.com");
		message.setMessageSubject("messageSubject");
		message.setMessageBody("messageBody");
		emailService.sendEmail(message);
	}
}