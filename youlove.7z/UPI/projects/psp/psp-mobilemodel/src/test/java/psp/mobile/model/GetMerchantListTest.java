package psp.mobile.model;

import java.util.List;

import org.junit.Assert;
import org.junit.Test;

import psp.mobile.model.response.GetMerchantListResponse;
import psp.mobile.model.response.MerchantDetails;

/**
 * @author prasadj
 *
 */
public class GetMerchantListTest {

	@Test
	public void constructGetMerchantListResponseTest(){
		String jsonStr = "{\n" +               
                "    \"statusCode\": \"108\",\n" +
                "    \"statusMessage\": \"Success\",\n" +
                "\"merchantList\": [" + "{" +
				" \"id\": \"1\",\n" +
				"\"name\": \"Deba\",\n" + 
				"\"nickName\": \"Debu\",\n" + 
				"\"virtualAddress\": \"Deba@tarang\",\n" + 
				"\"description\": \"Deba,GudenBerg\",\n" + 
				 "},\n" +
				 "{" +
				 " \"id\": \"2\",\n" +
				 "\"name\": \"Deba1\",\n" + 
					"\"nickName\": \"Debu1\",\n" + 
					"\"virtualAddress\": \"Deba1@tarang\",\n" + 
					"\"description\": \"Deba,Bonjour\",\n" + 
					  "}"
				+ "]"
				 + "}";      
		GetMerchantListResponse merchantRes = GetMerchantListResponse.constructGetMerchantListResponse(jsonStr);
		Assert.assertNotNull(merchantRes);		
		Assert.assertEquals("Success", merchantRes.getStatusMessage());
		Assert.assertEquals("108", merchantRes.getStatusCode());
		List<MerchantDetails> merchantList = merchantRes.getMerchantList();
		MerchantDetails merchant = merchantList.get(0);
		Assert.assertEquals(Long.parseLong("1"), merchant.getId().longValue());				
		Assert.assertEquals("Deba", merchant.getName());
		Assert.assertEquals("Debu", merchant.getNickName());
		Assert.assertEquals("Deba@tarang", merchant.getVirtualAddress());
		Assert.assertEquals("Deba,GudenBerg", merchant.getDescription());
		MerchantDetails merchant1 = merchantList.get(1);
		Assert.assertEquals(Long.parseLong("2"), merchant1.getId().longValue());				
		Assert.assertEquals("Deba1", merchant1.getName());
		Assert.assertEquals("Debu1", merchant1.getNickName());
		Assert.assertEquals("Deba1@tarang", merchant1.getVirtualAddress());
		Assert.assertEquals("Deba,Bonjour", merchant1.getDescription());
	}
	
	@Test
	public void constructGetMerchantListResponse02Test(){
		String jsonStr = "{\n" +               
                "    \"statusCode\": \"200\",\n" +
                "    \"statusMessage\": \"Success\",\n" +
                "\"merchantList\": [" + "{" +
				" \"id\": \"1\",\n" +
				"\"name\": \"Deba\",\n" + 
				"\"nickName\": \"Debu\",\n" + 
				"\"virtualAddress\": \"Deba@tarang\",\n" + 
				"\"description\": \"Deba,GudenBerg\",\n" + 
				 "}\n" 
				+ "]"
				 + "}";      
		GetMerchantListResponse merchantRes = GetMerchantListResponse.constructGetMerchantListResponse(jsonStr);
		Assert.assertNotNull(merchantRes);		
		Assert.assertEquals("Success", merchantRes.getStatusMessage());
		Assert.assertEquals("200", merchantRes.getStatusCode());
		List<MerchantDetails> merchantList = merchantRes.getMerchantList();
		MerchantDetails merchant = merchantList.get(0);
		Assert.assertEquals(Long.parseLong("1"), merchant.getId().longValue());				
		Assert.assertEquals("Deba", merchant.getName());
		Assert.assertEquals("Debu", merchant.getNickName());
		Assert.assertEquals("Deba@tarang", merchant.getVirtualAddress());
		Assert.assertEquals("Deba,GudenBerg", merchant.getDescription());
	}
	
	@Test
	public void constructGetMerchantListResponse03Test(){
		String jsonStr = "{\n" +               
                "    \"statusCode\": \"200\",\n" +
                "    \"statusMessage\": \"Success\"\n" +
				"}";  
		GetMerchantListResponse merListRes = GetMerchantListResponse.constructGetMerchantListResponse(jsonStr);
		Assert.assertNotNull(merListRes);		
		Assert.assertEquals("200", merListRes.getStatusCode());
		Assert.assertEquals("Success", merListRes.getStatusMessage());
		Assert.assertNull(merListRes.getMerchantList());				
	}
	
}