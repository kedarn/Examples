package psp.mobile.model;

import org.json.JSONObject;
import org.junit.Assert;
import org.junit.Test;

import psp.mobile.model.request.AddBeneficiaryRequest;
import psp.mobile.model.response.AddBeneficiaryResponse;

public class AddBeneficiaryTest {

	@Test
	public void constructJsonStringAddBeneficiaryRequestTest() { 
		AddBeneficiaryRequest request = new AddBeneficiaryRequest();
		request.setId(1L);
		request.setAddress("tarang@tarang");
		request.setBeneficiaryNote("paymnet");
		request.setNickName("tarang");
		request.setType("MOBILE");
		JSONObject jsonObj = new JSONObject(request.toJsonString());
		Assert.assertEquals(1L, jsonObj.getLong("id"));
		Assert.assertEquals("tarang@tarang", jsonObj.getString("address"));
		Assert.assertEquals("paymnet", jsonObj.getString("beneficiaryNote"));
		Assert.assertEquals("tarang", jsonObj.getString("nickName"));
		Assert.assertEquals("MOBILE", jsonObj.getString("type"));
	}
	
	@Test
	public void constructAddBeneficiaryResponseTest() { 
		String jsonStr = "{\n" +               
                "    \"statusCode\": \"200\",\n" +
                "    \"statusMessage\": \"Success\",\n" +
				" \"nickNameErrMsg\": \"nickname error\",\n" +
				"\"beneficiaryNoteErrMsg\": \"beneficiaryNote Err Msg\",\n" + 
				  "}";      
		AddBeneficiaryResponse addBenResp = AddBeneficiaryResponse.constructAddBeneficiaryResponse(jsonStr);
		Assert.assertNotNull(addBenResp);		
		Assert.assertEquals("Success", addBenResp.getStatusMessage());
		Assert.assertEquals("200", addBenResp.getStatusCode());
		Assert.assertEquals("nickname error", addBenResp.getNickNameErrMsg());
		Assert.assertEquals("beneficiaryNote Err Msg", addBenResp.getBeneficiaryNoteErrMsg());		
	}
}
