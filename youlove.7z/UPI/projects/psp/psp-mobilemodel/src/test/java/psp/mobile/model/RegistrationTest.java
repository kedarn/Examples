package psp.mobile.model;

import java.text.ParseException;

import org.json.JSONObject;
import org.junit.Assert;
import org.junit.Test;

import psp.mobile.model.request.RegistrationRequest;
import psp.mobile.model.response.RegistrationResponse;

public class RegistrationTest {

	@Test
	public void constructJsonStringRegistrationRequest01Test() { 
		RegistrationRequest request = new RegistrationRequest();
		request.setUserName("Gauti1234");
		request.setEmail("xyz@gmail.com");
		request.setFirstName("Gauti");
		request.setLastName("Bojan");
		request.setMiddleName("gambhir");
		request.setPassword("Gauti@1234");
		request.setMobileNumber("1234567890");
		JSONObject jsonObj = new JSONObject(request.toJsonString());
		Assert.assertEquals("Gauti1234", jsonObj.get("userName"));
		Assert.assertEquals("xyz@gmail.com", jsonObj.get("email"));
		Assert.assertEquals("Gauti", jsonObj.get("firstName"));
		Assert.assertEquals("Bojan", jsonObj.get("lastName"));
		Assert.assertEquals("gambhir", jsonObj.get("middleName"));
		Assert.assertEquals("Gauti@1234", jsonObj.get("password"));
		Assert.assertEquals("1234567890", jsonObj.get("mobileNumber"));
	}
	
	@Test
	public void constructJsonStringRegistrationRequest02Test() { 
		RegistrationRequest request = new RegistrationRequest();
		request.setUserName("");
		request.setEmail("");
		request.setFirstName("");
		request.setLastName("");
		request.setMiddleName("");
		request.setPassword("");
		request.setMobileNumber("");
		JSONObject jsonObj = new JSONObject(request.toJsonString());
		Assert.assertEquals("", jsonObj.get("userName"));
		Assert.assertEquals("", jsonObj.get("email"));
		Assert.assertEquals("", jsonObj.get("firstName"));
		Assert.assertEquals("", jsonObj.get("lastName"));
		Assert.assertEquals("", jsonObj.get("middleName"));
		Assert.assertEquals("", jsonObj.get("password"));
		Assert.assertEquals("", jsonObj.get("mobileNumber"));
	}
	
	@Test
	public void constructRegistrationResponseTest() throws ParseException { 
		String jsonStr =
				"{\n" +               
                "    \"statusCode\": \"200\",\n" +
                "    \"statusMessage\": \"Success\",\n" +
				" 	 \"firstNameErrMsg\": \"Invalid first name\",\n" +
				"	 \"lastNameErrMsg\": \"Invalid last name\",\n" +
				"	 \"middleNameErrMsg\": \"Invalid middle name\",\n" +
				"	 \"mobileNumberErrMsg\": \"Invalid mobile number\",\n"  +
				"	 \"adharNumberErrMsg\": \"Invalid aadhaar number\",\n"  +
				"	 \"emailErrMsg\": \"Invalid email\",\n"  +
				"	 \"userNameErrMsg\": \"Invalid user name\",\n"  +
				"	 \"passwordErrMsg\": \"Invalid password\",\n"  +
				"	 \"xmlPayload\": \"some xml\",\n"  
				 + "}";
		RegistrationResponse regRes = RegistrationResponse.constructRegistrationResponse(jsonStr);
		Assert.assertNotNull(regRes);		
		Assert.assertEquals("Success", regRes.getStatusMessage());
		Assert.assertEquals("200", regRes.getStatusCode());
		Assert.assertEquals("Invalid first name", regRes.getFirstNameErrMsg());
		Assert.assertEquals("Invalid last name", regRes.getLastNameErrMsg());
		Assert.assertEquals("Invalid middle name", regRes.getMiddleNameErrMsg());
		Assert.assertEquals("Invalid mobile number", regRes.getMobileNumberErrMsg());
		Assert.assertEquals("Invalid aadhaar number", regRes.getAdharNumberErrMsg());
		Assert.assertEquals("Invalid email", regRes.getEmailErrMsg());
		Assert.assertEquals("Invalid user name", regRes.getUserNameErrMsg());
		Assert.assertEquals("Invalid password", regRes.getPasswordErrMsg());
		Assert.assertEquals("some xml", regRes.getXmlPayload());
	}
	
}