package psp.mobile.model;

import java.text.ParseException;

import org.json.JSONObject;
import org.junit.Assert;
import org.junit.Test;

import psp.mobile.model.request.MobileCredentials;
import psp.mobile.model.request.SetPinRequest;
import psp.mobile.model.response.SetPinResponse;
import psp.mobile.model.util.RequestTestUtility;

public class SetPinTest {

	@Test
	public void constructJsonStringSetPinRequest01Test() {
		SetPinRequest request = new SetPinRequest();
		request.setIsChangePin(true);
		MobileCredentials credentials = RequestTestUtility.prepareCredentials();
		request.setOldCredentials(credentials);	
		request.setNewCredentials(credentials);
		JSONObject jsonObj = new JSONObject(request.toJsonString());
		Assert.assertEquals(true, jsonObj.getBoolean("isChangePin"));
		JSONObject jsonObj1 =  new JSONObject(jsonObj.get("oldCredentials").toString());	
		Assert.assertEquals("123", jsonObj1.get("dataCode"));
		Assert.assertEquals("222", jsonObj1.get("dataki"));
		Assert.assertEquals("MIIBIjANBgkqhkiG9w0BB", jsonObj1.get("dataValue"));
		Assert.assertEquals("MPIN", jsonObj1.get("subType"));
		Assert.assertEquals("PIN", jsonObj1.get("type"));
	}
	
	@Test
	public void constructJsonStringSetPinRequest02Test() {
		SetPinRequest request = new SetPinRequest();
		request.setIsChangePin(false);
		MobileCredentials credentials = RequestTestUtility.prepareCredentialsEmpty();
		request.setOldCredentials(credentials);	
		JSONObject jsonObj = new JSONObject(request.toJsonString());
		Assert.assertEquals(false, jsonObj.getBoolean("isChangePin"));
		JSONObject jsonObj1 =  new JSONObject(jsonObj.get("oldCredentials").toString());	
		Assert.assertEquals("", jsonObj1.get("dataCode"));
		Assert.assertEquals("", jsonObj1.get("dataki"));
		Assert.assertEquals("", jsonObj1.get("dataValue"));
		Assert.assertEquals("", jsonObj1.get("subType"));
		Assert.assertEquals("", jsonObj1.get("type"));
	}
	
	@Test
	public void constructSetPinResponseTest() throws ParseException { 
		String jsonStr =
				"{\n" +               
                "    \"statusCode\": \"200\",\n" +
                "    \"statusMessage\": \"Success\",\n" +
				" 	 \"oldPinErrMsg\": \"Invalid Old Pin\",\n" +
				"	 \"newPinErrMsg\": \"Invalid New Pin\",\n"   
				 + "}";
		SetPinResponse setPinRes = SetPinResponse.constructSetPinResponse(jsonStr);
		Assert.assertNotNull(setPinRes);		
		Assert.assertEquals("Success", setPinRes.getStatusMessage());
		Assert.assertEquals("200", setPinRes.getStatusCode());
		Assert.assertEquals("Invalid Old Pin", setPinRes.getOldPinErrMsg());
		Assert.assertEquals("Invalid New Pin", setPinRes.getNewPinErrMsg());
	}
	
}