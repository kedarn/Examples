package psp.mobile.model;

import org.json.JSONObject;
import org.junit.Assert;
import org.junit.Test;

import psp.mobile.model.request.GetTokenRequest;
import psp.mobile.model.request.MobileCredentials;
import psp.mobile.model.response.GetTokenResponse;
import psp.mobile.model.util.RequestTestUtility;

public class GetTokenTest {

	@Test
	public void constructJsonStringFromGetTokenRequestTest() { 
		GetTokenRequest request = new GetTokenRequest();
		MobileCredentials credentials = RequestTestUtility.prepareCredentials();
		request.setMobileCredentials(credentials);		
		JSONObject jsonObj = new JSONObject(request.toJsonString());
		JSONObject jsonObj1 =  new JSONObject(jsonObj.get("mobileCredentials").toString());	
		Assert.assertEquals("123", jsonObj1.get("dataCode"));
		Assert.assertEquals("222", jsonObj1.get("dataki"));
		Assert.assertEquals("MIIBIjANBgkqhkiG9w0BB", jsonObj1.get("dataValue"));
		Assert.assertEquals("MPIN", jsonObj1.get("subType"));
		Assert.assertEquals("PIN", jsonObj1.get("type"));
	}
	
	@Test
	public void constructGetTokenResponseTest() { 
		String jsonStr = "{\n" +               
                "    \"statusCode\": \"200\",\n" +
                "    \"statusMessage\": \"Success\",\n" +
				" \"code\": \"NPCI\",\n" +
				"\"keyIndexDate\": \"2432016\",\n" + 
				"\"keyValue\": \"12DDFFFFFDDDDD\",\n" + 
				"\"type\": \"MPIN\",\n" + 
				  "}";      
		GetTokenResponse getTokenResp = GetTokenResponse.constructGetTokenResponse(jsonStr);
		Assert.assertNotNull(getTokenResp);		
		Assert.assertEquals("Success", getTokenResp.getStatusMessage());
		Assert.assertEquals("200", getTokenResp.getStatusCode());
		Assert.assertEquals("NPCI", getTokenResp.getCode());
		Assert.assertEquals("2432016", getTokenResp.getKeyIndexDate());
		Assert.assertEquals("12DDFFFFFDDDDD", getTokenResp.getKeyValue());
		Assert.assertEquals("MPIN", getTokenResp.getType());
	}
}
