package psp.mobile.model;

import java.text.ParseException;

import org.json.JSONObject;
import org.junit.Assert;
import org.junit.Test;

import psp.common.model.AccountSummary;
import psp.mobile.model.request.LoginRequest;
import psp.mobile.model.response.LoginResponse;

public class LoginTest {

	@Test
	public void constructJsonStringLoginRequest01Test() { 
		LoginRequest request = new LoginRequest();
		request.setPassword("Gauti@1234");
		JSONObject jsonObj = new JSONObject(request.toJsonString());
		Assert.assertEquals("Gauti@1234", jsonObj.get("password"));
	}
	
	@Test
	public void constructJsonStringLoginRequest02Test() { 
		LoginRequest request = new LoginRequest();
		request.setPassword("");
		JSONObject jsonObj = new JSONObject(request.toJsonString());
		Assert.assertEquals("", jsonObj.get("password"));
	}
	
	@Test
	public void constructLoginResponseTest() throws ParseException { 
		String jsonStr =
				"{\n" +               
                "    \"statusCode\": \"200\",\n" +
                "    \"statusMessage\": \"Success\",\n" +
				" 	 \"userNameErrMsg\": \"Invalidate user name\",\n" +
				"	 \"passwordErrMsg\": \"Invalidate password\",\n" +  
				"	 \"accountSummary\": " + 
				"		{"  +
				" 			\"id\": \"1\",\n" +
				" 			\"maskedAccnumber\": \"XXXXXXXXXX4321\",\n" +
				" 			\"ifsc\": \"AACA1234567\",\n" +
				" 			\"name\": \"Tarang\",\n" +
				" 			\"aeba\": \"N\",\n" +
				" 			\"virtualAddress\": \"tarang@tarang\",\n" +
				" 			\"isPinSet\": \"true\",\n" +
				" 			\"credentailType\": \"PIN\",\n" +
				" 			\"credentailSubType\": \"MPIN\",\n" +
				" 			\"credentailDataType\": \"NUMBER\",\n" +
				" 			\"credentailDataLength\": \"6\"" +
				"	   }" 
				 + "}";
		LoginResponse loginRes = LoginResponse.constructLoginResponse(jsonStr);
		Assert.assertNotNull(loginRes);		
		Assert.assertEquals("Success", loginRes.getStatusMessage());
		Assert.assertEquals("200", loginRes.getStatusCode());
		Assert.assertEquals("Invalidate user name", loginRes.getUserNameErrMsg());
		Assert.assertEquals("Invalidate password", loginRes.getPasswordErrMsg());
		AccountSummary accSummary = loginRes.getAccountSummary();
		Assert.assertEquals(1L, accSummary.getId().longValue());
		Assert.assertEquals("XXXXXXXXXX4321", accSummary.getMaskedAccnumber());
		Assert.assertEquals("AACA1234567", accSummary.getIfsc());
		Assert.assertEquals("Tarang", accSummary.getName());
		Assert.assertEquals("N", accSummary.getAeba());
		Assert.assertEquals("tarang@tarang", accSummary.getVirtualAddress());
		Assert.assertEquals(true, accSummary.getIsPinSet());
		Assert.assertEquals("PIN", accSummary.getCredentailType());
		Assert.assertEquals("MPIN", accSummary.getCredentailSubType());
		Assert.assertEquals("NUMBER", accSummary.getCredentailDataType());
		Assert.assertEquals(6, accSummary.getCredentailDataLength().intValue());
	}
	
	@Test
	public void constructLoginResponse02Test() throws ParseException { 
		String jsonStr =
				"{\n" +               
                "    \"statusCode\": \"200\",\n" +
                "    \"statusMessage\": \"Success\",\n" +
				" 	 \"userNameErrMsg\": \"Invalidate user name\",\n" +
				"	 \"passwordErrMsg\": \"Invalidate password\"\n" +  
				"}";
		LoginResponse loginRes = LoginResponse.constructLoginResponse(jsonStr);
		Assert.assertNotNull(loginRes);		
		Assert.assertEquals("Success", loginRes.getStatusMessage());
		Assert.assertEquals("200", loginRes.getStatusCode());
		Assert.assertEquals("Invalidate user name", loginRes.getUserNameErrMsg());
		Assert.assertEquals("Invalidate password", loginRes.getPasswordErrMsg());
		Assert.assertNull(loginRes.getAccountSummary());	
	}
	
}