/**
 * 
 */
package psp.mobile.model;

import org.json.JSONObject;
import org.junit.Assert;
import org.junit.Test;

import psp.mobile.model.request.GetNotificationDetailsRequest;
import psp.mobile.model.response.CollectPayNotification;
import psp.mobile.model.response.GetNotificationDetailsResponse;

/**
 * @author prasadj
 *
 */
public class GetNotificationDetailsTest {

	@Test
	public void constructJsonStringGetNotificationdetailRequest01Test() { 
		GetNotificationDetailsRequest request = new GetNotificationDetailsRequest();
		request.setNotificationId("not123");
		JSONObject jsonObj = new JSONObject(request.toJsonString());
		Assert.assertEquals("not123", jsonObj.getString("notificationId"));
	}
	
	@Test
	public void constructGetNotificationDetailsResponseFromStrTest(){
		String jsonStr = "{"
				+ "\"statusCode\": \"200\","
				+ "\"statusMessage\": \"Success\","
				+ "\"notification\": {"
				+ "	\"notificationId\": \"1459850195414\","
				+ "	\"notificationtType\": \"COLLECT\","
				+ "	\"notificationMessage\": \"Hi pawan, Mr. pawan singhatia kumar initiated to collect money. added note: trirudjksdjd\","
				+ "	\"requestorMobileNumber\": null,"
				+ "	\"requestorName\": \"pawan singhatia kumar\","
				+ "	\"requestorVirtualAddress\": \"tiru1@tarang\","
				+ "	\"requestorNote\": \"trirudjksdjd\","
				+ "	\"amount\": \"200.0\","
				+ "	\"selfVitrualAddress\": \"pawan07@tarang\","
				+ "	\"txnId\": \"TARANG1459850195075\""
				+ "	}"
				+ "	}";      
		GetNotificationDetailsResponse notificationDetails = GetNotificationDetailsResponse.constructGetNotificationDetailsResponse(jsonStr);
		Assert.assertNotNull(notificationDetails);		
		Assert.assertEquals("Success", notificationDetails.getStatusMessage());
		Assert.assertEquals("200", notificationDetails.getStatusCode());
		CollectPayNotification notification = (CollectPayNotification)notificationDetails.getNotification();
		Assert.assertNotNull(notification);	
		Assert.assertEquals("1459850195414", notification.getNotificationId());
		Assert.assertEquals("COLLECT", notification.getNotificationtType());
		Assert.assertEquals("Hi pawan, Mr. pawan singhatia kumar initiated to collect money. added note: trirudjksdjd", notification.getNotificationMessage());
		Assert.assertEquals("pawan singhatia kumar", notification.getRequestorName());
		Assert.assertEquals("tiru1@tarang", notification.getRequestorVirtualAddress());
		Assert.assertEquals("trirudjksdjd", notification.getRequestorNote());
		Assert.assertEquals("200.0", notification.getAmount());
		Assert.assertEquals("pawan07@tarang", notification.getSelfVitrualAddress());
		Assert.assertEquals("TARANG1459850195075", notification.getTxnId());
		
	}
	
}