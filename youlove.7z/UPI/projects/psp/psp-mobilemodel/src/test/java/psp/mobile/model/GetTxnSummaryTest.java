package psp.mobile.model;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.List;

import org.json.JSONObject;
import org.junit.Assert;
import org.junit.Test;

import psp.mobile.model.request.GetTxnDetailsRequest;
import psp.mobile.model.response.GetTxnsSummaryResponse;
import psp.mobile.model.response.TxnSummary;

public class GetTxnSummaryTest {

	@Test
	public void constructJsonStringFromGetTxnDetailsRequestTest() { 
		GetTxnDetailsRequest request = new GetTxnDetailsRequest();
		request.setFromDate("2/03/2016");
		request.setToDate("24/03/2016");
		JSONObject jsonObj = new JSONObject(request.toJsonString());	
		Assert.assertEquals("2/03/2016", jsonObj.get("fromDate"));
		Assert.assertEquals("24/03/2016", jsonObj.get("toDate"));
	}
	
	@Test
	public void constructGetTxnsSummaryResponseTest() throws ParseException { 
		String jsonStr = "{\n" +               
                "    \"statusCode\": \"200\",\n" +
                "    \"statusMessage\": \"Success\",\n" +
				" \"fromDateErrMsg\": \"Invalidate from date\",\n" +
				"\"toDateErrMsg\": \"Invalidate to date\",\n" +  
				 "\"txnSummaryList\": [" + "{" +
					" \"paymentFrom\": \"hemanth\",\n" +
					"\"paymentTo\": \"tarang\",\n" + 
					"\"transactionDate\": \"03/24/2016\",\n" + 
					"\"status\": \"INITIATED\",\n" + 
					"\"txnMessage\": \"some bill\",\n" 
					 + "},\n" 
					 + "]"
					 + "}";  
		GetTxnsSummaryResponse txnSummary = GetTxnsSummaryResponse.constructGetTxnsSummaryResponse(jsonStr);
		Assert.assertNotNull(txnSummary);		
		Assert.assertEquals("Success", txnSummary.getStatusMessage());
		Assert.assertEquals("200", txnSummary.getStatusCode());
		Assert.assertEquals("Invalidate from date", txnSummary.getFromDateErrMsg());
		Assert.assertEquals("Invalidate to date", txnSummary.getToDateErrMsg());
		List<TxnSummary> txnSummaryList = txnSummary.getTxnSummaryList();
		TxnSummary txn = txnSummaryList.get(0);
		Assert.assertEquals("hemanth", txn.getPaymentFrom());
		Assert.assertEquals("tarang", txn.getPaymentTo());				
		Assert.assertEquals(new SimpleDateFormat("MM/dd/yyyy").parse("03/24/2016"), txn.getTransactionDate());
		Assert.assertEquals("INITIATED", txn.getStatus());
		Assert.assertEquals("some bill", txn.getTxnMessage());
	}

	@Test
	public void constructGetTxnsSummaryResponse02Test() throws ParseException { 
		String jsonStr = "{\n" +               
                "    \"statusCode\": \"200\",\n" +
                "    \"statusMessage\": \"Success\",\n" +
				" \"fromDateErrMsg\": \"Invalidate from date\",\n" +
				"\"toDateErrMsg\": \"Invalidate to date\",\n" +  
				 "\"txnSummaryList\": []"
					 + "}";  
		GetTxnsSummaryResponse txnSummary = GetTxnsSummaryResponse.constructGetTxnsSummaryResponse(jsonStr);
		Assert.assertNotNull(txnSummary);		
		Assert.assertEquals("Success", txnSummary.getStatusMessage());
		Assert.assertEquals("200", txnSummary.getStatusCode());
		Assert.assertEquals("Invalidate from date", txnSummary.getFromDateErrMsg());
		Assert.assertEquals("Invalidate to date", txnSummary.getToDateErrMsg());
		Assert.assertEquals(0, txnSummary.getTxnSummaryList().size());		
	}

	@Test
	public void constructGetTxnsSummaryResponse03Test() throws ParseException { 
		String jsonStr = "{\n" +               
                "    \"statusCode\": \"200\",\n" +
                "    \"statusMessage\": \"Success\",\n" +
				" \"fromDateErrMsg\": \"Invalidate from date\",\n" +
				"\"toDateErrMsg\": \"Invalidate to date\"\n"   
					 + "}";  
		GetTxnsSummaryResponse txnSummary = GetTxnsSummaryResponse.constructGetTxnsSummaryResponse(jsonStr);
		Assert.assertNotNull(txnSummary);		
		Assert.assertEquals("Success", txnSummary.getStatusMessage());
		Assert.assertEquals("200", txnSummary.getStatusCode());
		Assert.assertEquals("Invalidate from date", txnSummary.getFromDateErrMsg());
		Assert.assertEquals("Invalidate to date", txnSummary.getToDateErrMsg());
		List<TxnSummary> txnSummaryList = txnSummary.getTxnSummaryList();
		Assert.assertNull(txnSummaryList);		
	}

}