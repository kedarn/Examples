package psp.mobile.model;

import java.util.List;

import org.junit.Assert;
import org.junit.Test;

import psp.mobile.model.request.MobileNotification;
import psp.mobile.model.response.GetNotificationListResponse;

/**
 * @author prasadj
 *
 */
public class GetNotificationListTest {

	@Test
	public void constructGetNotificationListResponseFromStrTest(){
		String jsonStr = "{\n" +               
                "    \"statusCode\": \"200\",\n" +
                "    \"statusMessage\": \"Success\",\n" +
                "\"notifications\": [" + "{" +
				" \"notificationId\": \"noti1234\",\n" +
				"\"notificationtType\": \"TXN\",\n" + 
				"\"notificationMessage\": \"Transaction success\",\n" +  
				 "},\n" +
				 "{" +
				 " \"notificationId\": \"noti12345\",\n" +
				 "\"notificationtType\": \"COLLECT\",\n" + 
					"\"notificationMessage\": \"Collect Initiated\",\n" + 
					  "}"
				+ "]"
				 + "}";      
		GetNotificationListResponse notificationList = GetNotificationListResponse.constructGetNotificationListResponse(jsonStr);
		Assert.assertNotNull(notificationList);		
		Assert.assertEquals("Success", notificationList.getStatusMessage());
		Assert.assertEquals("200", notificationList.getStatusCode());
		List<MobileNotification> mobNotification = notificationList.getNotifications();
		MobileNotification notification = mobNotification.get(0);
		Assert.assertEquals("noti1234", notification.getNotificationId());
		Assert.assertEquals("Transaction success", notification.getNotificationMessage());
		Assert.assertEquals("TXN", notification.getNotificationtType());
		MobileNotification notification2 = mobNotification.get(1);				
		Assert.assertEquals("noti12345", notification2.getNotificationId());
		Assert.assertEquals("Collect Initiated", notification2.getNotificationMessage());
		Assert.assertEquals("COLLECT", notification2.getNotificationtType());
	}
	
	@Test
	public void constructGetNotificationListResponseFromStr01Test(){
		String jsonStr = "{\n" +               
                "    \"statusCode\": \"200\",\n" +
                "    \"statusMessage\": \"Success\"\n" +
				"}";  
		GetNotificationListResponse notificationListResp = GetNotificationListResponse.constructGetNotificationListResponse(jsonStr);
		Assert.assertNotNull(notificationListResp);		
		Assert.assertEquals("200", notificationListResp.getStatusCode());
		Assert.assertEquals("Success", notificationListResp.getStatusMessage());
		Assert.assertNull(notificationListResp.getNotifications());				
	}
	
}
