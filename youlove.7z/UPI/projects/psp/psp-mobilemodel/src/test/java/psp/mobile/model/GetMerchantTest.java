/**
 * 
 */
package psp.mobile.model;

import org.json.JSONObject;
import org.junit.Assert;
import org.junit.Test;

import psp.mobile.model.request.GetMerchantRequest;
import psp.mobile.model.response.GetMerchantResponse;
import psp.mobile.model.response.MerchantDetails;

/**
 * @author prasadj
 *
 */
public class GetMerchantTest {

	@Test
	public void constructJsonStringGetMerchantRequest01Test() { 
		GetMerchantRequest request = new GetMerchantRequest();
		request.setMerchantId(1L);
		JSONObject jsonObj = new JSONObject(request.toJsonString());
		Assert.assertEquals(1L, jsonObj.getLong("merchantId"));
	}
	
	@Test
	public void constructJsonStringGetMerchantRequest02Test() { 
		GetMerchantRequest request = new GetMerchantRequest();
		request.setMerchantId(1L);
		JSONObject jsonObj = new JSONObject(request.toJsonString());
		Assert.assertEquals(1L, jsonObj.getLong("merchantId"));
	}
	
	@Test
	public void construcGetMerchantResponseTest(){	
		String jsonStr = "{\n" +
				"	\"merchantDetails\":	{"+
				 "    \"id\": \"11\",\n" +
				 "\"name\": \"Deba11\",\n" + 
					"\"nickName\": \"Debu11\",\n" + 
					"\"virtualAddress\": \"Deba11@tarang\",\n" + 
					"\"description\": \"Deba11,GudenBerg\",\n" +
				"},"+
                "    \"statusCode\": \"200\",\n" +
                "    \"statusMessage\": \"Success\"}";
		GetMerchantResponse merchantRes = GetMerchantResponse.constructGetMerchantResponse(jsonStr);
		Assert.assertEquals("200", merchantRes.getStatusCode());
		Assert.assertEquals("Success", merchantRes.getStatusMessage());
		MerchantDetails merchantDtls = merchantRes.getMerchantDetails();
		Assert.assertEquals("Deba11", merchantDtls.getName());
		Assert.assertEquals("Debu11", merchantDtls.getNickName());
		Assert.assertEquals("Deba11@tarang", merchantDtls.getVirtualAddress());
		Assert.assertEquals("Deba11,GudenBerg", merchantDtls.getDescription());
	}

	@Test
	public void construcGetMerchantResponse02Test(){	
		String jsonStr = "{\n" +
                "    \"statusCode\": \"200\",\n" +
                "    \"statusMessage\": \"Success\"}";
		GetMerchantResponse merchantRes = GetMerchantResponse.constructGetMerchantResponse(jsonStr);
		Assert.assertEquals("200", merchantRes.getStatusCode());
		Assert.assertEquals("Success", merchantRes.getStatusMessage());
		Assert.assertNull(merchantRes.getMerchantDetails());
	}

}