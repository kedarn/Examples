/**
 * 
 */
package psp.mobile.model.request;

import org.json.JSONObject;

/**
 * @author prasadj
 *
 */
@SuppressWarnings("serial")
public class VerifyCustomerMerchantRequest extends MobileRequest {

	private Long merchantId;
	
	private String identification;
	
	public VerifyCustomerMerchantRequest(){
	}

	public Long getMerchantId() {
		return merchantId;
	}

	public void setMerchantId(Long merchantId) {
		this.merchantId = merchantId;
	}

	public String getIdentification() {
		return identification;
	}

	public void setIdentification(String identification) {
		this.identification = identification;
	}
	
	public String toJsonString() {
		 JSONObject jobj = getJsonString();
		 jobj.put("merchantId", merchantId);
		 jobj.put("identification", identification);
		 return jobj.toString();
	}
	
}