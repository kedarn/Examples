/**
 * 
 */
package psp.mobile.model.response;

import java.text.SimpleDateFormat;
import java.util.Date;

import org.json.JSONObject;

/**
 * @author manasp
 *
 */
public class TxnSummary {

	private String paymentFrom;
	
	private String paymentTo;
	
	private Double amount;
	
	private Date transactionDate;
	
	private String status;
	
	private String txnMessage;
	
	private String txnId;
	
	private String transactionType;

	public String getPaymentFrom() {
		return paymentFrom;
	}

	public void setPaymentFrom(String paymentFrom) {
		this.paymentFrom = paymentFrom;
	}

	public String getPaymentTo() {
		return paymentTo;
	}

	public void setPaymentTo(String paymentTo) {
		this.paymentTo = paymentTo;
	}

	public Double getAmount() {
		return amount;
	}

	public void setAmount(Double amount) {
		this.amount = amount;
	}

	public Date getTransactionDate() {
		return transactionDate;
	}

	public void setTransactionDate(Date transactionDate) {
		this.transactionDate = transactionDate;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getTxnMessage() {
		return txnMessage;
	}

	public void setTxnMessage(String txnMessage) {
		this.txnMessage = txnMessage;
	}
	
	public String getTxnId() {
		return txnId;
	}

	public void setTxnId(String txnId) {
		this.txnId = txnId;
	}

	public String getTransactionType() {
		return transactionType;
	}

	public void setTransactionType(String transactionType) {
		this.transactionType = transactionType;
	}

	public static TxnSummary constructTxnSummary(JSONObject jsonObj){		
		TxnSummary response = null;
		if(jsonObj != null ){				
			response = new TxnSummary();			
			response.paymentFrom = jsonObj.optString("paymentFrom", null);
			response.paymentTo = jsonObj.optString("paymentTo", null);
			response.amount = jsonObj.optDouble("amount");
			response.transactionDate = convertStringToDate(String.valueOf(jsonObj.get("transactionDate")));
			response.status = jsonObj.optString("status", null);
			response.txnMessage = jsonObj.optString("txnMessage", null);
			response.txnId = jsonObj.optString("txnId", null);
			response.transactionType = jsonObj.optString("transactionType", null);
		}
		return response;
	}
	
	private static Date convertStringToDate(String dateStr){
		
		SimpleDateFormat formatter = new SimpleDateFormat("MM/dd/yyyy");
	 
		try {
			if(dateStr != null && !"".equals(dateStr)){
				return formatter.parse(dateStr);
			}
		} 
		catch (Exception e) {
			return null;
		}
		return null;
	}
	
	
}
