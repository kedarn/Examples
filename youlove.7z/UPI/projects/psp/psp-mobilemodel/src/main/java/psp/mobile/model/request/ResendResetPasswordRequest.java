package psp.mobile.model.request;

import org.json.JSONObject;

@SuppressWarnings("serial")
public class ResendResetPasswordRequest extends MobileRequest {

	public ResendResetPasswordRequest() {
	}
	
	public String toJsonString(){
		JSONObject jobj = getJsonString();
		return jobj.toString();
	}
}
