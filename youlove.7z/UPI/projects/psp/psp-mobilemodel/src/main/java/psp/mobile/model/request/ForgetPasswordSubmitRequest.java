package psp.mobile.model.request;

import org.json.JSONObject;

@SuppressWarnings("serial")
public class ForgetPasswordSubmitRequest extends MobileRequest {

	private String question;
	
	private String answer;
	
	public ForgetPasswordSubmitRequest() {
	}
	
	public String getQuestion() {
		return question;
	}

	public void setQuestion(String question) {
		this.question = question;
	}

	public String getAnswer() {
		return answer;
	}

	public void setAnswer(String answer) {
		this.answer = answer;
	}

	public String toJsonString(){
		JSONObject jobj = getJsonString();
		jobj.put("question", question);
		jobj.put("answer", answer);
		return jobj.toString();
	}
}
