package psp.mobile.model.response;

import org.json.JSONObject;

public class MerchantDetails {
	
	private Long id;
	
	private String name;
	
	private String nickName;
	
	private String virtualAddress;
	
	private String description;
	
	private String firstName;
	
	private String middleName;
	
	private String lastName;
	
	private String email;
	
	private String phoneNumber;
	
	private String fullName;
	
	public MerchantDetails() {
	}
	
	public MerchantDetails(Long id, String name, String virtualAddress) {
		this.id = id;
		this.name = name;
		this.virtualAddress = virtualAddress;
	}
	
	
	public MerchantDetails(Long id, String name, String virtualAddress, String firstName, String middleName, String lastName, String email, String phoneNumber) {
		this.id = id;
		this.name = name;
		this.virtualAddress = virtualAddress;
		this.fullName = firstName.concat(" ").concat(middleName).concat(" ").concat(lastName);
		this.email = email;
		this.phoneNumber = phoneNumber;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}
	
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getNickName() {
		return nickName;
	}

	public void setNickName(String nickName) {
		this.nickName = nickName;
	}

	public String getVirtualAddress() {
		return virtualAddress;
	}

	public void setVirtualAddress(String virtualAddress) {
		this.virtualAddress = virtualAddress;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}
	
	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getMiddleName() {
		return middleName;
	}

	public void setMiddleName(String middleName) {
		this.middleName = middleName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getPhoneNumber() {
		return phoneNumber;
	}

	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}

	public String getFullName() {
		return fullName;
	}

	public void setFullName(String fullName) {
		this.fullName = fullName;
	}

	public static MerchantDetails construcMerchantDetails(JSONObject jsonObj){		
		MerchantDetails response = null;
		if(jsonObj != null ){				
			response = new MerchantDetails();			
			response.id = jsonObj.optLong("id");
			response.name = jsonObj.optString("name", null);	
			response.nickName = jsonObj.optString("nickName", null);	
			response.virtualAddress = jsonObj.optString("virtualAddress", null);	
			response.description = jsonObj.optString("description", null);	
		}
		return response;
	}
	
	public static MerchantDetails construcMerchantDetails(String jsonStr){		
		MerchantDetails response = null;
		if(jsonStr != null && !jsonStr.equals("null") ){				
			response = new MerchantDetails();		
			JSONObject jsonObj = new JSONObject(jsonStr);
			return construcMerchantDetails(jsonObj);
		}
		return response;
	}

}