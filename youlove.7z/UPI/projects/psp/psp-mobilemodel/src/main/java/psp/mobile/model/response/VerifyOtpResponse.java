package psp.mobile.model.response;

import psp.constants.StatusCode;

@SuppressWarnings("serial")
public class VerifyOtpResponse extends MessageResponse {

	public VerifyOtpResponse() {
	}
	
	public boolean validate() {
		boolean isSuccess = true;

		if (!isSuccess) {
			setStatusCode(StatusCode.FIELD_VALIDATION_FAILED.getCode());
			setStatusMessage(StatusCode.FIELD_VALIDATION_FAILED.getMessage());
		}
		return isSuccess;
	}
	
	public static VerifyOtpResponse constructVerifyOtpResponse(String jsonStr){	
		VerifyOtpResponse response = null;
		if(jsonStr != null && !"".equals(jsonStr)){	
			response = new VerifyOtpResponse();
			response.constructMessageRespnse(jsonStr);
		}
		return response;
	}
}
