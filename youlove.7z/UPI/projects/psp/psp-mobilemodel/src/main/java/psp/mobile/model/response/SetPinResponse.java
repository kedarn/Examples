package psp.mobile.model.response;

import org.json.JSONObject;

import psp.constants.StatusCode;
import psp.mobile.model.request.SetPinRequest;


@SuppressWarnings("serial")
public class SetPinResponse extends MessageResponse {

	private String oldPinErrMsg;
	
	private String newPinErrMsg;
	
	public SetPinResponse() {
	}

	public String getOldPinErrMsg() {
		return oldPinErrMsg;
	}

	public void setOldPinErrMsg(String oldPinErrMsg) {
		this.oldPinErrMsg = oldPinErrMsg;
	}

	public String getNewPinErrMsg() {
		return newPinErrMsg;
	}

	public void setNewPinErrMsg(String newPinErrMsg) {
		this.newPinErrMsg = newPinErrMsg;
	}
	
	public boolean validate(SetPinRequest request) {
		boolean isSuccess = true;

		if(request.getOldCredentials() == null ){
			isSuccess = false;
		}
		if(request.getIsChangePin() && request.getNewCredentials() == null){
			isSuccess = false;
		}
		if (!isSuccess) {
			setStatusCode(StatusCode.FIELD_VALIDATION_FAILED.getCode());
			setStatusMessage(StatusCode.FIELD_VALIDATION_FAILED.getMessage()); 
		}
		return isSuccess;
	}
	
	public static SetPinResponse constructSetPinResponse(String jsonStr){		
		SetPinResponse response = null;
		if(jsonStr != null && !"".equals(jsonStr)) {	
			response = new SetPinResponse();
			JSONObject jsonObj = new JSONObject(jsonStr);
			response.constructMessageRespnse(jsonStr);
			response.oldPinErrMsg = jsonObj.optString("oldPinErrMsg", null);
			response.newPinErrMsg = jsonObj.optString("newPinErrMsg", null);
		}
		return response;
	}
}