package psp.mobile.model.response;

import java.util.ArrayList;
import java.util.List;

import org.json.JSONArray;
import org.json.JSONObject;

import psp.constants.StatusCode;


@SuppressWarnings("serial")
public class ForgetPasswordResponse extends MessageResponse {

	List<String> securityQuestions;
	
	public ForgetPasswordResponse() {
	}

	public List<String> getSecurityQuestions() {
		return securityQuestions;
	}

	public void setSecurityQuestions(List<String> securityQuestions) {
		this.securityQuestions = securityQuestions;
	}

	public boolean validate() {
		boolean isSuccess = true;
		
		if (!isSuccess) {
			 setStatusCode(StatusCode.FIELD_VALIDATION_FAILED.getCode());
			 setStatusMessage(StatusCode.FIELD_VALIDATION_FAILED.getMessage());
		}
		return isSuccess;
	}
	public static ForgetPasswordResponse constructForgetPasswordResponse(String jsonStr){
		ForgetPasswordResponse response = null;
		if(jsonStr != null && !"".equals(jsonStr)){
			response = new ForgetPasswordResponse();
			JSONObject jsonObj = new JSONObject(jsonStr);
			List<String> securityQuestionsList = null;	
			try {
				JSONArray securityQuestions = jsonObj.getJSONArray("securityQuestions");
				securityQuestionsList = new ArrayList<>();
				 for(int i = 0; i < securityQuestions.length(); i++){
					 JSONObject securityQuestion = securityQuestions.getJSONObject(i);
					 securityQuestionsList.add(i, securityQuestion.toString());
				 }	
			}
			catch(Exception e) {
			}			
			response.securityQuestions = securityQuestionsList;
			response.constructMessageRespnse(jsonStr);
		}
		return response;
	}
}