package psp.mobile.model.response;

import psp.common.model.constants.ValidatorConstants;
import psp.mobile.model.request.DRegisterRequest;

@SuppressWarnings("serial")
public class DregisterResponse extends MessageResponse implements ValidatorConstants{

	
	public DregisterResponse() {
	}

	
	public boolean validate(DRegisterRequest req) {
		boolean isSuccess = true;
		return isSuccess;
	}
	
	public static DregisterResponse constructDregisterResponse(String jsonStr){		
		DregisterResponse response = null;
		if(jsonStr != null && !"".equals(jsonStr)){	
			response = new DregisterResponse();
			response.constructMessageRespnse(jsonStr);
		}
		return response;
	}
	
}