/**
 * 
 */
package psp.common.model;

import org.json.JSONObject;

/**
 * @author prasadj
 *
 */
public class BillDetails {

	private String identification;
	
	private int billDate;

	private String billDateStr;

	private int notificationDate;
	
	private String notificationDateStr;

	private int notificationExpDate;
	
	private String notificationExpDateStr;

	private int expDate;
	
	private String expDateStr;

	public BillDetails(){
	}

	public String getIdentification() {
		return identification;
	}

	public void setIdentification(String identification) {
		this.identification = identification;
	}

	public int getBillDate() {
		return billDate;
	}

	public void setBillDate(int billDate) {
		this.billDate = billDate;
	}

	public String getBillDateStr() {
		return billDateStr;
	}

	public void setBillDateStr(String billDateStr) {
		this.billDateStr = billDateStr;
	}

	public int getNotificationDate() {
		return notificationDate;
	}

	public void setNotificationDate(int notificationDate) {
		this.notificationDate = notificationDate;
	}

	public String getNotificationDateStr() {
		return notificationDateStr;
	}

	public void setNotificationDateStr(String notificationDateStr) {
		this.notificationDateStr = notificationDateStr;
	}

	public int getNotificationExpDate() {
		return notificationExpDate;
	}

	public void setNotificationExpDate(int notificationExpDate) {
		this.notificationExpDate = notificationExpDate;
	}

	public String getNotificationExpDateStr() {
		return notificationExpDateStr;
	}

	public void setNotificationExpDateStr(String notificationExpDateStr) {
		this.notificationExpDateStr = notificationExpDateStr;
	}

	public int getExpDate() {
		return expDate;
	}

	public void setExpDate(int expDate) {
		this.expDate = expDate;
	}

	public String getExpDateStr() {
		return expDateStr;
	}

	public void setExpDateStr(String expDateStr) {
		this.expDateStr = expDateStr;
	}

	public JSONObject toJsonObject(){
		JSONObject jobj = new JSONObject();
		jobj.put("identification", identification);
		jobj.put("billDate", billDate);
		jobj.put("billDateStr", billDateStr);
		jobj.put("notificationDate", notificationDate);
		jobj.put("notificationDateStr", notificationDateStr);
		jobj.put("notificationExpDate", notificationExpDate);
		jobj.put("notificationExpDateStr", notificationExpDateStr);
		jobj.put("expDate", expDate);
		jobj.put("expDateStr", expDateStr);
		return jobj;
	}

	public static BillDetails constructBillDetails(JSONObject jsonObj){		
		BillDetails response = null;
		if(jsonObj != null ){				
			response = new BillDetails();			
			response.identification = jsonObj.optString("identification");
			response.billDate = jsonObj.optInt("billDate", 0);	
			response.billDateStr = jsonObj.optString("billDateStr", null);	
			response.notificationDate = jsonObj.optInt("notificationDate", 0);	
			response.notificationDateStr = jsonObj.optString("notificationDateStr", null);	
			response.notificationExpDate = jsonObj.optInt("notificationExpDate", 0);	
			response.notificationExpDateStr = jsonObj.optString("notificationExpDateStr", null);	
			response.expDate = jsonObj.optInt("expDate", 0);	
			response.expDateStr = jsonObj.optString("expDateStr", null);	
		}
		return response;
	}
	
	public static BillDetails constructBillDetails(String jsonStr){		
		BillDetails response = null;
		if(jsonStr != null && !jsonStr.equals("null") ){				
			response = new BillDetails();		
			JSONObject jsonObj = new JSONObject(jsonStr);
			return constructBillDetails(jsonObj);
		}
		return response;
	}
	
}