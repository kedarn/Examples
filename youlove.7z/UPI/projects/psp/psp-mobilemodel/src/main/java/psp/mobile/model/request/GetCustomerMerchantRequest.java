/**
 * 
 */
package psp.mobile.model.request;

import org.json.JSONObject;

/**
 * @author prasadj
 *
 */
@SuppressWarnings("serial")
public class GetCustomerMerchantRequest extends MobileRequest {

	public boolean addedMerchants;
	
	public GetCustomerMerchantRequest(){
	}

	public boolean isAddedMerchants() {
		return addedMerchants;
	}

	public void setAddedMerchants(boolean addedMerchants) {
		this.addedMerchants = addedMerchants;
	}
	
	public String toJsonString() {
		 JSONObject jobj = getJsonString();
		 jobj.put("addedMerchants", addedMerchants);
		 return jobj.toString();
	}
	
}