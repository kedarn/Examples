/**
 * 
 */
package psp.mobile.model.request;

import org.json.JSONObject;

import psp.common.model.BillDetails;

/**
 * @author prasadj
 *
 */
@SuppressWarnings("serial")
public class ConformCustomerMerchantRequest extends MobileRequest {

	private Long merchantId;
	
	private BillDetails billDetails;
	
	public ConformCustomerMerchantRequest(){
	}

	public Long getMerchantId() {
		return merchantId;
	}

	public void setMerchantId(Long merchantId) {
		this.merchantId = merchantId;
	}

	public BillDetails getBillDetails() {
		return billDetails;
	}

	public void setBillDetails(BillDetails billDetails) {
		this.billDetails = billDetails;
	}

	public String toJsonString() {
		 JSONObject jobj = getJsonString();
		 jobj.put("merchantId", merchantId);
		 jobj.put("billDetails", billDetails.toJsonObject().toString());
		 return jobj.toString();
	}
	
}