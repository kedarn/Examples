/**
 * 
 */
package psp.mobile.model.response;

import psp.constants.StatusCode;

/**
 * @author prasadj
 *
 */
@SuppressWarnings("serial")
public class ConformCustomerMerchantResponse extends MessageResponse {

	public ConformCustomerMerchantResponse() {
	}

	public boolean validate() {
		boolean isSuccess = true;
		if (!isSuccess) {
			setStatusCode(StatusCode.FIELD_VALIDATION_FAILED.getCode());
			setStatusMessage(StatusCode.FIELD_VALIDATION_FAILED.getMessage()); 
		}
		return isSuccess;
	}
	
	public static ConformCustomerMerchantResponse constructConformCustomerMerchantResponse(String jsonStr){		
		ConformCustomerMerchantResponse response = null;
		if(jsonStr != null && !"".equals(jsonStr)){	
			response = new ConformCustomerMerchantResponse();
			response.constructMessageRespnse(jsonStr);
		}
		return response;
	}

}