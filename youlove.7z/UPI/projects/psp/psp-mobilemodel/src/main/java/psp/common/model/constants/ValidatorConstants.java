/**
 * 
 */
package psp.common.model.constants;

/**
 * @author prasadj
 *
 */	
public interface ValidatorConstants {

	// ALL expression types
	String ALPHABET_EXP = "[a-zA-Z]*";
	
	String ALPHABET_EXP_MSG = " should contain only alphabets";
	
	String ALPHABET_SPACE_EXP = "[a-zA-Z ]*";
	
	String ALPHABET_SPACE_EXP_MSG = " should contain only alphabets and space";
	
	String ALPHANUMARIC_EXP = "[a-zA-Z0-9]*";
	
	String ALPHANUMARICSPACE_EXP = "[a-zA-Z0-9 ]*";
	
	String ALPHANUMARIC_SPACE_SPECIALCHAR_EXP = "^[ _A-Za-z0-9'.-]+$";
	
	String NUMARIC_EXP = "[0-9]*";
	
	String DECIMAL_NUMBER_EXP = "\\d{0,18}\\.\\d{1,2}" + "|" +"\\d*";
	
	//String PASSWORD_EXP = "(?=.*[0-9])(?=.*[a-z])(?=.*[A-Z])(?=.*[@#$%^&+=])(?=\\S+$).{7,20}";
	
	String PASSWORD_EXP = ALPHANUMARIC_EXP;
	
	String EMAIL_EXP = "^[(a-zA-Z-0-9-\\_\\+\\.)]+@[(a-z-A-z)]+\\.[(a-zA-z)]{2,3}$";
	
	String VITUAL_ADDR_CONDITION1 = "^[(a-zA-Z-0-9-\\+\\.)]+@[(A-Za-z0-9_'|'-)]+\\.[(a-zA-z)]{2,4}+\\.[(a-zA-z)]{2,4}$";
	String VITUAL_ADDR_CONDITION2 = "^[(a-zA-Z-0-9-\\+\\.)]+@[(A-Za-z0-9_'|'-)]+\\.[(a-zA-z)]{2,4}$";
	String VITUAL_ADDR_CONDITION3 = "^[(a-zA-Z-0-9-\\+\\.)]+@[(A-Za-z0-9_'|'-)]+\\-[(a-zA-z)]{2,4}+\\.[(a-zA-z)]{2,4}$";
	String VITUAL_ADDR_CONDITION4 = "^[(a-zA-Z-0-9-\\+\\.)]+@[(a-z-A-z)]+";		

	String VIRTUAL_ADDRESS_EXP = "\\b("+VITUAL_ADDR_CONDITION1+"|"+VITUAL_ADDR_CONDITION2+"|"+VITUAL_ADDR_CONDITION3+"|"+VITUAL_ADDR_CONDITION4+")\\b";
	
	String DATE_EXP = "^(1[0-2]|0[1-9])-(3[01]|[12][0-9]|0[1-9])-[0-9]{4}$";
	
	String USER_NAME_EXP = ALPHANUMARIC_EXP;
	
	String MIN_LENGTH_MSG = " minimum length is ";
	
	String MAX_LENGTH_MSG = " maximum length is ";
	
	String MANDATORY_MSG = " can not be empty";
	
	String EMAIL_EXP_MSG = " is not in valid format, valid format for e.g(XYZ@gmail.com)";
	
	String ALPHABET_DIGIT_EXP_MSG = " should contain only alphabets and digits";  
	
	//String PASSWORD_EXP_MSG = " must contain a digit least once ,a lower case letter at least once ,an upper case letter at least once ," + "a special character at least once and no whitespace allowed in the entire string";
	
	String PASSWORD_EXP_MSG = " should contain alphaNumeric";
	
	String DIGIT_EXP_MSG = " should contain only digits";

	String VIRTUAL_ADDR_EXP_MSG = " is not in valid format";
	
	String AMOUNT_LEN_MSG = " minimum range is 1 and maximum range is 50,000";
	
	String AMOUNT_EXPR_MSG = " should contain only 2 decimal digits";
	
	String DATE_EXP_MSG = " is not in valid format";
	
	String ALPHANUMARICSPACE_ERR_MSG = " should contain only alphabets,digits and space";
	
	String ALPHANUMARIC_SPACE_SPLCHAR_ERR_MSG = " should contain only alphabets,digits,special characters such as(.,'-_) and space";
	// first name 
	
	String FIRST_NAME = "First name";
	
	boolean FIRST_NAME_IS_MANDATORY = true;

	int FIRST_NAME_MIN_LENGTH = 3;
	
	int FIRST_NAME_MAX_LENGTH = 30;
	
	String FIRST_NAME_EXPRESSION = ALPHABET_SPACE_EXP;
	
	String FIRST_NAME_MANDATORY_ERR_MSG = FIRST_NAME + MANDATORY_MSG;
	
	String FIRST_NAME_LENGTH_ERR_MSG = FIRST_NAME + MIN_LENGTH_MSG + FIRST_NAME_MIN_LENGTH + MAX_LENGTH_MSG + FIRST_NAME_MAX_LENGTH;
	
	String FIRST_NAME_EXPRESSION_ERR_MSG = FIRST_NAME + ALPHABET_SPACE_EXP_MSG;
	
	// middle name 
	
	String MIDDLE_NAME = "Middle name";
	
	boolean MIDDLE_NAME_IS_MANDATORY = true;

	int MIDDLE_NAME_MIN_LENGTH = 3;
	
	int MIDDLE_NAME_MAX_LENGTH = 20;
	
	String MIDDLE_NAME_EXPRESSION = ALPHABET_SPACE_EXP;
	
	String MIDDLE_NAME_MANDATORY_ERR_MSG = null;
	
	String MIDDLE_NAME_LENGTH_ERR_MSG = MIDDLE_NAME + MIN_LENGTH_MSG + MIDDLE_NAME_MIN_LENGTH + MAX_LENGTH_MSG + MIDDLE_NAME_MAX_LENGTH;
	
	String MIDDLE_NAME_EXPRESSION_ERR_MSG = MIDDLE_NAME + ALPHABET_SPACE_EXP_MSG;
		
	//last name
	
	String LAST_NAME = "Last name";
	
	boolean LAST_NAME_IS_MANDATORY = true;

	int LAST_NAME_MIN_LENGTH = 3;
	
	int LAST_NAME_MAX_LENGTH = 30;
	
	String LAST_NAME_EXPRESSION = ALPHABET_SPACE_EXP;
	
	String LAST_NAME_MANDATORY_ERR_MSG = LAST_NAME + MANDATORY_MSG;
	
	String LAST_NAME_LENGTH_ERR_MSG = LAST_NAME + MIN_LENGTH_MSG + LAST_NAME_MIN_LENGTH + MAX_LENGTH_MSG + LAST_NAME_MAX_LENGTH;
	
	String LAST_NAME_EXPRESSION_ERR_MSG = LAST_NAME + ALPHABET_SPACE_EXP_MSG;
		
	//Mobile number
	
	String MOBILE_NUMBER = "Mobile number";
	
	boolean MOBILE_NUMBER_IS_MANDATORY = true;
	
	int MOBILE_NUMBER_MIN_LENGTH = 10;
	
	int MOBILE_NUMBER_MAX_LENGTH = 10;
	
	String MOBILE_NUMBER_EXPRESSION = NUMARIC_EXP;
	
	String MOBILE_NUMBER_MANDATORY_ERR_MSG = MOBILE_NUMBER + MANDATORY_MSG;
	
	String MOBILE_NUMBER_LENGTH_ERR_MSG = MOBILE_NUMBER + MIN_LENGTH_MSG + MOBILE_NUMBER_MIN_LENGTH + MAX_LENGTH_MSG + MOBILE_NUMBER_MAX_LENGTH; 

    String MOBILE_NUMBER_EXPRESSION_ERR_MSG = MOBILE_NUMBER + DIGIT_EXP_MSG;
    
    //Aadhar Number
    
    String AADHAR_NUMBER = "Aadhaar number";
	
	boolean AADHAR_NUMBER_IS_MANDATORY = true;
	
	int AADHAR_NUMBER_MIN_LENGTH = 12;
	
	int AADHAR_NUMBER_MAX_LENGTH = 20;
	
	String AADHAR_NUMBER_EXPRESSION = NUMARIC_EXP;
	
	String AADHAR_NUMBER_MANDATORY_ERR_MSG = AADHAR_NUMBER + MANDATORY_MSG;
	
	String AADHAR_NUMBER_LENGTH_ERR_MSG = AADHAR_NUMBER + MIN_LENGTH_MSG + AADHAR_NUMBER_MIN_LENGTH + MAX_LENGTH_MSG + AADHAR_NUMBER_MAX_LENGTH; 

    String AADHAR_NUMBER_EXPRESSION_ERR_MSG = AADHAR_NUMBER + DIGIT_EXP_MSG;

    //Email
    
    String EMAIL = "Email";
	
	boolean EMAIL_IS_MANDATORY = true;
	
	int EMAIL_MIN_LENGTH = 7;
	
	int EMAIL_MAX_LENGTH = 40;
	
	String EMAIL_EXPRESSION = EMAIL_EXP;
	
	String EMAIL_MANDATORY_ERR_MSG = EMAIL + MANDATORY_MSG;
	
	String EMAIL_LENGTH_ERR_MSG = EMAIL + MIN_LENGTH_MSG + EMAIL_MIN_LENGTH + MAX_LENGTH_MSG + EMAIL_MAX_LENGTH; 

    String EMAIL_EXPRESSION_ERR_MSG = EMAIL + EMAIL_EXP_MSG;
    
   //User Name
    
    String USER_NAME = "User name";
	
	boolean USER_NAME_IS_MANDATORY = true;
	
	int USER_NAME_MIN_LENGTH = 5;
	
	int USER_NAME_MAX_LENGTH = 30;
	
	String USER_NAME_EXPRESSION = ALPHANUMARIC_EXP;
	
	String USER_NAME_MANDATORY_ERR_MSG = USER_NAME + MANDATORY_MSG;
	
	String USER_NAME_LENGTH_ERR_MSG = USER_NAME + MIN_LENGTH_MSG + USER_NAME_MIN_LENGTH + MAX_LENGTH_MSG + USER_NAME_MAX_LENGTH; 

    String USER_NAME_EXPRESSION_ERR_MSG = USER_NAME + ALPHABET_DIGIT_EXP_MSG;
    
    //Password
    
    String PASSWORD = "Password";
	
	boolean PASSWORD_IS_MANDATORY = true;
	
	int PASSWORD_MIN_LENGTH = 7;
	
	int PASSWORD_MAX_LENGTH = 20;
	
	String PASSWORD_EXPRESSION = PASSWORD_EXP;
	
	String PASSWORD_MANDATORY_ERR_MSG = PASSWORD + MANDATORY_MSG;
	
	String PASSWORD_LENGTH_ERR_MSG = PASSWORD + MIN_LENGTH_MSG + PASSWORD_MIN_LENGTH + MAX_LENGTH_MSG + PASSWORD_MAX_LENGTH; 

    String PASSWORD_EXPRESSION_ERR_MSG = PASSWORD + PASSWORD_EXP_MSG;
   
    //Old password
    
    String OLD_PASSWORD = "Old password";
    
    String OLD_PASSWORD_MANDATORY_ERR_MSG = OLD_PASSWORD + MANDATORY_MSG;
	
	String OLD_PASSWORD_LENGTH_ERR_MSG = OLD_PASSWORD + MIN_LENGTH_MSG + PASSWORD_MIN_LENGTH + MAX_LENGTH_MSG + PASSWORD_MAX_LENGTH; 

    String OLD_PASSWORD_EXPRESSION_ERR_MSG = OLD_PASSWORD + PASSWORD_EXP_MSG;
    
   //New password
    
    String NEW_PASSWORD = "New password";
    
    String NEW_PASSWORD_MANDATORY_ERR_MSG = NEW_PASSWORD + MANDATORY_MSG;
	
   	String NEW_PASSWORD_LENGTH_ERR_MSG = NEW_PASSWORD + MIN_LENGTH_MSG + PASSWORD_MIN_LENGTH + MAX_LENGTH_MSG + PASSWORD_MAX_LENGTH; 

    String NEW_PASSWORD_EXPRESSION_ERR_MSG = NEW_PASSWORD + PASSWORD_EXP_MSG;
    
    //MMID
    
    String MMID = "MMID";
	
	boolean MMID_IS_MANDATORY = true;
	
	int MMID_MIN_LENGTH = 7;
	
	int MMID_MAX_LENGTH = 10;
	
	String MMID_EXPRESSION = NUMARIC_EXP;
	
	String MMID_MANDATORY_ERR_MSG = MMID + MANDATORY_MSG;
	
	String MMID_LENGTH_ERR_MSG = MMID + MIN_LENGTH_MSG + MMID_MIN_LENGTH + MAX_LENGTH_MSG + MMID_MAX_LENGTH; 

    String MMID_EXPRESSION_ERR_MSG = MMID + DIGIT_EXP_MSG;
    
    //IIN
    
    String IIN = "IIN";
	
	boolean IIN_IS_MANDATORY = true;
	
	int IIN_MIN_LENGTH = 4;
	
	int IIN_MAX_LENGTH = 10;
	
	String IIN_EXPRESSION = NUMARIC_EXP;
	
	String IIN_MANDATORY_ERR_MSG = IIN + MANDATORY_MSG;
	
	String IIN_LENGTH_ERR_MSG = IIN + MIN_LENGTH_MSG + IIN_MIN_LENGTH + MAX_LENGTH_MSG + IIN_MAX_LENGTH; 

    String IIN_EXPRESSION_ERR_MSG = IIN + DIGIT_EXP_MSG;
    
    //IFSC
    
    String IFSC = "IFSC";
	
	boolean IFSC_IS_MANDATORY = true;
	
	int IFSC_MIN_LENGTH = 4;
	
	int IFSC_MAX_LENGTH = 12;
	
	String IFSC_EXPRESSION = ALPHANUMARIC_EXP;
	
	String IFSC_MANDATORY_ERR_MSG = IFSC + MANDATORY_MSG;
	
	String IFSC_LENGTH_ERR_MSG = IFSC + MIN_LENGTH_MSG + IFSC_MIN_LENGTH + MAX_LENGTH_MSG + IFSC_MAX_LENGTH; 

    String IFSC_EXPRESSION_ERR_MSG = IFSC + ALPHABET_DIGIT_EXP_MSG;
    
    //Account Type
    
    String ACC_TYPE = "Account type";
	
	boolean ACC_TYPE_IS_MANDATORY = true;
	
	int ACC_TYPE_MIN_LENGTH = 4;
	
	int ACC_TYPE_MAX_LENGTH = 12;
	
	String ACC_TYPE_EXPRESSION = ALPHABET_EXP;
	
	String ACC_TYPE_MANDATORY_ERR_MSG = ACC_TYPE + MANDATORY_MSG;
	
	String ACC_TYPE_LENGTH_ERR_MSG = ACC_TYPE + MIN_LENGTH_MSG + ACC_TYPE_MIN_LENGTH + MAX_LENGTH_MSG + ACC_TYPE_MAX_LENGTH; 

    String ACC_TYPE_EXPRESSION_ERR_MSG = ACC_TYPE + ALPHABET_EXP_MSG;
    
    //Account number
    
    String ACC_NUM = "Account number";
	
	boolean ACC_NUM_IS_MANDATORY = true;
	
	int ACC_NUM_MIN_LENGTH = 4;
	
	int ACC_NUM_MAX_LENGTH = 20;
	
	String ACC_NUM_EXPRESSION = NUMARIC_EXP;
	
	String ACC_NUM_MANDATORY_ERR_MSG = ACC_NUM + MANDATORY_MSG;
	
	String ACC_NUM_LENGTH_ERR_MSG = ACC_NUM + MIN_LENGTH_MSG + ACC_NUM_MIN_LENGTH + MAX_LENGTH_MSG + ACC_NUM_MAX_LENGTH; 

    String ACC_NUM_EXPRESSION_ERR_MSG = ACC_NUM + DIGIT_EXP_MSG;
    
    //Card number
    
    String CARD_NUM = "Card number";
	
	boolean CARD_NUM_IS_MANDATORY = true;
	
	int CARD_NUM_MIN_LENGTH = 4;
	
	int CARD_NUM_MAX_LENGTH = 20;
	
	String CARD_NUM_EXPRESSION = NUMARIC_EXP;
	
	String CARD_NUM_MANDATORY_ERR_MSG = CARD_NUM + MANDATORY_MSG;
	
	String CARD_NUM_LENGTH_ERR_MSG = CARD_NUM + MIN_LENGTH_MSG + CARD_NUM_MIN_LENGTH + MAX_LENGTH_MSG + CARD_NUM_MAX_LENGTH; 

    String CARD_NUM_EXPRESSION_ERR_MSG = CARD_NUM + DIGIT_EXP_MSG;
    
     //OTP
    
    String OTP = "OTP";
	
	boolean OTP_IS_MANDATORY = true;
	
	int OTP_MIN_LENGTH = 4;
	
	int OTP_MAX_LENGTH = 10;
	
	String OTP_EXPRESSION = NUMARIC_EXP;
	
	String OTP_MANDATORY_ERR_MSG = OTP + MANDATORY_MSG;
	
	String OTP_LENGTH_ERR_MSG = OTP + MIN_LENGTH_MSG + OTP_MIN_LENGTH + MAX_LENGTH_MSG + OTP_MAX_LENGTH; 

    String OTP_EXPRESSION_ERR_MSG = OTP + DIGIT_EXP_MSG;
    
    //OLD PIN
    
    String OLD_PIN = "Old pin";
	
   	boolean PIN_IS_MANDATORY = true;
   	
   	int PIN_MIN_LENGTH = 4;
   	
   	int PIN_MAX_LENGTH = 20;
   	
   	String PIN_EXPRESSION = NUMARIC_EXP;
   	
   	String OLD_PIN_MANDATORY_ERR_MSG = OLD_PIN + MANDATORY_MSG;
   	
   	String OLD_PIN_LENGTH_ERR_MSG = OLD_PIN + MIN_LENGTH_MSG + PIN_MIN_LENGTH + MAX_LENGTH_MSG + PIN_MAX_LENGTH; 

    String OLD_PIN_EXPRESSION_ERR_MSG = OLD_PIN + DIGIT_EXP_MSG;
    
    //NEW PIN
    
    String NEW_PIN = "New pin";
	
   	String NEW_PIN_MANDATORY_ERR_MSG = NEW_PIN + MANDATORY_MSG;
   	
   	String NEW_PIN_LENGTH_ERR_MSG = NEW_PIN + MIN_LENGTH_MSG + PIN_MIN_LENGTH + MAX_LENGTH_MSG + PIN_MAX_LENGTH; 

    String NEW_PIN_EXPRESSION_ERR_MSG = NEW_PIN + DIGIT_EXP_MSG;
    
   //PIN
    
    String PIN = "Pin";
	
   	String PIN_MANDATORY_ERR_MSG = PIN + MANDATORY_MSG;
   	
   	String PIN_LENGTH_ERR_MSG = PIN + MIN_LENGTH_MSG + PIN_MIN_LENGTH + MAX_LENGTH_MSG + PIN_MAX_LENGTH; 

    String PIN_EXPRESSION_ERR_MSG = PIN + DIGIT_EXP_MSG;
    
    
    //Mpin
    
    String MPIN = "MPIN";
	
   	String MPIN_MANDATORY_ERR_MSG = MPIN + MANDATORY_MSG;
   	
   	String MPIN_LENGTH_ERR_MSG = MPIN + MIN_LENGTH_MSG + PIN_MIN_LENGTH + MAX_LENGTH_MSG + PIN_MAX_LENGTH; 

    String MPIN_EXPRESSION_ERR_MSG = MPIN + DIGIT_EXP_MSG;
    
    //Self virtual Address
    
    String SELF_VIRTUAL_ADDR = "Self virtual address";
    
	boolean VIRTUAL_ADDR_IS_MANDATORY = true;
   	
   	int VIRTUAL_ADDR_MIN_LENGTH = 7;
   	
   	int VIRTUAL_ADDR_MAX_LENGTH = 40;
   	
   	String VIRTUAL_ADDR_EXPRESSION = VIRTUAL_ADDRESS_EXP;
   	
   	String SELF_VIRTUAL_ADDR_MANDATORY_ERR_MSG = SELF_VIRTUAL_ADDR + MANDATORY_MSG;
   	
   	String SELF_VIRTUAL_ADDR_LENGTH_ERR_MSG = SELF_VIRTUAL_ADDR + MIN_LENGTH_MSG + VIRTUAL_ADDR_MIN_LENGTH + MAX_LENGTH_MSG + VIRTUAL_ADDR_MAX_LENGTH; 

    String SELF_VIRTUAL_ADDR_EXPRESSION_ERR_MSG = SELF_VIRTUAL_ADDR + VIRTUAL_ADDR_EXP_MSG;
    
   //Third_party virtual Address
    
    String THIRD_PARTY_VIRTUAL_ADDR = "Third party virtual address";
    
    String THIRD_PARTY_VIRTUAL_ADDR_MANDATORY_ERR_MSG = THIRD_PARTY_VIRTUAL_ADDR + MANDATORY_MSG;
   	
   	String THIRD_PARTY_VIRTUAL_ADDR_LENGTH_ERR_MSG = THIRD_PARTY_VIRTUAL_ADDR + MIN_LENGTH_MSG + VIRTUAL_ADDR_MIN_LENGTH + MAX_LENGTH_MSG + VIRTUAL_ADDR_MAX_LENGTH; 

    String THIRD_PARTY_VIRTUAL_ADDR_EXPRESSION_ERR_MSG = THIRD_PARTY_VIRTUAL_ADDR + VIRTUAL_ADDR_EXP_MSG;
    
    
    //Amount
    
    String AMOUNT = "Amount";
    
    boolean AMOUNT_IS_MANDATORY = true;
   	
   	int AMOUNT_MIN_LENGTH = 1;
   	
   	int AMOUNT_MAX_LENGTH = 50000;
   	
   	String AMOUNT_EXPRESSION = DECIMAL_NUMBER_EXP;
   	
   	String AMOUNT_MANDATORY_ERR_MSG = AMOUNT + MANDATORY_MSG;
   	
   	String AMOUNT_LENGTH_ERR_MSG = AMOUNT + AMOUNT_LEN_MSG; 

    String AMOUNT_EXPRESSION_ERR_MSG = AMOUNT + AMOUNT_EXPR_MSG;
    
    String AMOUNT_SHOULD_BE_POSITIVE_ERR_MSG = AMOUNT + "should be posivive";
    
    //From date
    
    String FROM_DATE = "From date";
    
    boolean DATE_IS_MANDATORY = false;
   	
   	int DATE_MIN_LENGTH = 10;
   	
   	int DATE_MAX_LENGTH = 10;
   	
   	String DATE_EXPRESSION = DATE_EXP;
   	
   	String FROM_DATE_MANDATORY_ERR_MSG = FROM_DATE + MANDATORY_MSG;
   	
   	String FROM_DATE_LENGTH_ERR_MSG = FROM_DATE + MIN_LENGTH_MSG + EMAIL_MIN_LENGTH + MAX_LENGTH_MSG + DATE_MAX_LENGTH; 

    String FROM_DATE_EXPRESSION_ERR_MSG = FROM_DATE + DATE_EXP_MSG;
    
    //to date
    
    String TO_DATE = "To date";
   	
   	String TO_DATE_MANDATORY_ERR_MSG = TO_DATE + MANDATORY_MSG;
   	
   	String TO_DATE_LENGTH_ERR_MSG = TO_DATE + MIN_LENGTH_MSG + EMAIL_MIN_LENGTH + MAX_LENGTH_MSG + DATE_MAX_LENGTH; 

    String TO_DATE_EXPRESSION_ERR_MSG = TO_DATE + DATE_EXP_MSG;
    
    // Nick name 
	
 	String NICK_NAME = "Nick name";
 	
 	boolean NICK_NAME_IS_MANDATORY = true;

 	int NICK_NAME_MIN_LENGTH = 3;
 	
 	int NICK_NAME_MAX_LENGTH = 30;
 	
 	String NICK_NAME_EXPRESSION = ALPHANUMARICSPACE_EXP;
 	
 	String NICK_NAME_MANDATORY_ERR_MSG = NICK_NAME + MANDATORY_MSG;
 	
 	String NICK_NAME_LENGTH_ERR_MSG = NICK_NAME + MIN_LENGTH_MSG + NICK_NAME_MIN_LENGTH + MAX_LENGTH_MSG + NICK_NAME_MAX_LENGTH;
 	
 	String NICK_NAME_EXPRESSION_ERR_MSG = NICK_NAME + ALPHANUMARICSPACE_ERR_MSG;
 	
  // Beneficiary note 
	
  	String BENEFICIARY_NOTE = "Beneficiary note";
  	
  	boolean BENEFICIARY_NOTE_IS_MANDATORY = false;

  	int BENEFICIARY_NOTE_MIN_LENGTH = 5;
  	
  	int BENEFICIARY_NOTE_MAX_LENGTH = 100;
  	
  	String BENEFICIARY_NOTE_EXPRESSION = ALPHANUMARIC_SPACE_SPECIALCHAR_EXP;
  	
  	String BENEFICIARY_NOTE_MANDATORY_ERR_MSG = BENEFICIARY_NOTE + MANDATORY_MSG;
  	
  	String BENEFICIARY_NOTE_LENGTH_ERR_MSG = BENEFICIARY_NOTE + MIN_LENGTH_MSG + BENEFICIARY_NOTE_MIN_LENGTH + MAX_LENGTH_MSG + BENEFICIARY_NOTE_MAX_LENGTH;
  	
  	String BENEFICIARY_NOTE_EXPRESSION_ERR_MSG = BENEFICIARY_NOTE + ALPHANUMARIC_SPACE_SPLCHAR_ERR_MSG;
  	
  // Txn note 
	
   	String TXN_NOTE = "Transaction note";
   	
   	boolean TXN_NOTE_IS_MANDATORY = true;

   	int TXN_NOTE_MIN_LENGTH = 5;
   	
   	int TXN_NOTE_MAX_LENGTH = 100;
   	
   	String TXN_NOTE_EXPRESSION = ALPHANUMARICSPACE_EXP;
   	
   	String TXN_NOTE_MANDATORY_ERR_MSG = TXN_NOTE + MANDATORY_MSG;
   	
   	String TXN_NOTE_LENGTH_ERR_MSG = TXN_NOTE + MIN_LENGTH_MSG + TXN_NOTE_MIN_LENGTH + MAX_LENGTH_MSG + TXN_NOTE_MAX_LENGTH;
   	
   	String TXN_NOTE_EXPRESSION_ERR_MSG = TXN_NOTE + ALPHANUMARICSPACE_ERR_MSG;
}