package psp.mobile.model.response;

import psp.constants.StatusCode;

@SuppressWarnings("serial")
public class ForgetPasswordSubmitResponse extends MessageResponse {
	
	public ForgetPasswordSubmitResponse() {
	}
	
	public boolean validate() {
		boolean isSuccess = true;

		if (!isSuccess) {
			setStatusCode(StatusCode.FIELD_VALIDATION_FAILED.getCode());
			setStatusMessage(StatusCode.FIELD_VALIDATION_FAILED.getMessage());
		}
		return isSuccess;
	}
	
	public static ForgetPasswordSubmitResponse constructForgetPasswordSubmitResponse(String jsonStr){		
		ForgetPasswordSubmitResponse response = null;
		if(jsonStr != null && !"".equals(jsonStr)){	
			response = new ForgetPasswordSubmitResponse();
			response.constructMessageRespnse(jsonStr);
		}
		return response;
	}

}
