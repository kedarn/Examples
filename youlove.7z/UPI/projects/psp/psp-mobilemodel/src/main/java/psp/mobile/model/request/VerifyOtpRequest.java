package psp.mobile.model.request;

import org.json.JSONObject;

@SuppressWarnings("serial")
public class VerifyOtpRequest extends MobileRequest {
	
	private String mobileNumber;
	
	private String otp;
	
	public VerifyOtpRequest() {
	}

	public String getMobileNumber() {
		return mobileNumber;
	}

	public void setMobileNumber(String mobileNumber) {
		this.mobileNumber = mobileNumber;
	}

	public String getOtp() {
		return otp;
	}

	public void setOtp(String otp) {
		this.otp = otp;
	}
	
	public String toJsonString() {
		 JSONObject jobj = getJsonString();
		 jobj.put("mobileNumber", mobileNumber);
		 jobj.put("otp", otp);
		 return jobj.toString();
	}

}
