/**
 * 
 */
package psp.mobile.model.response;

import org.json.JSONObject;

import psp.common.model.BillDetails;
import psp.constants.StatusCode;

/**
 * @author prasadj
 *
 */
@SuppressWarnings("serial")
public class VerifyCustomerMerchantResponse extends MessageResponse {

	private MerchantDetails merchant;
	
	private BillDetails billDetails;
	
	public VerifyCustomerMerchantResponse() {
	}

	public MerchantDetails getMerchant() {
		return merchant;
	}

	public void setMerchant(MerchantDetails merchant) {
		this.merchant = merchant;
	}

	public BillDetails getBillDetails() {
		return billDetails;
	}

	public void setBillDetails(BillDetails billDetails) {
		this.billDetails = billDetails;
	}

	public boolean validate() {
		boolean isSuccess = true;
		if (!isSuccess) {
			setStatusCode(StatusCode.FIELD_VALIDATION_FAILED.getCode());
			setStatusMessage(StatusCode.FIELD_VALIDATION_FAILED.getMessage()); 
		}
		return isSuccess;
	}
	
	public static VerifyCustomerMerchantResponse constructVerifyCustomerMerchantResponse(String jsonStr){	
		VerifyCustomerMerchantResponse response = null;
		if(jsonStr != null && !"".equals(jsonStr)){	
			JSONObject jsonObj = new JSONObject(jsonStr);
			response = new VerifyCustomerMerchantResponse();
			response.constructMessageRespnse(jsonStr);		
			String asStr = jsonObj.optString("merchantDetails", null);
			if(asStr != null && !asStr.equals("null")) {
				response.merchant = MerchantDetails.construcMerchantDetails(asStr);			
			}
			asStr = jsonObj.optString("billDetails", null);
			if(asStr != null && !asStr.equals("null")) {
				response.billDetails = BillDetails.constructBillDetails(asStr);			
			}
		}
		return response;
	}
	
}