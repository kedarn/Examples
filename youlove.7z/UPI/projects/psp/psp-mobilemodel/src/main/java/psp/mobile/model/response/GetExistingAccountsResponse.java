package psp.mobile.model.response;

import org.json.JSONObject;

import psp.common.model.AccountSummary;
import psp.constants.StatusCode;

@SuppressWarnings("serial")
public class GetExistingAccountsResponse extends MessageResponse {

	private AccountSummary accountSummary;

	public GetExistingAccountsResponse() {
	}

	public AccountSummary getAccountSummary() {
		return accountSummary;
	}

	public void setAccountSummary(AccountSummary accountSummary) {
		this.accountSummary = accountSummary;
	}
	
	public boolean validate() {
		boolean isSuccess = true;

		if (!isSuccess) {
			setStatusCode(StatusCode.FIELD_VALIDATION_FAILED.getCode());
			setStatusMessage(StatusCode.FIELD_VALIDATION_FAILED.getMessage());
		}
		return isSuccess;
	}
	
	public static GetExistingAccountsResponse constructGetExistingAccountsResponse(String jsonStr){	
		GetExistingAccountsResponse response = null;
		if(jsonStr != null && !"".equals(jsonStr)){	
			response = new GetExistingAccountsResponse();
			response.constructMessageRespnse(jsonStr);
			JSONObject jsonObj = new JSONObject(jsonStr);
			String asStr = jsonObj.optString("accountSummary", null);
			if(asStr != null && !asStr.equals("null")) {
				response.accountSummary = AccountSummary.constructAccountSummary(asStr);
			}
		}
		return response;
	}
	
}