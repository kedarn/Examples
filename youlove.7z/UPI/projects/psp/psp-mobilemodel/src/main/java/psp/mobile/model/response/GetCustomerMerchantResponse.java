/**
 * 
 */
package psp.mobile.model.response;

import java.util.ArrayList;
import java.util.List;

import org.json.JSONArray;
import org.json.JSONObject;

import psp.constants.StatusCode;

/**
 * @author prasadj
 *
 */
@SuppressWarnings("serial")
public class GetCustomerMerchantResponse extends MessageResponse {

	private List<MerchantDetails> merchantList;
	
	public GetCustomerMerchantResponse() {
	}

	public List<MerchantDetails> getMerchantList() {
		return merchantList;
	}

	public void setMerchantList(List<MerchantDetails> merchantList) {
		this.merchantList = merchantList;
	}

	public boolean validate() {
		boolean isSuccess = true;
		
		if (!isSuccess) {
			 setStatusCode(StatusCode.FIELD_VALIDATION_FAILED.getCode());
			 setStatusMessage(StatusCode.FIELD_VALIDATION_FAILED.getMessage());
		}
		return isSuccess;
	}
	
	public static GetCustomerMerchantResponse constructGetCustomerMerchantResponse(String jsonStr){		
		GetCustomerMerchantResponse response = null;
		if(jsonStr != null && !"".equals(jsonStr)){	
			JSONObject jsonObj = new JSONObject(jsonStr);
			response = new GetCustomerMerchantResponse();					
			List<MerchantDetails> merchantDtlsList = null;	
			try{
				JSONArray merchantList = jsonObj.getJSONArray("merchantList");
				merchantDtlsList = new ArrayList<>();	
				 for(int i = 0; i < merchantList.length(); i++){
					 JSONObject merchantDtls = merchantList.getJSONObject(i);
					 MerchantDetails merchant = MerchantDetails.construcMerchantDetails(merchantDtls);
					 merchantDtlsList.add(i, merchant);
				 }	
			}
			catch(Exception e) {
			}			
			response.merchantList = merchantDtlsList;
			response.constructMessageRespnse(jsonStr);
		}
		return response;
	}
	
}