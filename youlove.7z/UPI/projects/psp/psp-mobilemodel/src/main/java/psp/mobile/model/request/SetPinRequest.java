package psp.mobile.model.request;

import org.json.JSONObject;


@SuppressWarnings("serial")
public class SetPinRequest extends MobileRequest {

	private Boolean isChangePin;
	
	private MobileCredentials oldCredentials;
	
	private MobileCredentials newCredentials;

	public SetPinRequest() {
	}

	public Boolean getIsChangePin() {
		return isChangePin;
	}

	public void setIsChangePin(Boolean isChangePin) {
		this.isChangePin = isChangePin;
	}

	public MobileCredentials getOldCredentials() {
		return oldCredentials;
	}

	public void setOldCredentials(MobileCredentials oldCredentials) {
		this.oldCredentials = oldCredentials;
	}

	public MobileCredentials getNewCredentials() {
		return newCredentials;
	}

	public void setNewCredentials(MobileCredentials newCredentials) {
		this.newCredentials = newCredentials;
	}

	public String toJsonString() {
		 JSONObject jobj = getJsonString();
		 jobj.put("isChangePin", isChangePin);
		 if(oldCredentials != null) {
			 jobj.put("oldCredentials", oldCredentials.toJsonString());
		 }
		 if(newCredentials != null) {
			 jobj.put("newCredentials", newCredentials.toJsonString());
		 }
		 return jobj.toString();
	}

}