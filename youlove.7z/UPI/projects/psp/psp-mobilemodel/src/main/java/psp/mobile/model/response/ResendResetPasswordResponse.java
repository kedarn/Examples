package psp.mobile.model.response;

import psp.constants.StatusCode;

@SuppressWarnings("serial")
public class ResendResetPasswordResponse extends MessageResponse {

	public ResendResetPasswordResponse() {
	}
	
	public boolean validate() {
		boolean isSuccess = true;

		if (!isSuccess) {
			setStatusCode(StatusCode.FIELD_VALIDATION_FAILED.getCode());
			setStatusMessage(StatusCode.FIELD_VALIDATION_FAILED.getMessage());
		}
		return isSuccess;
	}
	
	public static ResendResetPasswordResponse constructResendResetPasswordResponse(String jsonStr){		
		ResendResetPasswordResponse response = null;
		if(jsonStr != null && !"".equals(jsonStr)){	
			response = new ResendResetPasswordResponse();
			response.constructMessageRespnse(jsonStr);
		}
		return response;
	}
	
}
