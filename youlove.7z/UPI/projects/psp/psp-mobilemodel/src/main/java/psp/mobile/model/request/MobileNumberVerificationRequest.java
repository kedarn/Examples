package psp.mobile.model.request;

import org.json.JSONObject;

@SuppressWarnings("serial")
public class MobileNumberVerificationRequest extends MobileRequest {

	private String mobileNumber;
	
	public MobileNumberVerificationRequest() {
	}

	public String getMobileNumber() {
		return mobileNumber;
	}

	public void setMobileNumber(String mobileNumber) {
		this.mobileNumber = mobileNumber;
	}
	
	public String toJsonString() {
		 JSONObject jobj = getJsonString();
		 jobj.put("mobileNumber", mobileNumber);
		 return jobj.toString();
	}
	
}
