/**
 * 
 */
package psp.reports.constants;

/**
 * @author prasadj
 *
 */
public enum ReportType {

	USER_TXNS(1, "USER_TXNS", "User Transaction History");
	
	private final int value;

	private final String name;
	
	private final String filename;
	
	private ReportType(int value, String filename, String name){
		this.value = value;
		this.filename = filename;
		this.name = name;
	}
	
	public int getValue() {
		return value;
	}

	public String getName() {
		return name;
	}

	public String getFilename() {
		return filename;
	}

	public static ReportType getReportType(int value) {
		if (USER_TXNS.value == value) {
			return USER_TXNS;
		}else {
			return null;
		}
	}
	
}