/**
 * 
 */
package psp.reports.mgmt.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import psp.dbservice.mgmt.PspMgmtService;
import psp.reports.constants.ReportType;
import psp.reports.dao.ReportsDao;
import psp.reports.dto.ReportsDataDto;
import psp.reports.dto.ReportsInputDto;
import psp.reports.mgmt.ReportsMgmtService;

/**
 * @author prasadj
 *
 */
@Component("reportsService")
@Transactional (rollbackFor = Exception.class)
public class ReportsMgmtServiceImpl implements ReportsMgmtService {

	@Autowired
	private ReportsDao reportsDao;
	
	@Autowired
	private PspMgmtService pspMgmtService;
	
	public ReportsMgmtServiceImpl(){
	}
	
	@Override
	public List<ReportsDataDto> getReportList(ReportsInputDto input) {
		List<ReportsDataDto> list = null;
		if(input.getReportType() == ReportType.USER_TXNS){
			list = reportsDao.userTransactions(input);
		}
		
		return list;
	}

}