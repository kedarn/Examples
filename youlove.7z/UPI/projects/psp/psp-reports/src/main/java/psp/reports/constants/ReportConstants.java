/**
 * 
 */
package psp.reports.constants;

/**
 * @author prasadj
 *
 */
public interface ReportConstants {

	String PRODUCT_NAME_FLD = "productName";
	
	String PRODUCT_NAME_HDR = "Product Name";
	
	String CUSTOMER_ID_FLD = "customerId";
	
	String CUSTOMER_ID_HDR = "Customer Id";
	
	String AMOUNT_STR_FLD = "amountStr";
	
	String AMOUNT_STR_HDR = "Amount";
	
	String TOTAL_HDR = "Total";
	
	String NET_DISBURSEMENT_HDR = "Net Disbursement";
	
	String NET_COLLECTION_HDR = "Net Collection";
	
	String TOTAL_DUE_HDR = "Total Due";
	
	String REAGION_NAME_FLD = "regionName";
	
	String REGION_NAME_HDR = "Region";
	
	String SUB_REAGION_NAME_FLD = "subRegionName";
	
	String SUB_REGION_NAME_HDR = "Sub Region";
	
	String NUMBER_FLD = "number";
	
	String NUMBER_HDR = "Account Id";
	
	String APPLICATION_ID_HDR = "Application Id";
	
	String CUSTOMER_NAME_FLD = "customerName";
	
	String CUSTOMER_NAME_HDR = "Customer Name";

	String DATE_FLD = "date";
	
	String DATE_HDR = "Date";
	
	String START_DATE_HDR = "Start Date";
	
	String APPROVED_DATE_HDR = "Approved Date";
	
	String TO_DATE_FLD = "toDate";
	
	String TO_DATE_HDR = "End Date";

	String EMIS_AMOUNT_FLD = "emisAmountStr";
	
	String EMIS_TOTAL_HDR = "EMIs Total";

	String DISBURSEMENT_AMOUNT_HDR = "Disbursement Amount";
	
	String PENALTIES_AMOUNT_FLD = "penaltiesAmountStr";
	
	String PENALTIES_TOTAL_HDR = "Penalties Total";
	
	String PENALTIES_DUE_HDR = "Penalties Due";
	
	String PRE_CHARGES_HDR = "Pre Charges";
	
	String EMAIL_FLD = "emailId";
	
	String EMAIL_HDR = "Email";

	String PHONE_NUMBER_FLD = "phoneNumber";
			
	String PHONE_NUMBER_HDR = "Phone Number";
	
	String REPORT_SUB_HEADING = "PSP";
	
	String MESSAGE_FLD = "message";
	
	String ENQUIRY_MESSAGE_HRD = "Message Enquiry";
	
	String TYPE_FLD = "type";
	
	String QUERY_TYPE_HRD = "Query Type";
	
	String ENQUIRY_DATE_HRD = "Enquiry Date";
	
	
	
	
	
}