/**
 * 
 */
package psp.reports.constants;

/**
 * @author prasadj
 *
 */
public enum RCStyle {

	STRING_LEFT,
	STRING_RIGHT,
	NUMBER_LEFT,
	NUMBER_RIGHT;
	
}