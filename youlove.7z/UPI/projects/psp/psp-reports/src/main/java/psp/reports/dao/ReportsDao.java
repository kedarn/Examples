/**
 * 
 */
package psp.reports.dao;

import java.util.List;

import psp.reports.dto.ReportsDataDto;
import psp.reports.dto.ReportsInputDto;

/**
 * @author prasadj
 *
 */
public interface ReportsDao {

	List<ReportsDataDto> userTransactions(ReportsInputDto input);
	
}