/**
 * 
 */
package psp.reports.util;

import java.util.ArrayList;
import java.util.List;

import psp.reports.constants.ReportType;

/**
 * @author prasadj
 *
 */
public class ReportsUtil {

	private ReportsUtil(){
	}
	
	public static List<ReportType> getReportTypeList(){

		List<ReportType> list = new ArrayList<ReportType>();
		list.add(ReportType.USER_TXNS);

		return list;
	}
	
}