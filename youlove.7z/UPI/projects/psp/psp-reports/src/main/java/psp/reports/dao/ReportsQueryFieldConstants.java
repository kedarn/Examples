/**
 * 
 */
package psp.reports.dao;

/**
 * @author malleshamk
 *
 */
public interface ReportsQueryFieldConstants {

	String FROM_DATE_QFLD = "fromDate";
	
	String TO_DATE_QFLD = "toDate";
	
	String TXN_STATUS_QFLD = "txnStatus";
}
