/**
 * 
 */
package psp.reports.constants;

/**
 * @author prasadj
 *
 */
public enum DownloadType {

	PDF(1, "pdf"), 
	CSV(2, "csv");
	
	private final int value;

	private final String name;
	
	private DownloadType(int value, String name){
		this.value = value;
		this.name = name;
	}
	
	public int getValue() {
		return value;
	}

	public String getName() {
		return name;
	}

	public static DownloadType getDownloadType(int value) {
		if (PDF.value == value) {
			return PDF;
		} else if (CSV.value == value) {
			return CSV;
		}  else {
			return null;
		}
	}
	
}