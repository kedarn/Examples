/**
 * 
 */
package psp.reports.mgmt;

import java.util.List;

import psp.reports.dto.ReportsDataDto;
import psp.reports.dto.ReportsInputDto;

/**
 * @author prasadj
 *
 */
public interface ReportsMgmtService {

	List<ReportsDataDto> getReportList(ReportsInputDto input);

}
