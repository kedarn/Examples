/**
 * 
 */
package psp.reports.dto;

import java.util.Date;

import psp.reports.constants.DownloadType;
import psp.reports.constants.ReportType;

/**
 * @author prasadj
 *
 */
public class ReportsInputDto {

	private ReportType reportType;
	
	private Integer reportTypeIntr;
	
	private DownloadType downloadType;

	private Integer downloadTypeIntr;
	
	private Date fromDate;

	private String fromDateStr;
	
	private Date toDate;

	private String toDateStr;
	
	private Integer txnStatus;

	public ReportsInputDto(){
	}
	
	public ReportType getReportType() {
		return reportType;
	}

	public void setReportType(ReportType reportType) {
		this.reportType = reportType;
	}

	public Integer getReportTypeIntr() {
		return reportTypeIntr;
	}

	public void setReportTypeIntr(Integer reportTypeIntr) {
		this.reportTypeIntr = reportTypeIntr;
		if (reportTypeIntr != null) {
			reportType = ReportType.getReportType(reportTypeIntr);
		} else {
			reportType = null;
		}
	}
	
	public DownloadType getDownloadType() {
		return downloadType;
	}

	public void setDownloadType(DownloadType downloadType) {
		this.downloadType = downloadType;
	}

	public Integer getDownloadTypeIntr() {
		return downloadTypeIntr;
	}

	public void setDownloadTypeIntr(Integer downloadTypeIntr) {
		this.downloadTypeIntr = downloadTypeIntr;
		if (downloadTypeIntr != null) {
			downloadType = DownloadType.getDownloadType(downloadTypeIntr);
		} else {
			downloadType = null;
		}
	}
	
	public Date getFromDate() {
		return fromDate;
	}

	public void setFromDate(Date fromDate) {
		this.fromDate = fromDate;
	}

	public String getFromDateStr() {
		return fromDateStr;
	}

	public void setFromDateStr(String fromDateStr) {
		this.fromDateStr = fromDateStr;
	}

	public Date getToDate() {
		return toDate;
	}

	public void setToDate(Date toDate) {
		this.toDate = toDate;
	}

	public String getToDateStr() {
		return toDateStr;
	}

	public void setToDateStr(String toDateStr) {
		this.toDateStr = toDateStr;
	}

	public Integer getTxnStatus() {
		return txnStatus;
	}

	public void setTxnStatus(Integer txnStatus) {
		this.txnStatus = txnStatus;
	}
	
}