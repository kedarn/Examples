/**
 * 
 */
package psp.reports.util;

import java.awt.Color;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import net.sf.jasperreports.engine.JasperPrint;
import net.sf.jasperreports.engine.JasperReport;
import net.sf.jasperreports.engine.data.JRBeanCollectionDataSource;
import ar.com.fdvs.dj.core.DynamicJasperHelper;
import ar.com.fdvs.dj.core.layout.ClassicLayoutManager;
import ar.com.fdvs.dj.domain.DynamicReport;
import ar.com.fdvs.dj.domain.Style;
import ar.com.fdvs.dj.domain.builders.ColumnBuilder;
import ar.com.fdvs.dj.domain.builders.ColumnBuilderException;
import ar.com.fdvs.dj.domain.builders.DynamicReportBuilder;
import ar.com.fdvs.dj.domain.builders.StyleBuilder;
import ar.com.fdvs.dj.domain.constants.Border;
import ar.com.fdvs.dj.domain.constants.Font;
import ar.com.fdvs.dj.domain.constants.HorizontalAlign;
import ar.com.fdvs.dj.domain.constants.Stretching;
import ar.com.fdvs.dj.domain.constants.Transparency;
import ar.com.fdvs.dj.domain.constants.VerticalAlign;
import ar.com.fdvs.dj.domain.entities.columns.AbstractColumn;

import psp.reports.constants.RCStyle;
import psp.reports.dto.Report;
import psp.reports.dto.ReportColumn;
import psp.reports.dto.ReportsDataDto;


/**
 * @author prasadj
 *
 */
@SuppressWarnings({"unchecked", "rawtypes"})
public class IReport {

	private final Color titileColor = new Color(0, 0, 222);

	private final Color stitileColor = new Color(0, 222, 222);

	private final Color columnHeaderColor = new Color(0, 0, 222);

	private final Color columnHeaderBGColor = new Color(222, 222, 222);

	private final Report mfsReport;
	
	private String templatePath;
	
	public IReport(Report mfsReport, String templatePath) {
        this.mfsReport = mfsReport;
        this.templatePath = templatePath;
    }
	
    public IReport(Report mfsReport) {
        this.mfsReport = mfsReport;
    }
 
    public JasperPrint getReport(List<ReportsDataDto> list) throws Exception {
        DynamicReport dynaReport = getReportBody();
        return DynamicJasperHelper.generateJasperPrint(dynaReport, new ClassicLayoutManager(), new JRBeanCollectionDataSource(list));
    }
    
	public JasperReport getJasperReport() throws Exception {
        DynamicReport dynaReport = getReportBody();
		Map map = new HashMap();
        map.put("footer", "<my footer message>");
        return DynamicJasperHelper.generateJasperReport(dynaReport, new ClassicLayoutManager(), map);
    }
    
    private AbstractColumn createColumn(String property,  Class type, String title, int width, Style detailStyle) throws ColumnBuilderException {
        return ColumnBuilder.getNew()
                .setColumnProperty(property, type.getName()).setTitle(title).setWidth(Integer.valueOf(width))
                .setStyle(detailStyle).setHeaderStyle(createColumnHeaderStyle()).build();
    }
 
    private DynamicReport getReportBody() throws ColumnBuilderException, ClassNotFoundException {
        
        DynamicReportBuilder report = new DynamicReportBuilder();
        report.setTemplateFile(templatePath);
        for( ReportColumn column: mfsReport.getColumns()){
        	AbstractColumn ac = createColumn(column.getPropertyName(), column.getType().getCname(), 
        			column.getHeaderTxt(), column.getWidth(), getColumnCellStyle(column.getStyle()));
        	report.addColumn(ac);
        }
        
        report.setTitle(mfsReport.getReportHeader());
        report.setTitleStyle(getTitleStyle());
        report.setSubtitle(mfsReport.getReportSubHeader());
        report.setSubtitleStyle(getSubTitleStyle());
        report.setUseFullPageWidth(true);
        report.setLeftMargin(40);
        report.setRightMargin(40);
        report.setBottomMargin(20);
        return report.build();
    }  
    
	private Style getColumnCellStyle(RCStyle rcStyle){
		if(RCStyle.STRING_LEFT == rcStyle || RCStyle.NUMBER_LEFT == rcStyle){
			return createDetailCellTextStyle();
		}
		else if(RCStyle.NUMBER_RIGHT == rcStyle || RCStyle.STRING_RIGHT == rcStyle){
			return createDetailCellNumberStyle();
		}
		else {
			return null;
		}
	}
	
    private Style getTitleStyle(){
    	StyleBuilder titleStyle = new StyleBuilder(true);
        titleStyle.setHorizontalAlign(HorizontalAlign.CENTER);
        titleStyle.setFont(new Font(20, Font._FONT_GEORGIA, true));
        titleStyle.setTextColor(titileColor);
        return titleStyle.build();
    }
    
    private Style getSubTitleStyle(){
    	StyleBuilder subTitleStyle=new StyleBuilder(true);
        subTitleStyle.setHorizontalAlign(HorizontalAlign.CENTER);
        subTitleStyle.setFont(new Font(Font.MEDIUM, Font._FONT_GEORGIA, true));
        subTitleStyle.setTextColor(stitileColor);
        return subTitleStyle.build();
    }
    
    private Style createColumnHeaderStyle() {        
        StyleBuilder sb = new StyleBuilder(true);
        sb.setFont(Font.VERDANA_MEDIUM_BOLD);
        sb.setBorder(Border.THIN());
        sb.setBorderBottom(Border.PEN_2_POINT());
        sb.setStretching(Stretching.RELATIVE_TO_BAND_HEIGHT);
        sb.setBorderColor(Color.BLACK);
        sb.setTextColor(columnHeaderColor);
        sb.setBackgroundColor(columnHeaderBGColor);
        sb.setHorizontalAlign(HorizontalAlign.CENTER);
        sb.setVerticalAlign(VerticalAlign.MIDDLE);
        sb.setTransparency(Transparency.OPAQUE);        
        return sb.build();
    }

    private Style createDetailCellTextStyle(){
        StyleBuilder sb = new StyleBuilder(true);
        sb.setFont(Font.VERDANA_MEDIUM);
        sb.setStretching(Stretching.RELATIVE_TO_BAND_HEIGHT);
        sb.setBorder(Border.PEN_1_POINT());        
        sb.setBorderColor(Color.BLACK);        
        sb.setTextColor(Color.BLACK);
        sb.setHorizontalAlign(HorizontalAlign.LEFT);
        sb.setVerticalAlign(VerticalAlign.MIDDLE);
        sb.setPaddingLeft(5);   
        return sb.build();
    }
    
      private Style createDetailCellNumberStyle(){
        StyleBuilder sb = new StyleBuilder(true);
        sb.setFont(Font.VERDANA_MEDIUM);
        sb.setBorder(Border.PEN_1_POINT());        
        sb.setStretching(Stretching.RELATIVE_TO_BAND_HEIGHT);
        sb.setBorderColor(Color.BLACK);        
        sb.setTextColor(Color.BLACK);
        sb.setHorizontalAlign(HorizontalAlign.RIGHT);
        sb.setVerticalAlign(VerticalAlign.MIDDLE);
        sb.setPaddingRight(5);        
        return sb.build();
    }
    
}