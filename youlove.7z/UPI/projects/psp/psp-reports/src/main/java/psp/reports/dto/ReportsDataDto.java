/**
 * 
 */
package psp.reports.dto;

/**
 * @author prasadj
 *
 */
public class ReportsDataDto {

	private String amount;
	
	private String amountStr;
	
	private String fromAddr;
	
	private String toAddr;
	
	public ReportsDataDto(){
		
	}
	//for simple report
	public ReportsDataDto(String amount, String fromAddr, String toAddr){
		this.amount = amount;
		this.fromAddr = fromAddr;
		this.toAddr = toAddr;
		this.amountStr = amount;
	}

	public String getAmount() {
		return amount;
	}

	public void setAmount(String amount) {
		this.amount = amount;
	}

	public String getAmountStr() {
		return amountStr;
	}

	public void setAmountStr(String amountStr) {
		this.amountStr = amountStr;
	}

	public String getFromAddr() {
		return fromAddr;
	}

	public void setFromAddr(String fromAddr) {
		this.fromAddr = fromAddr;
	}

	public String getToAddr() {
		return toAddr;
	}

	public void setToAddr(String toAddr) {
		this.toAddr = toAddr;
	}
	
	
}
