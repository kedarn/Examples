/**
 * 
 */
package psp.reports.util;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import psp.reports.constants.RCDataType;
import psp.reports.constants.RCStyle;
import psp.reports.constants.ReportConstants;
import psp.reports.constants.ReportType;
import psp.reports.dto.Report;
import psp.reports.dto.ReportColumn;

/**
 * @author prasadj
 *
 */
public class UpiReportConstructor implements ReportConstants {

	private static Map<ReportType, Report> REPORTS_DEFINITIONS;
	
	private UpiReportConstructor(){
	}
	
	public static Map<ReportType, Report> getAllReports(){
		if(REPORTS_DEFINITIONS == null){
			REPORTS_DEFINITIONS = constructReports();
		}
		return REPORTS_DEFINITIONS;
	}
	
	private static Map<ReportType, Report> constructReports(){
		
		Map<ReportType, Report> reports = new HashMap<ReportType, Report>();
		userTxnReport(reports);
		
		return reports;
	}
	
	private static void userTxnReport(Map<ReportType, Report> reports){
		ReportType rt = ReportType.USER_TXNS;
		Report report = new Report(rt.getValue(), rt.getName(), REPORT_SUB_HEADING, rt.getFilename());
		List<ReportColumn> columns = new ArrayList<ReportColumn>();
		columns.add(new ReportColumn("fromAddr", "From Address", RCDataType.STRING, 40, RCStyle.STRING_LEFT));
		columns.add(new ReportColumn("toAddr", "To Address", RCDataType.STRING, 40, RCStyle.STRING_LEFT));
		columns.add(new ReportColumn(AMOUNT_STR_FLD, AMOUNT_STR_HDR, RCDataType.STRING, 40, RCStyle.STRING_LEFT));
		report.setColumns(columns);
		reports.put(rt, report);
	}
	
}