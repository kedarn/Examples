/**
 * 
 */
package psp.reports.util;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import net.sf.jasperreports.engine.JasperReport;
import net.sf.jasperreports.engine.JasperRunManager;
import net.sf.jasperreports.engine.data.JRBeanCollectionDataSource;

import org.apache.commons.lang3.reflect.FieldUtils;
import org.apache.log4j.Logger;

import psp.constants.CommonConstants;
import psp.reports.constants.ReportType;
import psp.reports.dto.Report;
import psp.reports.dto.ReportColumn;
import psp.reports.dto.ReportsDataDto;
import psp.reports.dto.ReportsInputDto;


/**
 * @author prasadj
 *
 */
@SuppressWarnings({"unchecked", "rawtypes"})
public class ReportConstructor {

	private static final Logger LOGGER = Logger.getLogger(ReportConstructor.class.getName());
	
	private List<ReportsDataDto> data;
	
	private ReportsInputDto reportSearch;
	
	public ReportConstructor(List<ReportsDataDto> data, ReportsInputDto reportSearch){
		this.data = data;
		this.reportSearch = reportSearch;
		if(data == null){
			this.data = new ArrayList<ReportsDataDto>();
		}
		if(data.isEmpty()){
			this.data.add(new ReportsDataDto());
		}
	}

	public byte[] generatePdfReport(String jrxmlPath) throws Exception {
		JRBeanCollectionDataSource beanColDataSource = new JRBeanCollectionDataSource(data);
		Map parameters = new HashMap();
		Map<ReportType, Report> reportDefs = UpiReportConstructor.getAllReports();
        IReport report = new IReport(reportDefs.get(reportSearch.getReportType()), jrxmlPath);
        JasperReport jp = report.getJasperReport();
		return JasperRunManager.runReportToPdf(jp, parameters, beanColDataSource);
	}
	
	public byte[] generateCsvReport(){
		StringBuilder sb = new StringBuilder();
		ReportType reportType = reportSearch.getReportType();
		Report mfsr = UpiReportConstructor.getAllReports().get(reportType);
		
		sb.append(mfsr.getReportHeader());
		sb.append(CommonConstants.NEWLINE_CHAR);
		sb.append(mfsr.getReportSubHeader());
		sb.append(CommonConstants.NEWLINE_CHAR);
		for(ReportColumn mfscolumn: mfsr.getColumns()){
			sb.append(mfscolumn.getHeaderTxt());
			sb.append(CommonConstants.CAMMA);
		}
		sb.append(CommonConstants.NEWLINE_CHAR);

		try {
			for(ReportsDataDto dto: data){
				for(ReportColumn mfscolumn: mfsr.getColumns()){
					Object fieldValue = FieldUtils.readField(dto, mfscolumn.getPropertyName(), true);
					if(fieldValue != null){
						sb.append(fieldValue.toString());
					}
					sb.append(CommonConstants.CAMMA);
				}
				sb.append(CommonConstants.NEWLINE_CHAR);
			}
		}
		catch(Exception ex){
			LOGGER.info(ex.toString(), ex);
		}
		return sb.toString().getBytes();
	}
	
}