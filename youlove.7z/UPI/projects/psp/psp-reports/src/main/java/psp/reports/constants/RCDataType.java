/**
 * 
 */
package psp.reports.constants;


/**
 * @author prasadj
 *
 */
@SuppressWarnings("rawtypes")
public enum RCDataType {

	STRING(1, String.class),
	INTEGER(2, Integer.class),
	FLOAT(3, Float.class),
	LONG(4, Long.class);
	
	private final int value;

	private final Class cname;
	
	private RCDataType(int value, Class cname){
		this.value = value;
		this.cname = cname;
	}
	
	public static RCDataType getRCDataType(int value) {
		if (STRING.value == value) {
			return STRING;
		} else if (INTEGER.value == value) {
			return INTEGER;
		} else if (FLOAT.value == value) {
			return FLOAT;
		}else if (LONG.value == value) {
			return LONG;
		}
		else {
			return null;
		}
	}

	public int getValue() {
		return value;
	}

	public Class getCname() {
		return cname;
	}
	
}