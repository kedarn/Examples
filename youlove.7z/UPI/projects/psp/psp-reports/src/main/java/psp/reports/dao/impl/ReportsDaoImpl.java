/**
 * 
 */
package psp.reports.dao.impl;

import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.orm.hibernate4.HibernateCallback;
import org.springframework.orm.hibernate4.HibernateTemplate;
import org.springframework.stereotype.Component;

import psp.constants.DateUtil;
import psp.reports.dao.ReportsDao;
import psp.reports.dao.ReportsQueryFieldConstants;
import psp.reports.dto.ReportsDataDto;
import psp.reports.dto.ReportsInputDto;

/**
 * @author prasadj
 *
 */
@SuppressWarnings({ "unchecked", "rawtypes" })
@Component
public class ReportsDaoImpl implements ReportsDao, ReportsQueryFieldConstants {

	@Autowired
	private HibernateTemplate hibernateTemplate;

	public ReportsDaoImpl(){
	}
	
	public List<ReportsDataDto> userTransactions(final ReportsInputDto input){
		return (List<ReportsDataDto>)hibernateTemplate.execute(new HibernateCallback<List<ReportsDataDto>>() {
			public List<ReportsDataDto> doInHibernate(Session session) {
				Query q = hibernateTemplate.getSessionFactory().getCurrentSession().createQuery(userTransactionsQuery(input));
				
				q.setParameter(FROM_DATE_QFLD, DateUtil.convertStringToDate(input.getFromDateStr()));
				q.setParameter(TO_DATE_QFLD, DateUtil.convertStringToDate(input.getToDateStr()));
				return q.list();
			}
		});
	}
	
	private String userTransactionsQuery(ReportsInputDto input){
		StringBuilder sb = new StringBuilder();
		sb.append("select new psp.reports.dto.ReportsDataDto(td.amount, td.fromAddr, td.toAddr) from TransactionDetails td");
		sb.append(" where td.txnInitiationTime >= :fromDate and td.txnInitiationTime <= :toDate");
				
		return sb.toString();
	}
}