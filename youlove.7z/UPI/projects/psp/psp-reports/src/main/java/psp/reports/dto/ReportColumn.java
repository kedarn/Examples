/**
 * 
 */
package psp.reports.dto;

import psp.reports.constants.RCDataType;
import psp.reports.constants.RCStyle;

/**
 * @author prasadj
 *
 */
public class ReportColumn {

	private String propertyName;
	
	private String headerTxt;
	
	private RCDataType	type;
	
	private int width;
	
	private RCStyle style;
	
	public ReportColumn(){
	}
	
	public ReportColumn(String propertyName, String headerTxt, RCDataType type, int width, RCStyle style){
		this.propertyName = propertyName;
		this.headerTxt = headerTxt;
		this.type = type;
		this.width = width;
		this.style = style;
	}

	public String getPropertyName() {
		return propertyName;
	}

	public void setPropertyName(String propertyName) {
		this.propertyName = propertyName;
	}

	public String getHeaderTxt() {
		return headerTxt;
	}

	public void setHeaderTxt(String headerTxt) {
		this.headerTxt = headerTxt;
	}

	public RCDataType getType() {
		return type;
	}

	public void setType(RCDataType type) {
		this.type = type;
	}

	public int getWidth() {
		return width;
	}

	public void setWidth(int width) {
		this.width = width;
	}

	public RCStyle getStyle() {
		return style;
	}

	public void setStyle(RCStyle style) {
		this.style = style;
	}
	
}