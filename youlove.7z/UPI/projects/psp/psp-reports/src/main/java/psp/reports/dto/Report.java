/**
 * 
 */
package psp.reports.dto;

import java.util.List;

/**
 * @author prasadj
 *
 */
public class Report {

	private Integer reportId;
	
	private String reportHeader;
	
	private String reportSubHeader;
	
	private String fileName;
	
	private List<ReportColumn> columns;
	
	public Report(){
	}

	public Report(Integer reportId, String reportHeader, String reportSubHeader, String fileName){
		this.reportId = reportId;
		this.reportHeader = reportHeader;
		this.reportSubHeader = reportSubHeader;
		this.fileName = fileName;
	}
	
	public Integer getReportId() {
		return reportId;
	}

	public void setReportId(Integer reportId) {
		this.reportId = reportId;
	}

	public String getReportHeader() {
		return reportHeader;
	}

	public void setReportHeader(String reportHeader) {
		this.reportHeader = reportHeader;
	}

	public String getReportSubHeader() {
		return reportSubHeader;
	}

	public void setReportSubHeader(String reportSubHeader) {
		this.reportSubHeader = reportSubHeader;
	}

	public String getFileName() {
		return fileName;
	}

	public void setFileName(String fileName) {
		this.fileName = fileName;
	}

	public List<ReportColumn> getColumns() {
		return columns;
	}

	public void setColumns(List<ReportColumn> columns) {
		this.columns = columns;
	}
	
}