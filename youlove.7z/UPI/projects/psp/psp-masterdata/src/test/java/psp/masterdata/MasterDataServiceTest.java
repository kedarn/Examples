package psp.masterdata;
/**
 * 
 */

import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

import psp.db.test.AbstractServiceTest;
import psp.user.service.CommonService;

/**
 * @author prasadj
 *
 */
public class MasterDataServiceTest extends AbstractServiceTest {

	@Autowired
	CommonService commonService;
	
	@Test
	public void sampleTest(){
		System.out.append("Master Data uploaded");
	}
	
}