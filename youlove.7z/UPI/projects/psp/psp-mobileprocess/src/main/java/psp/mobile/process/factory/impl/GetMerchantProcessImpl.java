package psp.mobile.process.factory.impl;

import java.util.Locale;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.stereotype.Component;

import psp.common.exception.ApplicationException;
import psp.constants.StatusCode;
import psp.mobile.model.request.GetMerchantRequest;
import psp.mobile.model.response.GetMerchantResponse;
import psp.mobile.model.response.MessageResponse;
import psp.mobile.process.factory.MobileCoreProcess;
import psp.user.service.CommonService;

@Component("getMerchantMpfb")
public class GetMerchantProcessImpl extends MobileCoreProcess {

	private static final Logger LOGGER = Logger.getLogger(GetMerchantProcessImpl.class.getName());
	
	@Autowired
	private CommonService commonService;
	
	@Autowired
	private MessageSource messageSource;
	
	public GetMerchantProcessImpl() {	
	}
	
	@Override
	public MessageResponse validateRequest() {
		GetMerchantResponse response = new GetMerchantResponse();
		response.validate();
		return response;
	}

	@Override
	public void doProcess(MessageResponse response) throws ApplicationException {
		LOGGER.info("doProcess of GetMerchantProcessImpl started ");
		GetMerchantResponse resp = (GetMerchantResponse) response;
		GetMerchantRequest req = (GetMerchantRequest) request;
		resp.setMerchantDetails(commonService.getMerchantDetailsByMerchantId(req.getMerchantId()));
		LOGGER.info("doProcess of GetMerchantProcessImpl completed ");
	}

	@Override
	public MessageResponse createResponseOnStatusCode(StatusCode code, Locale locale) {
		GetMerchantResponse response = new GetMerchantResponse();
		response.setStatusCode(code.getCode());
		response.setStatusMessage(messageSource.getMessage(code.getCode(), null, locale));
		return response;
	}

}
