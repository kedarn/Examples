/**
 * 
 */
package psp.mobile.process.factory.impl;

import java.util.Date;
import java.util.List;
import java.util.Locale;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.stereotype.Component;
import org.upi.system_1_2.Ack;
import org.upi.system_1_2.CredSubType;
import org.upi.system_1_2.CredType;
import org.upi.system_1_2.CredsType;
import org.upi.system_1_2.HeadType;
import org.upi.system_1_2.LinkType;
import org.upi.system_1_2.PayConstant;
import org.upi.system_1_2.PayTrans;
import org.upi.system_1_2.PayerConstant;
import org.upi.system_1_2.PayerType;
import org.upi.system_1_2.ReqListAccount.Link;

import psp.common.PropertyReader;
import psp.common.exception.ApplicationException;
import psp.constants.CommonConstants;
import psp.constants.ServiceNotes;
import psp.constants.ServiceStatus;
import psp.constants.StatusCode;
import psp.dbservice.mgmt.PspMgmtService;
import psp.dbservice.model.AccountDetails;
import psp.dbservice.model.AccountReference;
import psp.dbservice.model.GetAccountsUpiRequest;
import psp.mobile.model.request.GetAccountListRequest;
import psp.mobile.model.response.GetAccountListResponse;
import psp.mobile.model.response.MessageResponse;
import psp.mobile.process.account.service.AccountListCacheService;
import psp.mobile.process.factory.MobileCoreProcess;
import psp.mobile.process.util.MobileProcessUtility;
import psp.util.DtoObjectUtil;
import psp.util.PspClientTool;
import psp.util.dto.AcDto;
import psp.util.upi.client.UpiClientService;
import psp.util.upiclient.UpiDataPreparationUtility;

/**
 * @author prasadj
 *
 */
@Component("accountListMpfb")
public class GetAccountListProcessImpl extends MobileCoreProcess {
	
	private static final Logger LOGGER = Logger.getLogger(GetAccountListProcessImpl.class.getName());
	
	@Autowired
	private PspMgmtService pspMgmtService;
	
	@Autowired
	private UpiClientService upiClient;

	@Autowired
	private AccountListCacheService accountSummaryService;
	
	@Autowired
	private PropertyReader propertyReader;
	
	@Autowired
	private MessageSource messageSource;
	
	public GetAccountListProcessImpl(){
	}

	@Override
	public MessageResponse validateRequest() {
		GetAccountListResponse response = new GetAccountListResponse();		
		response.validate();
		return response;
	}

	@Override
	public void doProcess(MessageResponse response) throws ApplicationException {
		LOGGER.info("doProcess of GetAccountListProcessImpl started ");
		GetAccountListRequest req = (GetAccountListRequest) request;
		GetAccountListResponse res = (GetAccountListResponse) response;
		Date date = new Date();
		String messageId = DtoObjectUtil.constructMessageId();
		HeadType head = DtoObjectUtil.constructHeadType(messageId, date);
		String id = req.getTxnId();
		String note = ServiceNotes.ACC_LIST_NOTE;
		String orgTxnId = null;
		PayConstant type = PayConstant.LIST_ACCOUNT;
		PayTrans txn = DtoObjectUtil.constructPayTrans(id, note, orgTxnId, date, type, propertyReader.getReferenceUrl(), false);
		
		String fullName = user.getFirstName() + CommonConstants.SPACE_STR + user.getMiddleName() + CommonConstants.SPACE_STR + user.getLastName();
		PayerConstant payerType = PayerConstant.PERSON;
		
		AccountDetails acDetails = pspMgmtService.getAccountDetailsByUserDetailsId(user.getId());
		AcDto acDto =  MobileProcessUtility.getAcDto(acDetails);		
		//TODO virtual address is mandatory
		PayerType payer = DtoObjectUtil.constructPayerDto(user.getLoginName() + CommonConstants.SELF_PSP_NAME, fullName, payerType, acDto, null, null, null, request.getDevice(), null);
		Link link = new Link();
		link.setType(LinkType.MOBILE);
		if(Boolean.FALSE == req.getIsBenAccDetails()) {
			CredsType credsType = UpiDataPreparationUtility.constructCredsType(CredType.OTP, CredSubType.SMS, req.getMobileCredentials().getDataValue(), "NPCI", "20150822");
			payer.setCreds(credsType);
			link.setValue(user.getPhoneNumber());
		}
		else {
			link.setValue(req.getAcDetails().getMobnum());		
		}		
		
		String responseXml = upiClient.reqListAccount(head, txn, payer, link);	
		Ack ack = PspClientTool.convertUpiRequest(responseXml, Ack.class);
		boolean respReceived = false;
		if(ack.getErr() == null) {
			pspMgmtService.saveUpiRequest(MobileProcessUtility.prepareUpiRequestDetails(messageId, id, GetAccountsUpiRequest.class));
			int maxDelay = propertyReader.getMaxDelayInterval(); //seconds
			int count = 0;
			do {
				GetAccountsUpiRequest accListResp = (GetAccountsUpiRequest) pspMgmtService.getUpiRequestByTxnId(id);
				if (ServiceStatus.RECEIVED.name().equals(accListResp.getStatus())) {
					respReceived = true;
					if(CommonConstants.SUCCESS.equals(accListResp.getResult())) {
						acDetails.setIsAccDetailsVerified(true);
						pspMgmtService.updateAccountDetails(acDetails);
						List<AccountReference> accountDetails = MobileProcessUtility.prepareAccountReferenceList(accListResp);
						prepareResponse(accountDetails, res, accListResp, response);
					}
					else{
						pspMgmtService.deleteAccountDetails(acDetails);
						pspMgmtService.deleteUpiRequest(accListResp);
						throw new ApplicationException(StatusCode.GET_ACCOUNT_SERVICE_FAIL);
					}
				}
				try{
					count++;
					Thread.sleep(propertyReader.getMobileProcessDelay());
				}
				catch(Exception ex){
				}
				if(count > maxDelay){
					LOGGER.info("UPI Request time out");
					pspMgmtService.deleteAccountDetails(acDetails);
					pspMgmtService.deleteUpiRequest(accListResp);
					throw new ApplicationException(StatusCode.GET_ACCOUNT_SERVICE_FAIL);
				}
			}while (!respReceived);
		}
		else {
			throw new ApplicationException(StatusCode.GET_ACCOUNT_SERVICE_FAIL);
		}
		LOGGER.info("doProcess of GetAccountListProcessImpl completed ");
	}

	@Override
	public MessageResponse createResponseOnStatusCode(StatusCode code, Locale locale) {
		GetAccountListResponse response = new GetAccountListResponse();
		response.setStatusCode(code.getCode());
		response.setStatusMessage(messageSource.getMessage(code.getCode(), null, locale));
		return response;
		
	}
	
	private void prepareResponse(List<AccountReference> accountDetails, GetAccountListResponse res, GetAccountsUpiRequest accListResp, MessageResponse response) {
		accountSummaryService.addUserAccounts(request.getUserName(), accountDetails);
		res.setAccountSummaryList(MobileProcessUtility.prepareAccountSummaryList(accountDetails));
		pspMgmtService.deleteUpiRequest(accListResp);
		response.setStatusCode(StatusCode.SUCCESS.getCode());
		response.setStatusMessage(StatusCode.GET_ACC_SERVICE_SUCCESS.getMessage());
	}

}