package psp.mobile.process.factory.impl;

import java.util.Date;
import java.util.Locale;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.stereotype.Component;
import org.upi.system_1_2.Ack;
import org.upi.system_1_2.CredSubType;
import org.upi.system_1_2.CredType;
import org.upi.system_1_2.CredsType;
import org.upi.system_1_2.HeadType;
import org.upi.system_1_2.PayConstant;
import org.upi.system_1_2.PayTrans;

import psp.common.PropertyReader;
import psp.common.exception.ApplicationException;
import psp.constants.CommonConstants;
import psp.constants.ServiceNotes;
import psp.constants.ServiceStatus;
import psp.constants.StatusCode;
import psp.dbservice.mgmt.PspMgmtService;
import psp.dbservice.model.DeviceDetails;
import psp.dbservice.model.GetTokenUpiRequest;
import psp.dbservice.model.KeyInfoReq;
import psp.dto.UserProfileDto;
import psp.mobile.model.request.GetTokenRequest;
import psp.mobile.model.response.GetTokenResponse;
import psp.mobile.model.response.MessageResponse;
import psp.mobile.process.factory.MobileCoreProcess;
import psp.mobile.process.util.MobileProcessUtility;
import psp.util.DtoObjectUtil;
import psp.util.PspClientTool;
import psp.util.gcm.GcmNotification;
import psp.util.upi.client.UpiClientService;
import psp.util.upiclient.UpiDataPreparationUtility;

@Component("getTokenMpfb")
public class GetTokenProcessImpl extends MobileCoreProcess {

	private static final Logger LOGGER = Logger.getLogger(GetTokenProcessImpl.class.getName());
	
	@Autowired
	private PspMgmtService pspMgmtService;
	
	@Autowired
	private UpiClientService upiClient;
	
	@Autowired
	private PropertyReader propertyReader;
	
	@Autowired
	private GcmNotification gcmNotification;
	
	@Autowired
	private MessageSource messageSource;
	
	public GetTokenProcessImpl() {
	}
	
	@Override
	public MessageResponse validateRequest() {
		GetTokenResponse response = new GetTokenResponse();
		response.validate();
		return response;
	}

	@Override
	public void doProcess(MessageResponse response) throws ApplicationException {
		LOGGER.info("doProcess of GetTokenProcessImpl started ");
		UserProfileDto user = pspMgmtService.getNonDeletedUser(request.getUserName());
		if ( user != null) {
			DeviceDetails deviceDetails = pspMgmtService.getDeviceDetailsByUserId(user.getId());
			StatusCode statusCode = MobileProcessUtility.validateMobileDeviceDetails(deviceDetails, request.getDevice(), propertyReader.getAppBaseVersion(),propertyReader.getAppCurrentVersion(), gcmNotification, user);
			if (statusCode == StatusCode.SUCCESS) { 
				GetTokenRequest req = (GetTokenRequest)request;
				Date date = new Date();
				String messageId = DtoObjectUtil.constructMessageId();
				HeadType head = DtoObjectUtil.constructHeadType(messageId, date);
				String id = DtoObjectUtil.constructTxnId();
				String note = ServiceNotes.ACC_PROV_LIST_NOTE;
				
				PayConstant type = PayConstant.GET_TOKEN;
				PayTrans txn = DtoObjectUtil.constructPayTrans(id, note, null, date, type, propertyReader.getReferenceUrl(), false);
				// TODO need to verify type and sub type
				CredsType credType = UpiDataPreparationUtility.constructCredsType(CredType.PIN, CredSubType.MPIN, req.getMobileCredentials().getDataValue(), "NPCI", "20150822");

				String responseXml = upiClient.reqGetToken(head, txn, credType);
				Ack ack = PspClientTool.convertUpiRequest(responseXml, Ack.class);
				boolean respReceived = false;
				GetTokenResponse mobileRes = (GetTokenResponse) response;
				if(ack.getErr() == null) {
					pspMgmtService.saveUpiRequest(MobileProcessUtility.prepareUpiRequestDetails(messageId, id, GetTokenUpiRequest.class));
					int maxDelay = propertyReader.getMaxDelayInterval();//seconds
					int count = 0;
					do {
						GetTokenUpiRequest tokenResp = (GetTokenUpiRequest) pspMgmtService.getUpiRequestByTxnId(id);
						if (ServiceStatus.RECEIVED.name().equals(tokenResp.getStatus())) {
							respReceived = true;
							if(CommonConstants.SUCCESS.equals(tokenResp.getResult())) {
								if(!tokenResp.getKeyInfoReqs().isEmpty()){
									KeyInfoReq kiReq = tokenResp.getKeyInfoReqs().iterator().next();
									mobileRes.setCode(kiReq.getCode());
									mobileRes.setKeyIndexDate(kiReq.getKi());
									mobileRes.setKeyValue(kiReq.getKeyValue());
									mobileRes.setType(kiReq.getType());
								}
								pspMgmtService.deleteUpiRequest(tokenResp);
								response.setStatusCode(StatusCode.SUCCESS.getCode());
								response.setStatusMessage(StatusCode.GET_TOKEN_SERVICE_SUCCESS.getMessage());
							}
							else{
								pspMgmtService.deleteUpiRequest(tokenResp);
								throw new ApplicationException(StatusCode.GET_TOKEN_SERVICE_FAIL);
							}
						}		
						try{
							count++;
							Thread.sleep(propertyReader.getMobileProcessDelay());
						}
						catch(Exception ex){
						}
						if(count > maxDelay){
							LOGGER.info("UPI Request time out ");
							throw new ApplicationException(StatusCode.GET_TOKEN_SERVICE_FAIL);
						}
					}while (!respReceived);
				}
				else {
					throw new ApplicationException(StatusCode.GET_TOKEN_SERVICE_FAIL);
				}
			}
			else {
				throw new ApplicationException(StatusCode.DEVICE_VALIDATION_FAILED) ;
			}
		}
		else {
			throw new ApplicationException(StatusCode.USER_NOT_REGISTER) ;
		}
		LOGGER.info("doProcess of GetTokenProcessImpl completed ");
		
	}

	@Override
	public MessageResponse createResponseOnStatusCode(StatusCode code, Locale locale) {
		GetTokenResponse response = new GetTokenResponse();
		response.setStatusCode(code.getCode());
		response.setStatusMessage(messageSource.getMessage(code.getCode(), null, locale));
		return response;
	}

}
