/**
 * 
 */
package psp.mobile.process.factory.impl;


import java.util.Date;
import java.util.Locale;
import java.util.logging.Logger;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.stereotype.Component;

import psp.common.PropertyReader;
import psp.common.exception.ApplicationException;
import psp.constants.StatusCode;
import psp.dbservice.mgmt.PspMgmtService;
import psp.dbservice.model.GeneratedOtpDetails;
import psp.mobile.model.request.VerifyOtpRequest;
import psp.mobile.model.response.MessageResponse;
import psp.mobile.model.response.VerifyOtpResponse;
import psp.mobile.process.factory.MobileCoreProcess;
import psp.notification.service.SmsService;

/**
 * @author hemanthk
 *
 */
@Component("verifyOtpMpfb")
public class VerifyOtpProcessImpl extends MobileCoreProcess {

	private static final Logger LOGGER = Logger.getLogger(VerifyOtpProcessImpl.class.getName());
	
	@Autowired
	private PspMgmtService pspMgmtService;
	
	@Autowired
	private SmsService smsService;
	
	@Autowired
	private PropertyReader propertyReader;
	
	@Autowired
	private MessageSource messageSource;
	
	public VerifyOtpProcessImpl() {
	}
	
	@Override
	public MessageResponse validateRequest() {
		VerifyOtpResponse response = new VerifyOtpResponse();
		response.validate();
		return response;
	}

	@Override
	public void doProcess(MessageResponse response) throws ApplicationException {
		LOGGER.info("doProcess of VerifyOtpProcessImpl started ");
		VerifyOtpRequest verifyOtpRequest = (VerifyOtpRequest) request;
		GeneratedOtpDetails generatedOtpDetails = pspMgmtService.getOtpDetailsByMobileNumber(verifyOtpRequest.getMobileNumber());
		if(null != generatedOtpDetails ) {
			if(isOtpExpired(generatedOtpDetails.getGeneratedTime().getTime(), propertyReader.getLocalOtpExpTime())){
				if(generatedOtpDetails.getOtp().equals(verifyOtpRequest.getOtp()) ) {
					pspMgmtService.deleteOtpDetails(generatedOtpDetails);
				}
				else {
					throw new ApplicationException(StatusCode.INVALID_OTP);
				}
			}
			else{
				throw new ApplicationException(StatusCode.OTP_EXPIRED);
			}
		}
		else {
			throw new ApplicationException(StatusCode.INVALID_OTP);
		}
		LOGGER.info("doProcess of VerifyOtpProcessImpl completed ");
	}

	@Override
	public MessageResponse createResponseOnStatusCode(StatusCode code, Locale locale) {
		VerifyOtpResponse response = new VerifyOtpResponse();
		response.setStatusCode(code.getCode());
		response.setStatusMessage(messageSource.getMessage(code.getCode(), null, locale));
		return response;
	}
	
	
	public static boolean isOtpExpired(long generatedTime, long localExpTime){
		Date  d = new Date();
		long currentTime = d.getTime();
		long difference = currentTime - generatedTime;
		long diffSec = (difference/1000)%60;
		if(diffSec > localExpTime){
			return false;
		}
		return true;
	}

}
