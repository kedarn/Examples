package psp.mobile.process.factory.impl;

import java.util.Date;
import java.util.Locale;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.stereotype.Component;
import org.upi.system_1_2.Ack;
import org.upi.system_1_2.CredSubType;
import org.upi.system_1_2.CredType;
import org.upi.system_1_2.CredsType;
import org.upi.system_1_2.InfoType;
import org.upi.system_1_2.PayTrans;
import org.upi.system_1_2.PayerConstant;
import org.upi.system_1_2.PayerType;
import org.upi.system_1_2.ReqAuthDetails;
import org.upi.system_1_2.RespAuthDetails;
import org.upi.system_1_2.RespType;

import psp.common.PropertyReader;
import psp.common.exception.ApplicationException;
import psp.constants.CommonConstants;
import psp.constants.NotificationStatus;
import psp.constants.StatusCode;
import psp.constants.TxnStatus;
import psp.dbservice.mgmt.PspMgmtService;
import psp.dbservice.model.AccountDetails;
import psp.dbservice.model.NotificationDetails;
import psp.dbservice.model.TransactionDetails;
import psp.mobile.model.request.CollectPayConfirmRequest;
import psp.mobile.model.response.CollectPayConfirmResponse;
import psp.mobile.model.response.MessageResponse;
import psp.mobile.process.factory.MobileCoreProcess;
import psp.util.DtoObjectUtil;
import psp.util.PspClientTool;
import psp.util.dto.AcDto;
import psp.util.upi.client.UpiClientService;
import psp.util.upiclient.UpiDataPreparationUtility;

@Component("collectPayConfirmationMpfb")
public class CollectPayConfirmationProcessImpl extends MobileCoreProcess {

	private static final Logger LOGGER = Logger.getLogger(CollectPayConfirmationProcessImpl.class.getName());
	
	@Autowired
	private PspMgmtService pspMgmtService;
	
	@Autowired
	private UpiClientService upiClientService;
	
	@Autowired
	private PropertyReader propertyReader;
	
	@Autowired
	private MessageSource messageSource;

	public CollectPayConfirmationProcessImpl() {
	}
	
	@Override
	public MessageResponse validateRequest() {
		CollectPayConfirmResponse response = new CollectPayConfirmResponse();
		response.validate();
		return response;
	}

	@Override
	public void doProcess(MessageResponse response) throws ApplicationException {
		LOGGER.info("doProcess of CollectPayConfirmationProcessImpl started ");
		CollectPayConfirmRequest req = (CollectPayConfirmRequest) request;
		NotificationDetails notification = pspMgmtService.getNotificationDetailsByNotificationId(req.getNotificationId());
		if(null != notification) {
			ReqAuthDetails reqAuthDetails = PspClientTool.convertUpiRequest(notification.getUpiMessagePacket().getMessagePacket(), ReqAuthDetails.class);
			String ackXml = upiClientService.respAuthDetails(prepareCollectrequest(reqAuthDetails, req));
			LOGGER.info(" Resp auth details ack in CollectPayConfirmationProcessImpl: " + ackXml);
			Ack ackRes = PspClientTool.convertUpiRequest(ackXml, Ack.class);
			if(ackRes.getErr() == null) {
				notification.setStatus(NotificationStatus.NOTIFIED.name());
				pspMgmtService.updateNotificationDetails(notification);	
				TransactionDetails txnDetails = pspMgmtService.getTransactionDetailsByTxnId(reqAuthDetails.getTxn().getId(), reqAuthDetails.getTxn().getType().name());
				txnDetails.setTxnConfirmationTime(new Date());
				txnDetails.setStatus(TxnStatus.COMPLETED.name());
				pspMgmtService.updateTransactionDetails(txnDetails);
				if(req.getRejected()) {
					response.setStatusCode(StatusCode.SUCCESS.getCode());
					response.setStatusMessage(StatusCode.COLLECT_PAY_REJECTED_SUCCESS.getMessage());
				}
			}
			else {
				response.setStatusCode(StatusCode.COLLECT_CONFIRMATION_FAIL.getCode());
				response.setStatusMessage(StatusCode.COLLECT_CONFIRMATION_FAIL.getMessage());
			}
		}
		LOGGER.info("doProcess of CollectPayConfirmationProcessImpl completed ");
	}

	@Override
	public MessageResponse createResponseOnStatusCode(StatusCode code, Locale locale) {
		CollectPayConfirmResponse response = new CollectPayConfirmResponse();
		response.setStatusCode(code.getCode());
		response.setStatusMessage(messageSource.getMessage(code.getCode(), null, locale));
		return response;
	}

	private RespAuthDetails prepareCollectrequest(ReqAuthDetails reqAuthDetails, CollectPayConfirmRequest req){
		Date date = new Date();
		String messageId = DtoObjectUtil.constructMessageId();
		PayTrans payTrans = reqAuthDetails.getTxn();
		PayTrans txn = DtoObjectUtil.constructPayTrans(payTrans.getId(), payTrans.getNote(), null, date, payTrans.getType(), propertyReader.getReferenceUrl(), false);
		
		PayerType payerType = reqAuthDetails.getPayer();
		AccountDetails accountDetails = pspMgmtService.getAccountDetailsByVirtualAddr(reqAuthDetails.getPayer().getAddr());
		AcDto acDto = new AcDto();//TODO need to change
		acDto.setAddrType(accountDetails.getAddressType());
		acDto.setAcnum(accountDetails.getAccountNumber());
		acDto.setActype(accountDetails.getAccountType());
		acDto.setIfsc(accountDetails.getIfsc());
		
		CredsType credsType = null;
		RespType respType = new RespType();
		respType.setReqMsgId(reqAuthDetails.getHead().getMsgId());
		if (!req.getRejected()) {
			credsType = UpiDataPreparationUtility.constructCredsType(CredType.PIN, CredSubType.MPIN, req.getMobileCredentials().getDataValue(), "NPCI", "20150822");
			respType.setResult(CommonConstants.SUCCESS);
		}
		else {
			respType.setResult("FAILURE");
		}
		InfoType info = DtoObjectUtil.constructIdentityInfoDto(payerType.getAddr());
		PayerType payer = DtoObjectUtil.constructPayerDto(payerType.getAddr(), null, PayerConstant.PERSON, acDto, payerType.getAmount().getValue(), credsType, null, req.getDevice(), info);
	
		RespAuthDetails respAuthDetails = new RespAuthDetails();
		respAuthDetails.setHead(DtoObjectUtil.constructHeadType(messageId, date));
		respAuthDetails.setTxn(txn);
		respAuthDetails.setPayees(reqAuthDetails.getPayees());
		respAuthDetails.setPayer(payer);
		respAuthDetails.setResp(respType);
		return respAuthDetails;
	}
	
}