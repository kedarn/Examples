package psp.mobile.process.factory.impl;

import java.util.List;
import java.util.Locale;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.stereotype.Component;

import psp.common.exception.ApplicationException;
import psp.constants.StatusCode;
import psp.dto.UserSearchDto;
import psp.mobile.model.request.GetCustomerMerchantRequest;
import psp.mobile.model.response.GetCustomerMerchantResponse;
import psp.mobile.model.response.MerchantDetails;
import psp.mobile.model.response.MessageResponse;
import psp.mobile.process.factory.MobileCoreProcess;
import psp.user.service.CommonService;

@Component("getCustomerMerchantMpfb")
public class GetCustomerMerchantProcessImpl extends MobileCoreProcess {

	private static final Logger LOGGER = Logger.getLogger(GetCustomerMerchantProcessImpl.class.getName());
	
	@Autowired
	private CommonService commonService;
	
	@Autowired
	private MessageSource messageSource;
	
	public GetCustomerMerchantProcessImpl() {
	}
	
	@Override
	public MessageResponse validateRequest() {
		GetCustomerMerchantResponse response = new GetCustomerMerchantResponse();
		response.validate();
		return response;
	}

	@Override
	public void doProcess(MessageResponse response) throws ApplicationException {
		LOGGER.info("doProcess of GetCustomerMerchantProcessImpl started ");
		GetCustomerMerchantRequest req = (GetCustomerMerchantRequest) request;
		GetCustomerMerchantResponse mobileres = (GetCustomerMerchantResponse) response;
		List<MerchantDetails> merchantUserList = null;
		if(req.isAddedMerchants()) {
			merchantUserList = commonService.getCustomerAddedMerchants(new UserSearchDto(), request.getUserName());	
		}
		else {
			merchantUserList = commonService.getCustomerNotAddedMerchants(request.getUserName());
		}
		mobileres.setMerchantList(merchantUserList);
		LOGGER.info("doProcess of GetCustomerMerchantProcessImpl completed ");	
	}

	@Override
	public MessageResponse createResponseOnStatusCode(StatusCode code, Locale locale) {
		GetCustomerMerchantResponse response = new GetCustomerMerchantResponse();
		response.setStatusCode(code.getCode());
		response.setStatusMessage(messageSource.getMessage(code.getCode(), null, locale));
		return response;
	}

}
