/**
 * 
 */
package psp.mobile.process.factory.impl;

import java.util.Date;
import java.util.Locale;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.stereotype.Component;
import org.upi.system_1_2.Ack;
import org.upi.system_1_2.CredSubType;
import org.upi.system_1_2.CredType;
import org.upi.system_1_2.CredsType;
import org.upi.system_1_2.HeadType;
import org.upi.system_1_2.PayConstant;
import org.upi.system_1_2.PayTrans;
import org.upi.system_1_2.PayerConstant;
import org.upi.system_1_2.PayerType;

import psp.common.PropertyReader;
import psp.common.exception.ApplicationException;
import psp.constants.CommonConstants;
import psp.constants.ServiceNotes;
import psp.constants.ServiceStatus;
import psp.constants.StatusCode;
import psp.dbservice.mgmt.PspMgmtService;
import psp.dbservice.model.AccountDetails;
import psp.dbservice.model.BalanceEnquiryUpiRequest;
import psp.mobile.model.request.BalanceEnquiryRequest;
import psp.mobile.model.response.BalanceEnquiryResponse;
import psp.mobile.model.response.MessageResponse;
import psp.mobile.process.factory.MobileCoreProcess;
import psp.mobile.process.util.MobileProcessUtility;
import psp.util.DtoObjectUtil;
import psp.util.PspClientTool;
import psp.util.dto.AcDto;
import psp.util.upi.client.UpiClientService;
import psp.util.upiclient.UpiDataPreparationUtility;

/**
 * @author prasadj
 *
 */
@Component("balanceEnquiryMpfb")
public class GetBalanceEnquiryProcessImpl extends MobileCoreProcess{

	private static final Logger LOGGER = Logger.getLogger(GetBalanceEnquiryProcessImpl.class.getName());
	
	@Autowired
	private PspMgmtService pspMgmtService;
	
	@Autowired
	private UpiClientService upiClient;
	
	@Autowired
	private PropertyReader propertyReader;
	
	@Autowired
	private MessageSource messageSource;
	
	public GetBalanceEnquiryProcessImpl(){
	}
	
	@Override
	public MessageResponse validateRequest() {
		BalanceEnquiryResponse response = new BalanceEnquiryResponse();
		response.validate();
		return response;
	}

	@Override
	public void doProcess(MessageResponse response) throws ApplicationException {
		LOGGER.info("doProcess of GetBalanceEnquiryProcessImpl started ");
		BalanceEnquiryRequest req = (BalanceEnquiryRequest)request;
		Date date = new Date();
		String messageId = DtoObjectUtil.constructMessageId();
		HeadType head = DtoObjectUtil.constructHeadType(messageId, date);
		String id = req.getTxnId();
		String note = ServiceNotes.BAL_ENQ;
		
		PayConstant type = PayConstant.BAL_ENQ;
		PayTrans txn = DtoObjectUtil.constructPayTrans(id, note, null, date, type, propertyReader.getReferenceUrl(), false);
		
		String fullName = user.getFirstName() + CommonConstants.SPACE_STR + user.getMiddleName() + CommonConstants.SPACE_STR + user.getLastName();
		
		AccountDetails acDetails = pspMgmtService.getAccountDetailsByUserDetailsId(user.getId());
		AcDto acDto = MobileProcessUtility.getAcDto(acDetails);
		
		PayerType payerDto = DtoObjectUtil.constructPayerDto(acDetails.getVirtualAddress(), fullName, PayerConstant.PERSON, acDto, null, null, null, request.getDevice(), null);
		
		
		CredsType credsType = UpiDataPreparationUtility.constructCredsType(CredType.PIN, CredSubType.MPIN, req.getMobileCredentials().getDataValue(), "NPCI", "20150822");
		payerDto.setCreds(credsType);
		
		String responseXml = upiClient.reqBalEnq(head, txn, payerDto);
		Ack ack = PspClientTool.convertUpiRequest(responseXml, Ack.class);
		boolean respReceived = false;
		BalanceEnquiryResponse mobileRes = (BalanceEnquiryResponse) response;
		if(ack.getErr() == null) {
			pspMgmtService.saveUpiRequest(MobileProcessUtility.prepareUpiRequestDetails(messageId, id, BalanceEnquiryUpiRequest.class));
			do {
				BalanceEnquiryUpiRequest balResp = (BalanceEnquiryUpiRequest) pspMgmtService.getUpiRequestByTxnId(id);
				if (ServiceStatus.RECEIVED.name().equals(balResp.getStatus())) {
					respReceived = true;
					if(CommonConstants.SUCCESS.equals(balResp.getResult())) {
						prepareResponse(balResp.getBalance(), mobileRes, response, balResp);
					}
					else {
						pspMgmtService.deleteUpiRequest(balResp);
						throw new ApplicationException(StatusCode.BAL_ENQ_SERVICE_FAIL);
					}
				}		
				try{
					Thread.sleep(propertyReader.getMobileProcessDelay());
				}
				catch(Exception ex){
				}
			}while (!respReceived);
		}
		else {
			throw new ApplicationException(StatusCode.BAL_ENQ_SERVICE_FAIL);
		}
		LOGGER.info("doProcess of GetBalanceEnquiryProcessImpl completed ");
	}

	@Override
	public MessageResponse createResponseOnStatusCode(StatusCode code, Locale locale) {
		BalanceEnquiryResponse response = new BalanceEnquiryResponse();
		response.setStatusCode(code.getCode());
		response.setStatusMessage(messageSource.getMessage(code.getCode(), null, locale));
		return response;
	}
	
	private void prepareResponse(String bal, BalanceEnquiryResponse mobileRes, MessageResponse response, BalanceEnquiryUpiRequest balResp) {
		mobileRes.setBalance(bal);
		pspMgmtService.deleteUpiRequest(balResp);
		response.setStatusCode(StatusCode.SUCCESS.getCode());
		response.setStatusMessage(StatusCode.BAL_ENQ_SERVICE_SUCCESS.getMessage());
	}

}