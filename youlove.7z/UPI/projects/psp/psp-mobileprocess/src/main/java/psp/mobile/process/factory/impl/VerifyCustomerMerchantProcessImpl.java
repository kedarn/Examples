package psp.mobile.process.factory.impl;

import java.util.Locale;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.stereotype.Component;

import psp.common.exception.ApplicationException;
import psp.constants.StatusCode;
import psp.mobile.model.request.VerifyCustomerMerchantRequest;
import psp.mobile.model.response.MessageResponse;
import psp.mobile.model.response.VerifyCustomerMerchantResponse;
import psp.mobile.process.factory.MobileCoreProcess;
import psp.user.service.CommonService;
import psp.util.BillDetailsUtil;

@Component("verifyCustomerMerchantMpfb")
public class VerifyCustomerMerchantProcessImpl extends MobileCoreProcess {

	private static final Logger LOGGER = Logger.getLogger(VerifyCustomerMerchantProcessImpl.class.getName());
	
	@Autowired
	private CommonService commonService;
	
	@Autowired
	private MessageSource messageSource;
	
	public VerifyCustomerMerchantProcessImpl() {
	}

	@Override
	public MessageResponse validateRequest() {
		VerifyCustomerMerchantResponse response = new VerifyCustomerMerchantResponse();
		response.validate();
		return response;
	}

	@Override
	public void doProcess(MessageResponse response) throws ApplicationException {
		LOGGER.info("doProcess of VerifyCustomerMerchantProcessImpl started ");
		VerifyCustomerMerchantRequest req = (VerifyCustomerMerchantRequest) request;
		VerifyCustomerMerchantResponse res = (VerifyCustomerMerchantResponse) response;
		res.setBillDetails(BillDetailsUtil.getBillDetails(req.getIdentification()));
		res.setMerchant(commonService.getMerchantSummaryByMerchantId(req.getMerchantId()));
		LOGGER.info("doProcess of VerifyCustomerMerchantProcessImpl completed ");
	}

	@Override
	public MessageResponse createResponseOnStatusCode(StatusCode code, Locale locale) {
		VerifyCustomerMerchantResponse response = new VerifyCustomerMerchantResponse();
		response.setStatusCode(code.getCode());
		response.setStatusMessage(messageSource.getMessage(code.getCode(), null, locale));
		return response;
	}

}
