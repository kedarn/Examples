/**
 * 
 */
package psp.mobile.process.factory.impl;

import java.util.Locale;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.stereotype.Component;

import psp.common.exception.ApplicationException;
import psp.constants.StatusCode;
import psp.dbservice.mgmt.PspMgmtService;
import psp.mobile.model.request.ChangePasswordRequest;
import psp.mobile.model.response.ChangePasswordResponse;
import psp.mobile.model.response.MessageResponse;
import psp.mobile.process.factory.MobileCoreProcess;
import psp.user.service.CommonService;

/**
 * @author prasadj
 *
 */
@Component("changePasswordMpfb")
public class ChangePasswordProcessImpl extends MobileCoreProcess {

	private static final Logger LOGGER = Logger.getLogger(ChangePasswordProcessImpl.class.getName());
	
	@Autowired
	private PspMgmtService pspMgmtService;
	
	@Autowired
	private CommonService commonService;
	
	@Autowired
	private MessageSource messageSource;
	
	public ChangePasswordProcessImpl(){
	}
	
	@Override
	public MessageResponse validateRequest() {
		ChangePasswordResponse response = new ChangePasswordResponse();
		response.validate((ChangePasswordRequest)request);
		return response;
	}

	@Override
	public void doProcess(MessageResponse response) throws ApplicationException {
		LOGGER.info("doProcess of ChangePasswordProcessImpl started ");
		ChangePasswordRequest chgPwdreq = (ChangePasswordRequest) request;
		Boolean flag = false;
		flag = commonService.changePassword(chgPwdreq.getOldPassword(), chgPwdreq.getNewPassword(), chgPwdreq.getUserName());
		if(flag){
		}
		else{
			throw new ApplicationException(StatusCode.INVALID_OLD_PASSWORD);
		}
		LOGGER.info("doProcess of ChangePasswordProcessImpl completed ");
	}

	@Override
	public MessageResponse createResponseOnStatusCode(StatusCode code, Locale locale) {
		ChangePasswordResponse response = new ChangePasswordResponse();
		response.setStatusCode(code.getCode());
		response.setStatusMessage(messageSource.getMessage(code.getCode(), null, locale));
		return response;
	}

}