package psp.mobile.process.util;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.upi.system_1_2.PayConstant;
import org.upi.system_1_2.ResultType;

import com.google.android.gcm.server.Result;

import psp.common.PropertyReader;
import psp.common.model.AccountSummary;
import psp.common.model.BillDetails;
import psp.constants.CommonConstants;
import psp.constants.ServiceStatus;
import psp.constants.StatusCode;
import psp.dbservice.model.AccountDetails;
import psp.dbservice.model.AccountReference;
import psp.dbservice.model.BeneficiaryAccountDetails;
import psp.dbservice.model.BeneficiaryDetails;
import psp.dbservice.model.BillMappingDetails;
import psp.dbservice.model.CustomerDetails;
import psp.dbservice.model.DeviceDetails;
import psp.dbservice.model.GetAccountsUpiRequest;
import psp.dbservice.model.GetTokenUpiRequest;
import psp.dbservice.model.LoginDetails;
import psp.dbservice.model.MobileAuditTrail;
import psp.dbservice.model.NotificationDetails;
import psp.dbservice.model.OtpUpiRequest;
import psp.dbservice.model.ReqAccountReference;
import psp.dbservice.model.TransactionDetails;
import psp.dbservice.model.UpiRequest;
import psp.dto.BeneficiaryDetailsDto;
import psp.dto.DeviceDto;
import psp.dto.UserProfileDto;
import psp.mobile.model.request.AcDetails;
import psp.mobile.model.request.AddBankAccountRequest;
import psp.mobile.model.request.AddBeneficiaryRequest;
import psp.mobile.model.request.BalanceEnquiryRequest;
import psp.mobile.model.request.ChangePasswordRequest;
import psp.mobile.model.request.CheckUserRequest;
import psp.mobile.model.request.CollectPayConfirmRequest;
import psp.mobile.model.request.CollectPaymentRequest;
import psp.mobile.model.request.ConformCustomerMerchantRequest;
import psp.mobile.model.request.DRegisterRequest;
import psp.mobile.model.request.ForgetPasswordRequest;
import psp.mobile.model.request.ForgetPasswordSubmitRequest;
import psp.mobile.model.request.GeneratePinRequest;
import psp.mobile.model.request.GetAccountListRequest;
import psp.mobile.model.request.GetAccountProvidersRequest;
import psp.mobile.model.request.GetBeneficiaryListRequest;
import psp.mobile.model.request.GetBeneficiaryRequest;
import psp.mobile.model.request.GetCustomerMerchantRequest;
import psp.mobile.model.request.GetExistingAccountsRequest;
import psp.mobile.model.request.GetKeyRequest;
import psp.mobile.model.request.GetMerchantListRequest;
import psp.mobile.model.request.GetMerchantRequest;
import psp.mobile.model.request.GetNotificationDetailsRequest;
import psp.mobile.model.request.GetNotificationListRequest;
import psp.mobile.model.request.GetTokenRequest;
import psp.mobile.model.request.GetTxnDetailsRequest;
import psp.mobile.model.request.LoginRequest;
import psp.mobile.model.request.LogoutRequest;
import psp.mobile.model.request.MobileDevice;
import psp.mobile.model.request.MobileNotification;
import psp.mobile.model.request.MobileNumberVerificationRequest;
import psp.mobile.model.request.OtpRequest;
import psp.mobile.model.request.PaymentRequest;
import psp.mobile.model.request.RegistrationRequest;
import psp.mobile.model.request.ResendResetPasswordRequest;
import psp.mobile.model.request.SetPinRequest;
import psp.mobile.model.request.VerifyCustomerMerchantRequest;
import psp.mobile.model.request.VerifyOtpRequest;
import psp.mobile.model.response.BeneficiarySummary;
import psp.mobile.model.response.TxnSummary;
import psp.util.dto.AcDto;
import psp.util.gcm.GcmNotification;

public class MobileProcessUtility implements CommonConstants {
	
	/**
	 * coreProcessBeanMap holds the request class name as key and alias name as value
	 */
	private static final Map<String, String> coreProcessBeanMap = new HashMap<String, String>();
	
	static {
		coreProcessBeanMap.put(GetAccountProvidersRequest.class.getName(), "AccountProvidersMpfb");
		coreProcessBeanMap.put(OtpRequest.class.getName(), "OtpRequestMpfb");
		coreProcessBeanMap.put(GetAccountListRequest.class.getName(), "AccountListMpfb");
		coreProcessBeanMap.put(SetPinRequest.class.getName(), "SetPinMpfb");
		coreProcessBeanMap.put(PaymentRequest.class.getName(), "MakePaymentMpfb");
		coreProcessBeanMap.put(GetTxnDetailsRequest.class.getName(), "TxnDetailsMpfb");
		coreProcessBeanMap.put(AddBankAccountRequest.class.getName(), "AddBankAccountMpfb");
		coreProcessBeanMap.put(ChangePasswordRequest.class.getName(), "ChangePasswordMpfb");
		coreProcessBeanMap.put(ForgetPasswordRequest.class.getName(), "ForgetPasswordMpfb");
		coreProcessBeanMap.put(LoginRequest.class.getName(), "LoginMpfb");
		coreProcessBeanMap.put(RegistrationRequest.class.getName(), "RegistrationMpfb");
		coreProcessBeanMap.put(CheckUserRequest.class.getName(), "CheckUserMpfb");
		coreProcessBeanMap.put(LogoutRequest.class.getName(), "LogoutMpfb");
		coreProcessBeanMap.put(GetMerchantListRequest.class.getName(), "GetMerchantListMpfb");
		coreProcessBeanMap.put(GetBeneficiaryListRequest.class.getName(), "GetBeneficiaryListMpfb");
		coreProcessBeanMap.put(AddBeneficiaryRequest.class.getName(), "AddBeneficiaryMpfb");
		coreProcessBeanMap.put(GetExistingAccountsRequest.class.getName(), "GetExistingAccsMpfb");
		coreProcessBeanMap.put(GetKeyRequest.class.getName(), "GetKeyMpfb"); 
		coreProcessBeanMap.put(GetTokenRequest.class.getName(), "GetTokenMpfb"); 
		coreProcessBeanMap.put(GetBeneficiaryRequest.class.getName(), "GetBeneficiaryMpfb");
		coreProcessBeanMap.put(BalanceEnquiryRequest.class.getName(), "BalanceEnquiryMpfb");
		coreProcessBeanMap.put(GetMerchantRequest.class.getName(), "GetMerchantMpfb");
		coreProcessBeanMap.put(GeneratePinRequest.class.getName(), "GeneratePinMpfb");
		coreProcessBeanMap.put(CollectPaymentRequest.class.getName(), "CollectPaymentMpfb");
		coreProcessBeanMap.put(CollectPayConfirmRequest.class.getName(), "CollectPayConfirmationMpfb");
		coreProcessBeanMap.put(GetNotificationDetailsRequest.class.getName(), "GetNotificationDetailsMpfb");
		coreProcessBeanMap.put(GetNotificationListRequest.class.getName(), "GetNotificationListMpfb");
		coreProcessBeanMap.put(GetCustomerMerchantRequest.class.getName(), "GetCustomerMerchantMpfb");
		coreProcessBeanMap.put(VerifyCustomerMerchantRequest.class.getName(), "VerifyCustomerMerchantMpfb");
		coreProcessBeanMap.put(ConformCustomerMerchantRequest.class.getName(), "ConfirmCustomerMerchantMpfb");
		coreProcessBeanMap.put(DRegisterRequest.class.getName(), "DeregisterUserMpfb");
		coreProcessBeanMap.put(MobileNumberVerificationRequest.class.getName(), "VerifyMobileNumberMpfb");
		coreProcessBeanMap.put(VerifyOtpRequest.class.getName(), "VerifyOtpMpfb");
		coreProcessBeanMap.put(ResendResetPasswordRequest.class.getName(), "ResendResetPasswordMpfb");
		coreProcessBeanMap.put(ForgetPasswordSubmitRequest.class.getName(), "ForgetPasswordSubmitMpfb");
	}
	
	private MobileProcessUtility() {
	}
	
	public static String getProcessBeanName(Object object){
		return coreProcessBeanMap.get(object.getClass().getName());
	}
	
	public static UserProfileDto prepareCustomerDto(RegistrationRequest request) {
		UserProfileDto customerDto = new UserProfileDto();
		customerDto.setAadhaarNumber(request.getAdharNumber());
		customerDto.setRegistrationDate(new Date());
		customerDto.setEmail(request.getEmail());
		customerDto.setFirstName(request.getFirstName());
		customerDto.setLastName(request.getLastName());
		customerDto.setMiddleName(request.getMiddleName());
		customerDto.setPhoneNumber(request.getMobileNumber());
		customerDto.setPassword(request.getPassword());
		customerDto.setLoginName(request.getUserName());
		customerDto.setRnsMpaId(request.getRnsMpaId());
		
		DeviceDto deviceDto = new DeviceDto();
		MobileDevice mobileDevice = request.getDevice();
		deviceDto.setApp(mobileDevice.getApp());
		deviceDto.setCapability(mobileDevice.getCapability());
		deviceDto.setGeoCode(mobileDevice.getGeoCode());
		deviceDto.setIp(mobileDevice.getIp());
		deviceDto.setLocation(mobileDevice.getLocation());
		deviceDto.setOs(mobileDevice.getOs());
		deviceDto.setType(mobileDevice.getType());
		deviceDto.setTerminalId(mobileDevice.getTerminalId());
		deviceDto.setMobile(mobileDevice.getMobile());
		customerDto.setDeviceDto(deviceDto);
		return customerDto;
	}
	
	public static List<AccountReference> prepareAccountReferenceList(GetAccountsUpiRequest response){
		List<AccountReference> list = new ArrayList<AccountReference>();
		Long id = 0l; 
		Iterator<ReqAccountReference> iterator = response.getAccounts().iterator();
		ReqAccountReference ref = null;
		while (iterator.hasNext()) {
			ref =  (ReqAccountReference) iterator.next();
			AccountReference ar = new AccountReference();
			ar.setAeba(ref.getAeba());
			ar.setIfsc(ref.getIfsc());
			ar.setMaskedNumber(ref.getMaskedNumber());
			ar.setName(ref.getName());
			ar.setCredentailType(ref.getCredentailDataType());
			ar.setCredentailSubType(ref.getCredentailSubType());
			ar.setCredentailDataType(ref.getCredentailDataType());
			ar.setCredentailDataLength(ref.getCredentailDataLength());
			ar.setId(++id);
			list.add(ar);
		}
		return list;
	}
	
	public static LoginDetails prepareLoginDetails(String userName, String terminalId) {
		LoginDetails loginDetails = new LoginDetails();
		loginDetails.setLoginTime(new Date());					
		loginDetails.setUserName(userName);
		loginDetails.setTerminalId(terminalId);			
		return loginDetails;
	}
	
	public static MobileAuditTrail prepareMobileAuditTrail(DeviceDetails deviceDetails, String userName, String service) {
		MobileAuditTrail mobileAuditTrail = new MobileAuditTrail();
		mobileAuditTrail.setApp(deviceDetails.getApp());
		mobileAuditTrail.setCapability(deviceDetails.getCapability());
		mobileAuditTrail.setGeoCode(deviceDetails.getGeoCode());
		mobileAuditTrail.setIp(deviceDetails.getIp());
		mobileAuditTrail.setLocation(deviceDetails.getLocation());
		mobileAuditTrail.setMobile(deviceDetails.getMobile());
		mobileAuditTrail.setOs(deviceDetails.getOs());
		mobileAuditTrail.setTerminalId(deviceDetails.getTerminalId());
		mobileAuditTrail.setType(deviceDetails.getType());
		mobileAuditTrail.setRequestTime(new Date());
		mobileAuditTrail.setServiceName(service);
		mobileAuditTrail.setUserName(userName);
		return mobileAuditTrail;
	}

	public static List<TxnSummary> prepareTxnsSummaryResponse(List<TransactionDetails> transactionDetails) {
		List<TxnSummary> detailsResponses = new ArrayList<>();
		for (TransactionDetails txn : transactionDetails) {
			TxnSummary response = new TxnSummary();
			response.setAmount(Double.parseDouble(txn.getAmount()));
			response.setPaymentFrom(txn.getFromAddr());
			response.setPaymentTo(txn.getToAddr());
			response.setTransactionDate(txn.getTxnInitiationTime());
			response.setStatus(txn.getStatus());
			response.setTxnMessage(txn.getTxnMessage());
			response.setTxnId(txn.getTxnId());
			response.setTransactionType(txn.getTxnType());
			detailsResponses.add(response);
		}
		return detailsResponses;
	}
	
	public static AcDto getAcDto(AcDetails acDetails){
		AcDto dto = new AcDto();
		dto.setAcnum(acDetails.getAcnum());
		dto.setActype(acDetails.getActype());
		dto.setAddrType(acDetails.getAddrType());
		dto.setCardNum(acDetails.getCardNum());
		dto.setIfsc(acDetails.getIfsc());
		dto.setIin(acDetails.getIin());
		dto.setMmid(acDetails.getMmid());
		dto.setMobnum(acDetails.getMobnum());
		dto.setUidnum(acDetails.getUidnum());
		return dto;
	}
	
	public static AcDto getAcDto(AccountDetails acDetails){
		AcDto dto = new AcDto();
		dto.setAcnum(acDetails.getAccountNumber());
		dto.setActype(acDetails.getAccountType());
		dto.setAddrType(acDetails.getAddressType());
		//dto.setCardNum(acDetails.get);
		dto.setIfsc(acDetails.getIfsc());
		//dto.setIin(acDetails.get);
		dto.setMmid(acDetails.getMmid());
		dto.setMobnum(acDetails.getMobileNumber());
		//dto.setUidnum(acDetails.get);
		return dto;
	}
	
	public static OtpUpiRequest prepareOtpReqDetails(OtpRequest otpRequest, String msgId, String txnId) {
		OtpUpiRequest otpRequestDetails = new OtpUpiRequest();
		otpRequestDetails.setAcNum(otpRequest.getAcDetails().getAcnum());
		otpRequestDetails.setAcType(otpRequest.getAcDetails().getActype());
		otpRequestDetails.setIfsc(otpRequest.getAcDetails().getIfsc());
		otpRequestDetails.setIin(otpRequest.getAcDetails().getIin());
		otpRequestDetails.setMessageId(msgId);
		otpRequestDetails.setMmid(otpRequest.getAcDetails().getMmid());
		otpRequestDetails.setMobNum(otpRequest.getAcDetails().getMobnum());
		otpRequestDetails.setRequestedTime(new Date());
		otpRequestDetails.setStatus(ServiceStatus.ACKNOWLEDGED.name());
		otpRequestDetails.setTransactionId(txnId);
		otpRequestDetails.setUidNum(otpRequest.getAcDetails().getUidnum());
		return otpRequestDetails;
	}
	
	public static DeviceDetails prepareDeviceDetails(MobileDevice mobileDevice) {
		DeviceDetails deviceDetails = new DeviceDetails();
		deviceDetails.setApp(mobileDevice.getApp());
		deviceDetails.setCapability(mobileDevice.getCapability());
		deviceDetails.setGeoCode(mobileDevice.getGeoCode());
		deviceDetails.setIp(mobileDevice.getIp());
		deviceDetails.setLocation(mobileDevice.getLocation());
		deviceDetails.setOs(mobileDevice.getOs());
		deviceDetails.setType(mobileDevice.getType());
		deviceDetails.setTerminalId(mobileDevice.getTerminalId());
		deviceDetails.setMobile(mobileDevice.getMobile());
		return deviceDetails;
	}

	public static GetTokenUpiRequest prepareGetTokenUpiRequest(String msgId, String txnId) {
		GetTokenUpiRequest upiRequest = new GetTokenUpiRequest();
		upiRequest.setMessageId(msgId);
		upiRequest.setRequestedTime(new Date());
		upiRequest.setStatus(ServiceStatus.ACKNOWLEDGED.name());
		upiRequest.setTransactionId(txnId);
		upiRequest.setKeyType(PayConstant.GET_TOKEN.name());
		return upiRequest;
	}
	public static  UpiRequest prepareUpiRequestDetails(String msgId, String txnId, Class<? extends UpiRequest> upiObject) {
		UpiRequest upiRequest = null;
		try {
			upiRequest = upiObject.newInstance();
			upiRequest.setMessageId(msgId);
			upiRequest.setRequestedTime(new Date());
			upiRequest.setStatus(ServiceStatus.ACKNOWLEDGED.name());
			upiRequest.setTransactionId(txnId);
		} catch (InstantiationException | IllegalAccessException e) {
			throw new RuntimeException("");
		}
		return upiRequest;
	}	

	public static List<BeneficiarySummary> convertBeneficiaryDetailsToBeneficiarySummary(List<BeneficiaryDetailsDto> bnfsDtls, String reqType){
		List<BeneficiarySummary>  bnfsSummary = new ArrayList<BeneficiarySummary>();
		for(int i = 0; i < bnfsDtls.size(); i++) {			
			BeneficiaryDetailsDto bnfDtls = bnfsDtls.get(i);	
			BeneficiarySummary  bnfSummary = new BeneficiarySummary();	
			/*if(RequestType.COLLECT.name().equals(reqType)) {
				bnfSummary.setBenVirtualAddr(bnfDtls.getAddress());
			}
			else {*/
				bnfSummary.setBenName(bnfDtls.getUserName());
				bnfSummary.setBenNickName(bnfDtls.getNickName());
				bnfSummary.setBenVirtualAddr(bnfDtls.getAddress()); 		
			//}	
			bnfsSummary.add(bnfSummary);
		}
		return bnfsSummary;
	}
	
	public static void updateBenificiary(BeneficiaryDetails bnfDetails, String name, String nickName, String address, String type, String note){
		bnfDetails.setAddress(address);
		bnfDetails.setAddressType(type);
		bnfDetails.setDescription(note);
		bnfDetails.setNickName(nickName);
		bnfDetails.setUserName(name);
	}

	public static void updateBenificiaryAccountDetails(AccountReference actRef, BeneficiaryAccountDetails bnfAcc){
		bnfAcc.setMaskedNumber(actRef.getMaskedNumber());
		bnfAcc.setIfsc(actRef.getIfsc());
		bnfAcc.setName(actRef.getName());
		bnfAcc.setAeba(actRef.getAeba());
		bnfAcc.setMmid(actRef.getMmid());
		bnfAcc.setReferenceNumber(actRef.getReferenceNumber());
	}
	
	public static BeneficiaryDetails prepareBenficiaryDetails(AccountReference actRef, String name, String nickName, String address, String type, String note){
		BeneficiaryDetails bnfDtls = new BeneficiaryDetails();
		BeneficiaryAccountDetails beneficiaryActDetails = new BeneficiaryAccountDetails();		
		beneficiaryActDetails.setMaskedNumber(actRef.getMaskedNumber());
		beneficiaryActDetails.setIfsc(actRef.getIfsc());
		beneficiaryActDetails.setName(actRef.getName());
		beneficiaryActDetails.setAeba(actRef.getAeba());
		beneficiaryActDetails.setMmid(actRef.getMmid());
		beneficiaryActDetails.setReferenceNumber(actRef.getReferenceNumber());
		bnfDtls.setAccountDetails(beneficiaryActDetails);
		bnfDtls.setAddress(address);
		bnfDtls.setAddressType(type);
		bnfDtls.setDescription(note);
		bnfDtls.setNickName(nickName);
		bnfDtls.setUserName(name);
		return bnfDtls;
	}
	
	//TODO has to remove
	public static List<AccountReference> prepareSampleDataForAccountSummaryList(String userName) {
		List<AccountReference> list = new ArrayList<AccountReference>(); 
		AccountReference ar = new AccountReference();
		ar.setAeba("Y");
		ar.setIfsc("AACA0010012");
		ar.setMaskedNumber("XXXXXXXXXXXX1234");
		ar.setMmid("AACA012");
		ar.setName(userName);
		ar.setCredentailType("PIN");
		ar.setCredentailSubType("MPIN");
		ar.setCredentailDataType("NUM");
		ar.setCredentailDataLength(6);
		ar.setId(1l);
		list.add(ar);		
		return list;
	}
	
	// TODO has to remove
	public static List<AccountReference> prepareSampleDataForBenAccountSummaryList(String userName) {
		List<AccountReference> list = new ArrayList<AccountReference>(); 
		AccountReference ar = new AccountReference();
		ar.setAeba("Y");
		ar.setIfsc("AACA0010013");
		ar.setMaskedNumber("XXXXXXXXXXXX4321");
		ar.setMmid("AACA013");
		ar.setId(1l);
		list.add(ar);		
		return list;
	}
	
	public static List<AccountSummary> prepareAccountSummaryList(List<AccountReference> accRefs) {
		List<AccountSummary> list = new ArrayList<AccountSummary>();
		Long id = 0l; 
		Iterator<AccountReference> iterator = accRefs.iterator();
		AccountReference ref = null;
		while (iterator.hasNext()) {
			ref =  (AccountReference) iterator.next();
			AccountSummary ar = new AccountSummary();
			ar.setAeba(ref.getAeba());
			ar.setIfsc(ref.getIfsc());
			ar.setMaskedAccnumber(ref.getMaskedNumber());
			ar.setName(ref.getName());
			ar.setCredentailType(ref.getCredentailType());
			ar.setCredentailSubType(ref.getCredentailSubType());
			ar.setCredentailDataType(ref.getCredentailDataType());
			ar.setCredentailDataLength(ref.getCredentailDataLength());
			ar.setId(++id);
			list.add(ar);
		}
		return list;
	}	

	public static StatusCode validateMobileDeviceDetails(DeviceDetails deviceDetails, MobileDevice mobileDevice, 
															String appBaseVersion, String appCurrentVersion, 
															GcmNotification gcmNotification, UserProfileDto user) {
		StatusCode statusCode = StatusCode.SUCCESS;
		String mobileVersion = mobileDevice.getApp().substring(14);
		if (!(deviceDetails.getOs().equals(mobileDevice.getOs())
				&& deviceDetails.getTerminalId().equals(mobileDevice.getTerminalId())
					&& deviceDetails.getCapability().equals(mobileDevice.getCapability())
					&& deviceDetails.getType().equals(mobileDevice.getType())
					&& deviceDetails.getMobile().equals(mobileDevice.getMobile()))) {
			statusCode = StatusCode.DEVICE_VALIDATION_FAILED;
		}else if(!compareVersion(mobileVersion, appBaseVersion)) {
			statusCode = StatusCode.APP_VERSION_VALIDATION_FAILED;
		}else if(!compareVersion(mobileVersion, appCurrentVersion)) {
			String notificationId = String.valueOf(System.currentTimeMillis());			
			Result result = gcmNotification.send(notificationId, APP_UPDATE_NOTIFICATION, StatusCode.APP_UPDATE_AVAILABLE.name(), user.getRnsMpaId());
			if (result.getMessageId() == null) {
				throw new RuntimeException("Not able to send the GCM Notification for App updates"); 
			} 
		}
		
		return statusCode;
	}	

	public static String getHexString(byte[] buffer) {
		  if(buffer == null) {
		   return null;
		  }
		  else {
		   return getHexString(buffer, 0, buffer.length);
		  }
	}
	
	public static String getHexString(byte[] buffer, int offset, int length) {
		if(buffer == null || offset < 0 || length < 0 || offset + length > buffer.length){
		   return null;
		}
	    StringBuilder sb = new StringBuilder();
		for (int i = offset; i < (offset + length); i++) {
		  sb.append(String.format("%02X", buffer[i]));
		}
		return sb.toString();
	}
	
	public static MobileNotification prepareMobileNotifications(NotificationDetails notificationDetails) {
		MobileNotification mobileNotificationDetails = new MobileNotification();
		mobileNotificationDetails.setNotificationId(notificationDetails.getNotificationId());
		mobileNotificationDetails.setNotificationMessage(notificationDetails.getNotificationMessage());
		mobileNotificationDetails.setNotificationtType(notificationDetails.getNotificationtType());
		return mobileNotificationDetails;
	}
	
	public static BillMappingDetails prepareBillMappingDetails(BillDetails billDetails, String userName, Long merchantId) {
		BillMappingDetails billMappingDetails = new BillMappingDetails();
		billMappingDetails.setBillDate(billDetails.getBillDate());
		billMappingDetails.setCustomerName(userName);
		billMappingDetails.setExpDate(billDetails.getExpDate());
		billMappingDetails.setIdentification(billDetails.getIdentification());
		billMappingDetails.setMerchantId(merchantId);
		billMappingDetails.setNotificationDate(billDetails.getNotificationDate());
		billMappingDetails.setNotificationExpDate(billDetails.getNotificationExpDate());
		return billMappingDetails;
	}
	
	private static boolean compareVersion(String appVersion, String baseVersion) {
		
		if(appVersion.isEmpty() || baseVersion.isEmpty()){
			throw new RuntimeException(StatusCode.INVALID_VERSION.getMessage());
		}
	    String[] appVersionArray = appVersion.split("\\.");
	    String[] baseVersionArray = baseVersion.split("\\.");
	 
	    int i=0;
		while (i < appVersionArray.length || i < baseVersionArray.length) {
			if (i < appVersionArray.length && i < baseVersionArray.length) {
				if (Integer.parseInt(appVersionArray[i]) < Integer
						.parseInt(baseVersionArray[i])) {
					return false;
				}
			}
			i++;
		}
	    return true;
}
}
