/**
 * 
 */
package psp.mobile.process.factory.impl;

import java.util.Date;
import java.util.Locale;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.stereotype.Component;

import psp.common.PropertyReader;
import psp.common.exception.ApplicationException;
import psp.constants.AuthStatusCode;
import psp.constants.StatusCode;
import psp.constants.UserConstants;
import psp.dbservice.mgmt.PspMgmtService;
import psp.dbservice.model.DeviceDetails;
import psp.dbservice.model.LoginDetails;
import psp.dto.AuthenticationDto;
import psp.dto.UserProfileDto;
import psp.mobile.model.request.LoginRequest;
import psp.mobile.model.response.LoginResponse;
import psp.mobile.model.response.MessageResponse;
import psp.mobile.process.factory.MobileCoreProcess;
import psp.mobile.process.util.MobileProcessUtility;
import psp.user.service.UserService;
import psp.user.util.PasswordEncryptor;
import psp.util.gcm.GcmNotification;

/**
 * @author prasadj
 *
 */
@Component("loginMpfb")
public class LoginProcessImpl extends MobileCoreProcess {

	private static final Logger LOGGER = Logger.getLogger(LoginProcessImpl.class.getName());
	
	@Autowired
	private PspMgmtService pspMgmtService;
	
	@Autowired
	private UserService userService;	
	
	@Autowired
	private PropertyReader propertyReader;
	
	@Autowired
	private GcmNotification gcmNotification;
	
	@Autowired
	private MessageSource messageSource;
	
	public LoginProcessImpl(){		
	}
	
	@Override
	public MessageResponse validateRequest() {
		LoginResponse response = new LoginResponse();
		response.validate((LoginRequest) request);
		return response;
	}

	@Override
	public void doProcess(MessageResponse response) throws ApplicationException {
		LOGGER.info("doProcess of LoginProcessImpl started ");
		LoginResponse res = (LoginResponse) response;
		LoginRequest req = (LoginRequest) request;
		UserProfileDto user = pspMgmtService.getUserByName(request.getUserName());
		AuthenticationDto authentication = pspMgmtService.getAuthenticationDto(request.getUserName());
		if (null != user && null != authentication) {
			boolean flag = PasswordEncryptor.checkPassword(req.getPassword(), authentication.getPassword());
			if(flag) {
				DeviceDetails deviceFromDb = pspMgmtService.getDeviceDetailsByUserId(user.getId());
				StatusCode statusCode = MobileProcessUtility.validateMobileDeviceDetails(deviceFromDb, request.getDevice(), propertyReader.getAppBaseVersion(),propertyReader.getAppCurrentVersion(), gcmNotification, user);
				if(StatusCode.SUCCESS == statusCode) {
					 LoginDetails loginDetails = pspMgmtService.getLoginDetailsByUserName(req.getUserName());
					 if (null != loginDetails) {
						loginDetails.setLoginTime(new Date());
						pspMgmtService.updateLoginDetails(loginDetails);
					} else {
						pspMgmtService.saveLoginDetails(MobileProcessUtility.prepareLoginDetails(user.getLoginName(), deviceFromDb.getTerminalId()));					
					}
					res.setAccountSummary(pspMgmtService.getAccountSummaryByUserDetailsId(user.getId()));
					authentication.setPwAttempts(0);
					pspMgmtService.updateAuthentication(authentication);
				}
				else {
					throw new ApplicationException(StatusCode.DEVICE_VALIDATION_FAILED) ;
				}	
			}
			else {
				
			}
		} else {
			if(authentication.getPwAttempts() < UserConstants.MAX_PWD_ATTEMPTS ){
				Integer pwAttempts = authentication.getPwAttempts() + 1;
				authentication.setPwAttempts(pwAttempts);
				if(pwAttempts == UserConstants.MAX_PWD_ATTEMPTS){
					authentication.setPwdStatus(AuthStatusCode.LOCKED.getValue());
					pspMgmtService.updateAuthentication(authentication);
					throw new ApplicationException(StatusCode.USER_ACCOUNT_LOCKED);
				}
				pspMgmtService.updateAuthentication(authentication);
			}else{
				throw new ApplicationException(StatusCode.USER_ACCOUNT_LOCKED);
			}
			throw new ApplicationException(StatusCode.USERNAME_OR_PASSWORD_INCORRECT);
		}
		LOGGER.info("doProcess of LoginProcessImpl completed ");
	}

	@Override
	public MessageResponse createResponseOnStatusCode(StatusCode code, Locale locale) {
		LoginResponse response = new LoginResponse();
		response.setStatusCode(code.getCode());
		response.setStatusMessage(messageSource.getMessage(code.getCode(), null, locale));
		return response;
	}

}