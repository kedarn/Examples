package psp.mobile.process;

import java.util.Locale;

import psp.mobile.model.request.MobileRequest;
import psp.mobile.model.response.MessageResponse;

public interface MobileRequestProcessor {

	MessageResponse processAuthorisedRequest(MobileRequest request, Locale locale);
		
	MessageResponse processNonAuthorisedRequest(MobileRequest request, Locale locale);
	
}