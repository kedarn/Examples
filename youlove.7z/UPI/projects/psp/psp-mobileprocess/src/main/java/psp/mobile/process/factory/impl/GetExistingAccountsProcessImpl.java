package psp.mobile.process.factory.impl;

import java.util.Locale;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.stereotype.Component;

import psp.constants.StatusCode;
import psp.dbservice.mgmt.PspMgmtService;
import psp.mobile.model.response.GetExistingAccountsResponse;
import psp.mobile.model.response.MessageResponse;
import psp.mobile.process.factory.MobileCoreProcess;

@Component("getExistingAccsMpfb")
public class GetExistingAccountsProcessImpl extends MobileCoreProcess {

	private static final Logger LOGGER = Logger.getLogger(GetExistingAccountsProcessImpl.class.getName());
	
	@Autowired
	private PspMgmtService pspMgmtService;
	
	@Autowired
	private MessageSource messageSource;

	public GetExistingAccountsProcessImpl() {
	}

	@Override
	public MessageResponse validateRequest() {
		GetExistingAccountsResponse response = new GetExistingAccountsResponse();
		response.validate();
		return response;
	}

	@Override
	public void doProcess(MessageResponse response) {
		LOGGER.info("doProcess of GetExistingAccountsProcessImpl started ");
		GetExistingAccountsResponse res = (GetExistingAccountsResponse) response;
		res.setAccountSummary(pspMgmtService.getAccountSummaryByUserDetailsId(user.getId()));
		LOGGER.info("doProcess of GetExistingAccountsProcessImpl completed ");
	}

	@Override
	public MessageResponse createResponseOnStatusCode(StatusCode code, Locale locale) {
		GetExistingAccountsResponse response = new GetExistingAccountsResponse();
		response.setStatusCode(code.getCode());
		response.setStatusMessage(messageSource.getMessage(code.getCode(), null, locale));
		return response;
	}

}
