package psp.mobile.process.factory.impl;

import java.util.Date;
import java.util.Locale;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.stereotype.Component;
import org.upi.system_1_2.Ack;
import org.upi.system_1_2.CredSubType;
import org.upi.system_1_2.CredType;
import org.upi.system_1_2.CredsType;
import org.upi.system_1_2.HeadType;
import org.upi.system_1_2.PayConstant;
import org.upi.system_1_2.PayTrans;
import org.upi.system_1_2.PayerConstant;
import org.upi.system_1_2.PayerType;
import org.upi.system_1_2.ReqRegMob;

import psp.common.PropertyReader;
import psp.common.exception.ApplicationException;
import psp.constants.CommonConstants;
import psp.constants.ServiceNotes;
import psp.constants.ServiceStatus;
import psp.constants.StatusCode;
import psp.dbservice.mgmt.PspMgmtService;
import psp.dbservice.model.AccountDetails;
import psp.dbservice.model.GeneratePinUpiRequest;
import psp.mobile.model.request.GeneratePinRequest;
import psp.mobile.model.response.GeneratePinResponse;
import psp.mobile.model.response.MessageResponse;
import psp.mobile.process.factory.MobileCoreProcess;
import psp.mobile.process.util.MobileProcessUtility;
import psp.util.DtoObjectUtil;
import psp.util.PspClientTool;
import psp.util.dto.AcDto;
import psp.util.upi.client.UpiClientService;
import psp.util.upiclient.UpiDataPreparationUtility;

@Component("generatePinMpfb")
public class GeneratePinProcessImpl extends MobileCoreProcess {

	private static final Logger LOGGER = Logger.getLogger(GeneratePinProcessImpl.class.getName());
	
	@Autowired
	private PspMgmtService pspMgmtService;
	
	@Autowired
	private UpiClientService upiClient;
	
	@Autowired
	private PropertyReader propertyReader;
	
	@Autowired
	private MessageSource messageSource;
	
	public GeneratePinProcessImpl() {
	}
	
	@Override
	public MessageResponse validateRequest() {
		GeneratePinResponse response = new GeneratePinResponse();
		response.vaildate();
		return response;
	}

	@Override
	public void doProcess(MessageResponse response) throws ApplicationException {
		LOGGER.info("doProcess of GeneratePinProcessImpl started ");
		GeneratePinRequest generatePinRequest = (GeneratePinRequest) request;
		Date date = new Date();
		String messageId = DtoObjectUtil.constructMessageId();
		HeadType head = DtoObjectUtil.constructHeadType(messageId, date);
		String id = generatePinRequest.getTxnId();
		PayTrans txn = DtoObjectUtil.constructPayTrans(id, ServiceNotes.REG_MOB, null, date, PayConstant.REQ_REG_MOB, propertyReader.getReferenceUrl(), false);	
		String fullName = user.getFirstName() + CommonConstants.SPACE_STR + user.getMiddleName() + CommonConstants.SPACE_STR + user.getLastName();
		PayerConstant payerType = PayerConstant.PERSON;
		AccountDetails acDetails = pspMgmtService.getAccountDetailsByUserDetailsId(user.getId());
		AcDto acDto = MobileProcessUtility.getAcDto(acDetails);
		PayerType payer = DtoObjectUtil.constructPayerDto(acDetails.getVirtualAddress(), fullName, payerType, acDto, null, null, null, request.getDevice(), null);
		
		CredsType credsType = UpiDataPreparationUtility.constructCredsType(CredType.PIN, CredSubType.MPIN, generatePinRequest.getMobileCredentials().getDataValue(), "NPCI", "20150822");
		ReqRegMob.RegDetails regDetailsDto = DtoObjectUtil.constructRegDetailsDto(request.getDevice().getMobile(), generatePinRequest.getCardDigits(), generatePinRequest.getExpiryDate(), credsType);
		String ackXml = upiClient.regMob(head, txn, payer, regDetailsDto);
		Ack ackRes = PspClientTool.convertUpiRequest(ackXml, Ack.class);
		boolean respReceived = false;
		if(ackRes.getErr() == null) {
			pspMgmtService.saveUpiRequest(MobileProcessUtility.prepareUpiRequestDetails(messageId, id, GeneratePinUpiRequest.class));
			int maxDelay = propertyReader.getMaxDelayInterval(); //seconds
			int count = 0;
			do {
				GeneratePinUpiRequest genPin =  (GeneratePinUpiRequest) pspMgmtService.getUpiRequestByTxnId(id);
				if (ServiceStatus.RECEIVED.name().equals(genPin.getStatus())) {
					respReceived = true;
					if(CommonConstants.SUCCESS.equals(genPin.getResult())) {
						prepareResponse(genPin, response, acDetails);
					}
					else{
						pspMgmtService.deleteUpiRequest(genPin);
						throw new ApplicationException(StatusCode.GEN_PIN_REQUEST_FAILED);
					}
				}	
				try{
					count++;
					Thread.sleep(propertyReader.getMobileProcessDelay());
				}
				catch(Exception ex){
				}
				if(count > maxDelay){
					LOGGER.info("UPI Request time out");
					pspMgmtService.deleteUpiRequest(genPin);
					throw new ApplicationException(StatusCode.GEN_PIN_REQUEST_FAILED);
				}
			}while (!respReceived);
		}
		else {
			throw new ApplicationException(StatusCode.GEN_PIN_REQUEST_FAILED);
		}
		LOGGER.info("doProcess of GeneratePinProcessImpl completed ");
		
	}

	@Override
	public MessageResponse createResponseOnStatusCode(StatusCode code, Locale locale) {
		GeneratePinResponse response = new GeneratePinResponse();
		response.setStatusCode(code.getCode());
		response.setStatusMessage(messageSource.getMessage(code.getCode(), null, locale));
		return response;
	}

	private void prepareResponse(GeneratePinUpiRequest genPin, MessageResponse response, AccountDetails acDetails) {
		acDetails.setIsPinSet(true);
		pspMgmtService.updateAccountDetails(acDetails);
		pspMgmtService.deleteUpiRequest(genPin);
		response.setStatusCode(StatusCode.SUCCESS.getCode());
		response.setStatusMessage(StatusCode.GEN_PIN_SERVICE_SUCCESS.getMessage());
	}
	
}
