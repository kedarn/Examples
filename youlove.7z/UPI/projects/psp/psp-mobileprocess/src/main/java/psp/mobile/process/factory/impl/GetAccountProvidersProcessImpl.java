/**
 * 
 */
package psp.mobile.process.factory.impl;

import java.util.Locale;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.stereotype.Component;

import psp.constants.StatusCode;
import psp.dbservice.mgmt.PspMgmtService;
import psp.mobile.model.response.GetAccountProvidersResponse;
import psp.mobile.model.response.MessageResponse;
import psp.mobile.process.factory.MobileCoreProcess;

/**
 * @author prasadj
 *
 */
@Component("accountProvidersMpfb")
public class GetAccountProvidersProcessImpl extends MobileCoreProcess {

	private static final Logger LOGGER = Logger.getLogger(GetAccountProvidersProcessImpl.class.getName());
	
	@Autowired
	private PspMgmtService pspMgmtService;
	
	@Autowired
	private MessageSource messageSource;
	
	public GetAccountProvidersProcessImpl(){
	}

	@Override
	public MessageResponse validateRequest() {
		GetAccountProvidersResponse response = new GetAccountProvidersResponse();
		response.validate();
		return response;
	}

	@Override
	public void doProcess(MessageResponse response) {
		LOGGER.info("doProcess of GetAccountProvidersProcessImpl started ");
		((GetAccountProvidersResponse)response).setListOfBanks(pspMgmtService.getBankSummary());	
		LOGGER.info("doProcess of GetAccountProvidersProcessImpl completed ");
	}

	@Override
	public MessageResponse createResponseOnStatusCode(StatusCode code, Locale locale) {
		GetAccountProvidersResponse response = new GetAccountProvidersResponse();
		response.setStatusCode(code.getCode());
		response.setStatusMessage(messageSource.getMessage(code.getCode(), null, locale));
		return response;
	}

}