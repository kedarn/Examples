/**
 * 
 */
package psp.mobile.process.factory.impl;

import java.util.Locale;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.stereotype.Component;

import psp.common.exception.ApplicationException;
import psp.constants.StatusCode;
import psp.constants.UserStatus;
import psp.dbservice.mgmt.PspMgmtService;
import psp.dto.AuthenticationDto;
import psp.mobile.model.request.DRegisterRequest;
import psp.mobile.model.response.DregisterResponse;
import psp.mobile.model.response.MessageResponse;
import psp.mobile.process.factory.MobileCoreProcess;
import psp.user.service.UserService;

/**
 * @author prasadj
 *
 */
@Component("DeregisterUserMpfb")
public class DRegisterUserProcessImpl extends MobileCoreProcess {

	private static final Logger LOGGER = Logger.getLogger(DRegisterUserProcessImpl.class.getName());
	
	@Autowired
	private PspMgmtService pspMgmtService;
	
	@Autowired
	private UserService userService;	
	
	@Autowired
	private MessageSource messageSource;
	
	public DRegisterUserProcessImpl(){		
	}
	
	@Override
	public MessageResponse validateRequest() {
		DregisterResponse response = new DregisterResponse();
		response.validate((DRegisterRequest) request);
		return response;
	}

	@Override
	public void doProcess(MessageResponse response) throws ApplicationException {
		LOGGER.info("doProcess of DRegisterUserProcessImpl started ");
		AuthenticationDto authentication = pspMgmtService.getAuthenticationDto(request.getUserName());
		if (null != authentication) {
				authentication.setUserStatus(UserStatus.SUSPEND.getValue());
				pspMgmtService.updateAuthentication(authentication);
		} else {
			throw new ApplicationException(StatusCode.USER_NOT_REGISTER);
		}
		LOGGER.info("doProcess of DRegisterUserProcessImpl completed ");
	}

	@Override
	public MessageResponse createResponseOnStatusCode(StatusCode code, Locale locale) {
		DregisterResponse response = new DregisterResponse();
		response.setStatusCode(code.getCode());
		response.setStatusMessage(messageSource.getMessage(code.getCode(), null, locale));
		return response;
	}

}