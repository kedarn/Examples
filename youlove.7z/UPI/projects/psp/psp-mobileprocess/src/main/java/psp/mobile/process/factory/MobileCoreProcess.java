/**
 * 
 */
package psp.mobile.process.factory;

import java.util.Locale;

import psp.common.exception.ApplicationException;
import psp.constants.StatusCode;
import psp.dbservice.model.LoginDetails;
import psp.dto.AuthenticationDto;
import psp.dto.UserProfileDto;
import psp.mobile.model.request.MobileRequest;
import psp.mobile.model.response.MessageResponse;

/**
 * @author prasadj
 *
 */
public abstract class MobileCoreProcess {

	protected MobileRequest request;
	
	protected UserProfileDto user;
	
	protected LoginDetails loginDetails;
	
	protected AuthenticationDto authentication;
	
	public MobileCoreProcess(){
	}
	
	public abstract MessageResponse validateRequest();
	
	public abstract void doProcess(MessageResponse response) throws ApplicationException;
	
	public abstract MessageResponse createResponseOnStatusCode(StatusCode code, Locale locale);
	
	public void setUser(UserProfileDto user){
		this.user = user;
	}
	
	public void setRequest(MobileRequest request){
		this.request = request;
	}
	
	public void setLoginDetails(LoginDetails loginDetails){
		this.loginDetails = loginDetails;
	}
	
	public void setAuthenticationr(AuthenticationDto authentication){
		this.authentication = authentication;
	}
	
}