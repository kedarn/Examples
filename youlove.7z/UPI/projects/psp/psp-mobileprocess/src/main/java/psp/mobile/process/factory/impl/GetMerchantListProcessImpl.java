package psp.mobile.process.factory.impl;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.stereotype.Component;

import psp.common.exception.ApplicationException;
import psp.constants.StatusCode;
import psp.dto.UserSearchDto;
import psp.mobile.model.request.GetMerchantListRequest;
import psp.mobile.model.response.GetMerchantListResponse;
import psp.mobile.model.response.MerchantDetails;
import psp.mobile.model.response.MessageResponse;
import psp.mobile.process.factory.MobileCoreProcess;
import psp.user.service.CommonService;

@Component("getMerchantListMpfb")
public class GetMerchantListProcessImpl extends MobileCoreProcess {

	private static final Logger LOGGER = Logger.getLogger(GetMerchantListProcessImpl.class.getName());
	
	@Autowired
	private CommonService commonService;
	
	@Autowired
	private MessageSource messageSource;
	
	public GetMerchantListProcessImpl() {
	}
	
	@Override
	public MessageResponse validateRequest() {
		GetMerchantListResponse response = new GetMerchantListResponse();
		response.validate();
		return response;
	}

	@Override
	public void doProcess(MessageResponse response) throws ApplicationException {
		LOGGER.info("doProcess of GetMerchantListProcessImpl started ");
		GetMerchantListRequest req = (GetMerchantListRequest) request;
		GetMerchantListResponse res = (GetMerchantListResponse) response;
		List<MerchantDetails> merchantDetails = new ArrayList<>();
		merchantDetails = commonService.getCustomerAddedMerchants(new UserSearchDto(), req.getUserName());	
		res.setMerchantList(merchantDetails);
		LOGGER.info("doProcess of GetMerchantListProcessImpl completed ");
	}

	@Override
	public MessageResponse createResponseOnStatusCode(StatusCode code, Locale locale) {
		GetMerchantListResponse response = new GetMerchantListResponse();
		response.setStatusCode(code.getCode());
		response.setStatusMessage(messageSource.getMessage(code.getCode(), null, locale));
		return response;
	}

}
