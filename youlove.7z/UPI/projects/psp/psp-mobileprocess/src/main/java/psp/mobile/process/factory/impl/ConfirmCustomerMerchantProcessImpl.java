package psp.mobile.process.factory.impl;

import java.util.Locale;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.stereotype.Component;

import psp.common.exception.ApplicationException;
import psp.constants.StatusCode;
import psp.dbservice.model.BillMappingDetails;
import psp.dbservice.model.MerchantAccount;
import psp.mobile.model.request.ConformCustomerMerchantRequest;
import psp.mobile.model.response.ConformCustomerMerchantResponse;
import psp.mobile.model.response.MessageResponse;
import psp.mobile.process.factory.MobileCoreProcess;
import psp.mobile.process.util.MobileProcessUtility;
import psp.user.service.CommonService;
import psp.user.service.UserService;

@Component("confirmCustomerMerchantMpfb")
public class ConfirmCustomerMerchantProcessImpl extends MobileCoreProcess {

	private static final Logger LOGGER = Logger.getLogger(ConfirmCustomerMerchantProcessImpl.class.getName());
	
	@Autowired
	private CommonService commonService;
	
	@Autowired
	private UserService userService;
	
	@Autowired
	private MessageSource messageSource;
	
	public ConfirmCustomerMerchantProcessImpl() {
	}

	@Override
	public MessageResponse validateRequest() {
		ConformCustomerMerchantResponse response = new ConformCustomerMerchantResponse();
		response.validate();
		return response;
	}

	@Override
	public void doProcess(MessageResponse response) throws ApplicationException {
		LOGGER.info("doProcess of ConfirmCustomerMerchantProcessImpl started ");
		ConformCustomerMerchantRequest req = (ConformCustomerMerchantRequest) request;
		MerchantAccount ma  = userService.getMerchantAccountByMerchantId(req.getMerchantId());
		BillMappingDetails billMappingDetails = MobileProcessUtility.prepareBillMappingDetails(req.getBillDetails(), req.getUserName(), req.getMerchantId());
		billMappingDetails.setMerchantVirtualAddress(ma.getVirtualAddress());
		commonService.saveBillMappingDetails(billMappingDetails);
		LOGGER.info("doProcess of ConfirmCustomerMerchantProcessImpl completed ");
	}

	@Override
	public MessageResponse createResponseOnStatusCode(StatusCode code, Locale locale) {
		ConformCustomerMerchantResponse response = new ConformCustomerMerchantResponse();
		response.setStatusCode(code.getCode());
		response.setStatusMessage(messageSource.getMessage(code.getCode(), null, locale));
		return response;
	}

}
