package psp.mobile.process.factory.impl;

import java.util.Locale;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.stereotype.Component;

import psp.common.exception.ApplicationException;
import psp.constants.StatusCode;
import psp.dto.ForgetPasswordDto;
import psp.mobile.model.response.MessageResponse;
import psp.mobile.model.response.ResendResetPasswordResponse;
import psp.mobile.process.factory.MobileCoreProcess;
import psp.user.service.ForgetPasswordService;

@Component("resendResetPasswordMpfb")
public class ResendResetPasswordProcessImpl extends MobileCoreProcess {

	private static final Logger LOGGER = Logger.getLogger(ResendResetPasswordProcessImpl.class.getName());
	
	@Autowired
	private ForgetPasswordService forgetPasswordService;
	
	@Autowired
	private MessageSource messageSource;
	
	public ResendResetPasswordProcessImpl() {
	}
	
	@Override
	public MessageResponse validateRequest() {
		ResendResetPasswordResponse response = new ResendResetPasswordResponse();
		response.validate();
		return response;
	}

	@Override
	public void doProcess(MessageResponse response) throws ApplicationException {
		LOGGER.info("doProcess of ResendResetPasswordProcessImpl started ");
		ForgetPasswordDto forgetPasswordDto = forgetPasswordService.resendPasswordLink(request.getUserName());
		if(null != forgetPasswordDto.getMessage()) {
			throw new ApplicationException(StatusCode.getStatusCodeByCode(forgetPasswordDto.getMessage()));
		}
		LOGGER.info("doProcess of ResendResetPasswordProcessImpl Completed ");
	}

	@Override
	public MessageResponse createResponseOnStatusCode(StatusCode code, Locale locale) {
		ResendResetPasswordResponse response = new ResendResetPasswordResponse();
		response.setStatusCode(code.getCode());
		response.setStatusMessage(messageSource.getMessage(code.getCode(), null, locale));
		return response;
	}

}
