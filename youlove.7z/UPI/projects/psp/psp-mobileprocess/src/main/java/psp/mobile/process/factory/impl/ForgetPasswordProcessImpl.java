package psp.mobile.process.factory.impl;

import java.util.Locale;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.stereotype.Component;

import psp.common.exception.ApplicationException;
import psp.constants.StatusCode;
import psp.dto.ForgetPasswordDto;
import psp.mobile.model.response.ForgetPasswordResponse;
import psp.mobile.model.response.MessageResponse;
import psp.mobile.process.factory.MobileCoreProcess;
import psp.user.service.ForgetPasswordService;

@Component("forgetPasswordMpfb")
public class ForgetPasswordProcessImpl extends MobileCoreProcess {

	private static final Logger LOGGER = Logger.getLogger(ForgetPasswordProcessImpl.class.getName());
	
	@Autowired
	private ForgetPasswordService forgetPasswordService;
	
	@Autowired
	private MessageSource messageSource;
	
	public ForgetPasswordProcessImpl(){
	}
	
	@Override
	public MessageResponse validateRequest() {
		ForgetPasswordResponse response = new ForgetPasswordResponse();
		response.validate();
		return response;
	}

	@Override
	public void doProcess(MessageResponse response) throws ApplicationException {
		LOGGER.info("doProcess of ForgetPasswordProcessImpl started ");
		ForgetPasswordResponse res = (ForgetPasswordResponse) response;
		ForgetPasswordDto forgetPasswordDto = forgetPasswordService.sendSequrityQuestions(request.getUserName());
		if(null != forgetPasswordDto.getMessage()) {
			throw new ApplicationException(StatusCode.getStatusCodeByCode(forgetPasswordDto.getMessage()));
		}
		else {
			res.setSecurityQuestions(forgetPasswordDto.getSecurityQuestions());
		}
		LOGGER.info("doProcess of ForgetPasswordProcessImpl completed ");

	}

	@Override
	public MessageResponse createResponseOnStatusCode(StatusCode code, Locale locale) {
		ForgetPasswordResponse response = new ForgetPasswordResponse();
		response.setStatusCode(code.getCode());
		response.setStatusMessage(messageSource.getMessage(code.getCode(), null, locale));
		return response;
	}

}