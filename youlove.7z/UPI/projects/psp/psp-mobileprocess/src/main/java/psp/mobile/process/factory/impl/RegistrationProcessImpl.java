/**
 * 
 */
package psp.mobile.process.factory.impl;

import java.util.Locale;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.stereotype.Component;

import psp.common.exception.ApplicationException;
import psp.constants.StatusCode;
import psp.dbservice.mgmt.PspMgmtService;
import psp.dbservice.model.KeyInfo;
import psp.dto.UserProfileDto;
import psp.mobile.model.request.RegistrationRequest;
import psp.mobile.model.response.MessageResponse;
import psp.mobile.model.response.RegistrationResponse;
import psp.mobile.process.factory.MobileCoreProcess;
import psp.mobile.process.util.MobileProcessUtility;
import psp.user.service.UserService;

/**
 * @author prasadj
 *
 */
@Component("registrationMpfb")
public class RegistrationProcessImpl extends MobileCoreProcess {

	private static final Logger LOGGER = Logger.getLogger(RegistrationProcessImpl.class.getName());
	
	@Autowired
	private PspMgmtService pspMgmtService;
	
	@Autowired
	private UserService userService;
	
	@Autowired
	private MessageSource messageSource;
	
	public RegistrationProcessImpl(){
	}
	
	@Override
	public MessageResponse validateRequest() {
		RegistrationResponse response = new RegistrationResponse();
		response.validate((RegistrationRequest)request);
		return response;
	}

	@Override
	public void doProcess(MessageResponse response) throws ApplicationException {
		LOGGER.info("doProcess of RegistrationProcessImpl started ");
		RegistrationRequest req = (RegistrationRequest) request;
		RegistrationResponse registrationResponse = (RegistrationResponse)response;
		UserProfileDto customer = pspMgmtService.getUser(request.getUserName(), req.getMobileNumber(), req.getAdharNumber());
		if(null == customer) {
			UserProfileDto customerDto = MobileProcessUtility.prepareCustomerDto(req);
			pspMgmtService.saveCustomerRegistration(customerDto);
			KeyInfo keyInfo = pspMgmtService.getKeyInfo();
			if(null != keyInfo) {
				registrationResponse.setXmlPayload(keyInfo.getXmlPayload());//	CommonConstants.payload
			}			
		}
		else {
			if(req.getAdharNumber().equals(customer.getAadhaarNumber())){
				throw new ApplicationException(StatusCode.DUPLICATE_AADHAAR_NUMBER);
			}
			else if(req.getMobileNumber().equals(customer.getPhoneNumber())) {
				throw new ApplicationException(StatusCode.DUPLICATE_MOBILE_NUMBER);
			}
			else if(req.getUserName().equals(customer.getLoginName())) {
				throw new ApplicationException(StatusCode.DUPLICATE_USER_NAME);
			}
		}
		LOGGER.info("doProcess of RegistrationProcessImpl completed ");
	}

	@Override
	public MessageResponse createResponseOnStatusCode(StatusCode code, Locale locale) {
		RegistrationResponse response = new RegistrationResponse();
		response.setStatusCode(code.getCode());
		response.setStatusMessage(messageSource.getMessage(code.getCode(), null, locale));
		return response;
	}
	
}