/**
 * 
 */
package psp.mobile.process.factory.impl;

import java.util.Date;
import java.util.Locale;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.stereotype.Component;
import org.upi.system_1_2.Ack;
import org.upi.system_1_2.CredSubType;
import org.upi.system_1_2.CredType;
import org.upi.system_1_2.CredsType;
import org.upi.system_1_2.HeadType;
import org.upi.system_1_2.PayConstant;
import org.upi.system_1_2.PayTrans;
import org.upi.system_1_2.PayerConstant;
import org.upi.system_1_2.PayerType;

import psp.common.PropertyReader;
import psp.common.exception.ApplicationException;
import psp.constants.CommonConstants;
import psp.constants.ServiceNotes;
import psp.constants.ServiceStatus;
import psp.constants.StatusCode;
import psp.constants.UserStatus;
import psp.dbservice.mgmt.PspMgmtService;
import psp.dbservice.model.AccountDetails;
import psp.dbservice.model.SetCredentialUpiRequest;
import psp.mobile.model.request.SetPinRequest;
import psp.mobile.model.response.MessageResponse;
import psp.mobile.model.response.SetPinResponse;
import psp.mobile.process.factory.MobileCoreProcess;
import psp.mobile.process.util.MobileProcessUtility;
import psp.util.DtoObjectUtil;
import psp.util.PspClientTool;
import psp.util.dto.AcDto;
import psp.util.upi.client.UpiClientService;
import psp.util.upiclient.UpiDataPreparationUtility;

/**
 * @author prasadj
 *
 */
@Component("setPinMpfb")
public class SetPinProcessImpl extends MobileCoreProcess {

	private static final Logger LOGGER = Logger.getLogger(SetPinProcessImpl.class.getName());
	
	@Autowired
	private PspMgmtService pspMgmtService;
	
	@Autowired
	private UpiClientService upiClient;
	
	@Autowired
	private PropertyReader propertyReader;
	
	@Autowired
	private MessageSource messageSource;
	
	public SetPinProcessImpl() {
	}
	
	@Override
	public MessageResponse validateRequest() {
		SetPinResponse response = new SetPinResponse();
		response.validate((SetPinRequest)request);
		return response;
	}

	 /*1. login expire time has to increase
	   2. If credential type is MPIN then only we need to allow the service
	   3. Need to discuss about the user status update*/
	@Override
	public void doProcess(MessageResponse response) throws ApplicationException {
		LOGGER.info("doProcess of SetPinProcessImpl started ");
		SetPinRequest req = (SetPinRequest) request;
		AccountDetails accDetails = pspMgmtService.getAccountDetailsByUserDetailsId(user.getId());
		if(null != accDetails){
			String msgId = DtoObjectUtil.constructMessageId();
			String id = DtoObjectUtil.constructTxnId();
			HeadType head = DtoObjectUtil.constructHeadType(msgId, new Date());
			PayTrans txn = DtoObjectUtil.constructPayTrans(id, ServiceNotes.SET_CRED_NOTE, null, new Date(), PayConstant.SET_CRE, propertyReader.getReferenceUrl(), false);
			String fullName = user.getFirstName() + CommonConstants.SPACE_STR + user.getMiddleName() + CommonConstants.SPACE_STR + user.getLastName();
			AcDto acDto = MobileProcessUtility.getAcDto(accDetails);
			CredsType credType = UpiDataPreparationUtility.constructCredsType(CredType.PIN, CredSubType.MPIN, req.getOldCredentials().getDataValue(), "NPCI", "20150822");
			CredsType newCredType = UpiDataPreparationUtility.constructCredsType(CredType.PIN, CredSubType.MPIN, req.getNewCredentials().getDataValue(), "NPCI", "20150822");
			
			PayerType payer = DtoObjectUtil.constructPayerDto(accDetails.getVirtualAddress(), fullName, PayerConstant.PERSON, acDto, null, credType, newCredType, null, null);
			
			String responseXml = upiClient.reqSetCre(head, txn, payer);
			Ack ack = PspClientTool.convertUpiRequest(responseXml, Ack.class);
			boolean respReceived = false;
			if(ack.getErr() == null) {
				pspMgmtService.saveUpiRequest(MobileProcessUtility.prepareUpiRequestDetails(msgId, id, SetCredentialUpiRequest.class));
				int maxDelay = propertyReader.getMaxDelayInterval(); //seconds
				int count = 0;
				do {
					SetCredentialUpiRequest credsRes = (SetCredentialUpiRequest) pspMgmtService.getUpiRequestByTxnId(id);
					if (ServiceStatus.RECEIVED.name().equals(credsRes.getStatus())) {
						respReceived = true;
						if(CommonConstants.SUCCESS.equals(credsRes.getResult())) {
							prepareResponse(accDetails, credsRes, response);
						}
						else{
							pspMgmtService.deleteUpiRequest(credsRes);
							throw new ApplicationException(StatusCode.SET_CREDENTIAL_FAILED);
						}
					}	
					try{
						count++;
						Thread.sleep(propertyReader.getMobileProcessDelay());
					}
					catch(Exception ex){
					}
					if(count > maxDelay){
						LOGGER.info("UPI Request time out ");
						pspMgmtService.deleteUpiRequest(credsRes);
						throw new ApplicationException(StatusCode.SET_CREDENTIAL_FAILED);
					}
				}while (!respReceived);
			}
			else {
				throw new ApplicationException(StatusCode.SET_CREDENTIAL_FAILED);
			}
		}
		else {
			throw new ApplicationException(StatusCode.ACCOUNT_DETAILS_NOT_FOUND);
		}
		LOGGER.info("doProcess of SetPinProcessImpl completed ");
	}

	@Override
	public MessageResponse createResponseOnStatusCode(StatusCode code, Locale locale) {
		SetPinResponse response = new SetPinResponse();
		response.setStatusCode(code.getCode());
		response.setStatusMessage(messageSource.getMessage(code.getCode(), null, locale));
		return response;
	}

	private void prepareResponse(AccountDetails accDetails, SetCredentialUpiRequest credsRes, MessageResponse response) {
		authentication.setUserStatus(UserStatus.ACTIVE.getValue());
		accDetails.setIsPinSet(true);
		pspMgmtService.updateAccountDetails(accDetails);
		pspMgmtService.updateAuthentication(authentication);
		pspMgmtService.deleteUpiRequest(credsRes);
		response.setStatusCode(StatusCode.SUCCESS.getCode());
		response.setStatusMessage(StatusCode.SET_CRED_SERVICE_SUCCESS.getMessage());
	}
}