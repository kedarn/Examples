package psp.notification.jms.server;

import java.util.Date;
import java.util.Properties;

import javax.mail.Authenticator;
import javax.mail.Message;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import psp.notification.model.EmailMessage;

/**
 * The Class is used to Send the mail to Recipients  based on SMTP Authentication.
 * it has the following methods.
 * 1. sendEmail
 * 2. SMTPAuthentication
 * 
 * 
 */
@Component
public class EmailSender {

	/** The Constant LOGGER. */
	private static final Logger LOGGER = Logger.getLogger(EmailSender.class.getName());

    /** The mailuser name. */
    @Value("${psp.mail.username}")
	private String mailuserName;

	/** The mailuserpassword. */
	@Value("${psp.mail.password}")
	private String mailuserpassword;
	
	/** The transportprotocol. */
	@Value("${psp.mail.transport.protocol}")
	private String transportprotocol;
	
	/** The starttlsenable. */
	@Value("${psp.mail.smtp.starttls.enable}")
	private String starttlsenable;
	
	/** The smtphost. */
	@Value("${psp.mail.smtp.host}")
	private String smtphost;

	/** The smtpport. */
	@Value("${psp.mail.smtp.port}")
	private String smtpport;

	/** The smtpauth. */
	@Value("${psp.mail.smtp.auth}")
	private String smtpauth;
	
	/** The from mail. */
	@Value("${psp.mail.frommail}")
	private String fromMail;		

	/** The maildebug. */
	@Value("${psp.mail.debug}")
	private String maildebug;
			
	public EmailSender(){
		System.out.println("EmailSender constructed...");
	}
	/**
	 * 
	 * This method is used to send the email by fallowing steps.
	 * Step 1: Set the SMTP Properties
	 * Step 2: Check the SMTP Authenticator
	 * Step 3: set the from and to address
	 * Step 4: Setting the Subject and Content Type
	 * Step 5: Send message
	 * 
	 * @param emailMsg the email msg
	 * @return true, if successful
	 */
	public boolean sendEmail(Object emailObj) {

		try {
			EmailMessage emailMsg = (EmailMessage)emailObj;
			System.out.println("sendEmail " + emailMsg.getToEmail() + "on " + new Date());
			LOGGER.info(emailMsg.getToEmail());
			boolean debug = false;
			// Set the SMTP Properties
			Properties props = new Properties();
			props.put("mail.transport.protocol", transportprotocol);
			props.put("mail.smtp.starttls.enable", starttlsenable);
			props.put("mail.smtp.host", smtphost);
			props.put("mail.smtp.port", smtpport);
			props.put("mail.smtp.auth", smtpauth);
			props.put("mail.debug", maildebug);
			// Check the SMTP Authenticator
			Authenticator auth = new SMTPAuthenticator();
			Session session = Session.getDefaultInstance(props, auth);
			session.setDebug(debug);
			Message msg = new MimeMessage(session);
			// set the from and to address
			InternetAddress addressFrom = new InternetAddress(fromMail);
			msg.setFrom(addressFrom);
			
			String[] recipients = new String[1];
			recipients[0] = emailMsg.getToEmail();
			InternetAddress[] addressTo = new InternetAddress[recipients.length];
			for (int i = 0; i < recipients.length; i++) {
				if (recipients[i] != null) {
					addressTo[i] = new InternetAddress(recipients[i]);
				}
			}

			msg.setRecipients(Message.RecipientType.TO, addressTo);
			// Setting the Subject and Content Type
			msg.setSubject(emailMsg.getMessageSubject());
			msg.setContent(emailMsg.getMessageBody(), "text/html");

			Transport.send(msg);
			LOGGER.info(emailMsg.getToEmail());
			return true;
		} 
		catch (Exception e) {
			LOGGER.error("Exceprion is Occurred: Mail Sending Failed : {} ", e);
			return false;
		}
	}

	/**
	 * The Class SMTPAuthenticator.
	 */
	private class SMTPAuthenticator extends javax.mail.Authenticator {

		/**
		 * getPasswordAuthentication
		 * 
		 * This method is used to authenticate the credentials.
		 *
		 * @return the password authentication
		 */
		public PasswordAuthentication getPasswordAuthentication() {
			String username = mailuserName;
			String password = mailuserpassword;
			
			return new PasswordAuthentication(username, password);
		}
	}

}