package psp.notification.jms.server;

import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.MessageListener;
import javax.jms.ObjectMessage;
import javax.jms.TextMessage;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;

import psp.notification.model.EmailMessage;

/**
 * This Email Processor class process message consume by MQ Server.
 * Once Message queue has the message, queue will invoke message processing.
 */
public class EmailProcessor implements MessageListener {

	/** The Constant LOG. */
	private static final Logger LOGGER = Logger.getLogger(EmailProcessor.class.getName());
	
    /** The email sender. */
    @Autowired
	EmailSender emailSender;

	/** The mail message. */
	EmailMessage mailMessage;

	/**
	 * This method is used to send the mail to Admin.
	 * @param  The message that we send to the Admin.
	 */
	@Override
	public void onMessage(Message message) {
		if (message instanceof ObjectMessage){
			ObjectMessage objectMessage = (ObjectMessage) message;
			try{
				emailSender.sendEmail((psp.notification.model.EmailMessage)objectMessage.getObject());
			}
			catch (JMSException ex) {
				LOGGER.error(ex.getMessage(), ex);
				throw new RuntimeException(ex);
			}
		}
		else if (message instanceof TextMessage) {
			try {
				TextMessage textMessage = (TextMessage) message;
				String xmlMessage = textMessage.getText();
				String[] mail = xmlMessage.split("\\|");
				// Construct the Mail Message Object
				mailMessage = new psp.notification.model.EmailMessage();
				mailMessage.setToEmail(mail[0]);
				mailMessage.setMessageBody(mail[1]);
				mailMessage.setMessageSubject(mail[2]);
				emailSender.sendEmail(mailMessage);
			} 
			catch (JMSException ex) {
				LOGGER.error(ex.getMessage(), ex);
				throw new RuntimeException(ex);
			}
			catch (Exception ex) {
				LOGGER.error(ex.getMessage(), ex);
				throw new RuntimeException(ex);
			}
		}
	}

	/**
	 * This method sets the email sender.
	 *
	 * @param emailSender the new email sender
	 */
	public void setEmailSender(EmailSender emailSender) {
		this.emailSender = emailSender;
	}

	/**
	 * This method is used to set the mail message.
	 *
	 * @param mailMessage the new mail message
	 */
	public void setMailMessage(psp.notification.model.EmailMessage mailMessage) {
		this.mailMessage = mailMessage;
	}

}