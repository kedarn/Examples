package psp.upi.process.factory.impl;

import java.util.Date;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.upi.system_1_2.HeadType;
import org.upi.system_1_2.PayTrans;
import org.upi.system_1_2.ReqRegMob;
import org.upi.system_1_2.RespRegMob;
import org.upi.system_1_2.RespType;

import psp.common.PropertyReader;
import psp.constants.CommonConstants;
import psp.constants.ServiceNames;
import psp.dbservice.mgmt.PspMgmtService;
import psp.upi.process.factory.UpiCoreHandler;
import psp.upi.process.util.TransactionThread;
import psp.util.DtoObjectUtil;
import psp.util.PspClientTool;
import psp.util.upi.client.UpiClientService;

@Component("reqRegMobHandler")
public class ReqRegMobHandlerImpl extends UpiCoreHandler {

	@Autowired
	private PspMgmtService pspMgmtService;

	@Autowired
	private UpiClientService upiClientService;
	
	@Autowired
	private PropertyReader propertyReader;
	
	public ReqRegMobHandlerImpl(){
	}
	
	@Override
	public String handleProcess(String upiData) {
		ReqRegMob response = PspClientTool.convertUpiRequest(upiData, ReqRegMob.class);
		Date date = new Date();
		String messageId = DtoObjectUtil.constructMessageId();
		HeadType head = DtoObjectUtil.constructHeadType(messageId, date);
		
		PayTrans payTrans = response.getTxn();
		//TODO reference Id has to pass from the ReqPay
		PayTrans txn = DtoObjectUtil.constructPayTrans(payTrans.getId(), payTrans.getNote(), null, date, payTrans.getType(), propertyReader.getReferenceUrl(), false);
				
		RespType respType = new RespType();
		respType.setResult(CommonConstants.SUCCESS);
		respType.setReqMsgId(response.getHead().getMsgId());
		
		RespRegMob respRegMob = new RespRegMob();
		respRegMob.setHead(head);
		respRegMob.setTxn(txn);
		respRegMob.setResp(respType);
		
		TransactionThread transactionThread = new TransactionThread(respRegMob, ServiceNames.RESP_REG_MOB, upiClientService, null, null);
		new Thread(transactionThread).start();
		return upiClientService.requestToString(prepareAckData(ServiceNames.REQ_REG_MOB, response.getHead().getMsgId(), null));
	}

}
