/**
 * 
 */
package psp.upi.process.factory.impl;

import java.util.Date;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.upi.system_1_2.HeadType;
import org.upi.system_1_2.PayTrans;
import org.upi.system_1_2.ReqOtp;
import org.upi.system_1_2.RespOtp;
import org.upi.system_1_2.RespType;

import psp.common.PropertyReader;
import psp.constants.CommonConstants;
import psp.constants.ServiceNames;
import psp.dbservice.mgmt.PspMgmtService;
import psp.upi.process.factory.UpiCoreHandler;
import psp.upi.process.util.TransactionThread;
import psp.util.DtoObjectUtil;
import psp.util.PspClientTool;
import psp.util.upi.client.UpiClientService;

/**
 * @author prasadj
 *
 */
@Component("reqOtpHandler")
public class ReqOtpHandlerImpl extends UpiCoreHandler {

	@Autowired
	private PspMgmtService pspMgmtService;

	@Autowired
	private UpiClientService upiClientService;
	
	@Autowired
	private PropertyReader propertyReader;
	
	public ReqOtpHandlerImpl(){
	}
	
	@Override
	public String handleProcess(String upiData) {
		ReqOtp response = PspClientTool.convertUpiRequest(upiData, ReqOtp.class);
		
		Date date = new Date();
		String messageId = DtoObjectUtil.constructMessageId();
		HeadType head = DtoObjectUtil.constructHeadType(messageId, date);
		
		PayTrans payTrans = response.getTxn();
		//TODO reference Id has to pass from the ReqOtp
		PayTrans txn = DtoObjectUtil.constructPayTrans(payTrans.getId(), payTrans.getNote(), null, date, payTrans.getType(), propertyReader.getReferenceUrl(), false);
				
		RespType respType = new RespType();
		respType.setResult(CommonConstants.SUCCESS);
		respType.setReqMsgId(response.getHead().getMsgId());
		
		RespOtp respOtp = new RespOtp();
		respOtp.setHead(head);
		respOtp.setTxn(txn);
		respOtp.setResp(respType);
		
		TransactionThread transactionThread = new TransactionThread(respOtp, ServiceNames.RESP_OTP, upiClientService, null, null);
		new Thread(transactionThread).start();
		return upiClientService.requestToString(prepareAckData(ServiceNames.REQ_OTP, response.getHead().getMsgId(), null));
	}

}