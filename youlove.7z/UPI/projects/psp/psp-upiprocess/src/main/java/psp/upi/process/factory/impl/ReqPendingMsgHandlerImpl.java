/**
 * 
 */
package psp.upi.process.factory.impl;

import org.springframework.stereotype.Component;

import psp.common.exception.PspRuntimeException;
import psp.constants.StatusCode;
import psp.upi.process.factory.UpiCoreHandler;

/**
 * @author prasadj
 *
 */
@Component("reqPendingMsgHandler")
public class ReqPendingMsgHandlerImpl extends UpiCoreHandler {

	public ReqPendingMsgHandlerImpl(){
	}
	
	@Override
	public String handleProcess(String upiData) {
		throw new PspRuntimeException(StatusCode.UPI_REQUEST_NOT_SUPPORTING);
	}

}