/**
 * 
 */
package psp.upi.process.factory.impl;

import java.util.Date;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.upi.system_1_2.RespRegMob;

import psp.constants.ServiceNames;
import psp.constants.ServiceStatus;
import psp.dbservice.mgmt.PspMgmtService;
import psp.dbservice.model.GeneratePinUpiRequest;
import psp.upi.process.factory.UpiCoreHandler;
import psp.util.PspClientTool;
import psp.util.upi.client.UpiClientService;

/**
 * @author prasadj
 *
 */
@Component("respRegMobHandler")
public class RespRegMobHandlerImpl extends UpiCoreHandler {

	@Autowired
	private PspMgmtService pspMgmtService;
	
	@Autowired
	private UpiClientService upiClientService;

	public RespRegMobHandlerImpl(){
	}
	
	@Override
	public String handleProcess(String upiData) {
		RespRegMob response = PspClientTool.convertUpiRequest(upiData, RespRegMob.class);
		GeneratePinUpiRequest reqdetails = (GeneratePinUpiRequest) pspMgmtService.getUpiRequestByTxnId(response.getTxn().getId());
		if(null != reqdetails) {
			reqdetails.setStatus(ServiceStatus.RECEIVED.name());
			reqdetails.setResult(response.getResp().getResult());
			reqdetails.setErrMsg(response.getResp().getErrCode());
			reqdetails.setResponseTimeFromUpi(new Date());
			pspMgmtService.updateUpiRequest(reqdetails);
		}
		return upiClientService.requestToString(prepareAckData(ServiceNames.RESP_REG_MOB, response.getHead().getMsgId(), null));
	}

}