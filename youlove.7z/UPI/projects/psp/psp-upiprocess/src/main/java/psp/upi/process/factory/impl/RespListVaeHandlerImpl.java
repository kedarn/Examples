/**
 * 
 */
package psp.upi.process.factory.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.upi.system_1_2.RespListVae;

import psp.constants.ServiceNames;
import psp.upi.process.factory.UpiCoreHandler;
import psp.util.PspClientTool;
import psp.util.upi.client.UpiClientService;

/**
 * @author prasadj
 *
 */
@Component("respListVaeHandler")
public class RespListVaeHandlerImpl extends UpiCoreHandler {

	@Autowired
	private UpiClientService upiClientService;

	public RespListVaeHandlerImpl(){
	}
	
	@Override
	public String handleProcess(String upiData) {
		RespListVae response = PspClientTool.convertUpiRequest(upiData, RespListVae.class);
		return upiClientService.requestToString(prepareAckData(ServiceNames.RESP_LIST_VAE, response.getHead().getMsgId(), null));
	}

}