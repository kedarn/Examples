/**
 * 
 */
package psp.upi.process.factory.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.upi.system_1_2.RespListPsp;

import psp.constants.ServiceNames;
import psp.upi.process.factory.UpiCoreHandler;
import psp.util.PspClientTool;
import psp.util.upi.client.UpiClientService;

/**
 * @author prasadj
 *
 */
@Component("respListPspHandler")
public class RespListPspHandlerImpl extends UpiCoreHandler {

	@Autowired
	private UpiClientService upiClientService;

	public RespListPspHandlerImpl(){
	}
	
	@Override
	public String handleProcess(String upiData) {
		RespListPsp psp = PspClientTool.convertUpiRequest(upiData, RespListPsp.class);
		return upiClientService.requestToString(prepareAckData(ServiceNames.RESP_LIST_PSP, psp.getHead().getMsgId(), null));
	}

}