/**
 * 
 */
package psp.upi.process.factory.impl;

import java.util.Date;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.upi.system_1_2.RespSetCre;

import psp.constants.ServiceNames;
import psp.constants.ServiceStatus;
import psp.dbservice.mgmt.PspMgmtService;
import psp.dbservice.model.SetCredentialUpiRequest;
import psp.upi.process.factory.UpiCoreHandler;
import psp.util.PspClientTool;
import psp.util.upi.client.UpiClientService;

/**
 * @author prasadj
 *
 */
@Component("respSetCreHandler")
public class RespSetCreHandlerImpl extends UpiCoreHandler {

	@Autowired
	private PspMgmtService pspMgmtService;
	
	@Autowired
	private UpiClientService upiClientService;

	public RespSetCreHandlerImpl(){
	}
	
	@Override
	public String handleProcess(String upiData) {
		RespSetCre response = PspClientTool.convertUpiRequest(upiData, RespSetCre.class);
		SetCredentialUpiRequest req = (SetCredentialUpiRequest) pspMgmtService.getUpiRequestByTxnId(response.getTxn().getId());
		if(null != req) {
			req.setStatus(ServiceStatus.RECEIVED.name());
			req.setResult(response.getResp().getResult());
			req.setErrMsg(response.getResp().getErrCode());
			req.setResponseTimeFromUpi(new Date());
			pspMgmtService.updateUpiRequest(req);
		}
		return upiClientService.requestToString(prepareAckData(ServiceNames.RESP_SET_CRE, response.getHead().getMsgId(), null));
	}

}