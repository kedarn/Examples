/**
 * 
 */
package psp.upi.process.factory.impl;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.upi.system_1_2.HeadType;
import org.upi.system_1_2.PayConstant;
import org.upi.system_1_2.PayTrans;
import org.upi.system_1_2.PayeeType;
import org.upi.system_1_2.PayeesType;
import org.upi.system_1_2.PayerType;
import org.upi.system_1_2.ReqAuthDetails;
import org.upi.system_1_2.RespAuthDetails;
import org.upi.system_1_2.RespType;

import psp.common.PropertyReader;
import psp.constants.CommonConstants;
import psp.constants.NotificationStatus;
import psp.constants.ServiceNames;
import psp.constants.StatusCode;
import psp.dbservice.mgmt.PspMgmtService;
import psp.dbservice.model.AccountDetails;
import psp.dbservice.model.CustomerDetails;
import psp.dbservice.model.NotificationDetails;
import psp.dbservice.model.UpiMessagePacket;
import psp.upi.process.factory.UpiCoreHandler;
import psp.upi.process.util.TransactionThread;
import psp.upi.process.util.UpiProcessUtility;
import psp.util.DtoObjectUtil;
import psp.util.PspClientTool;
import psp.util.dto.AcDto;
import psp.util.gcm.GcmNotification;
import psp.util.upi.client.UpiClientService;
import psp.util.upiclient.UpiDataPreparationUtility;

import com.google.android.gcm.server.Result;

/**
 * @author prasadj
 *
 */
@Component("reqAuthDetailsHandler")
public class ReqAuthDetailsHandlerImpl extends UpiCoreHandler {

	@Autowired
	private PspMgmtService pspMgmtService;
	
	@Autowired
	private UpiClientService upiClientService;
	
	@Autowired
	private GcmNotification gcmNotification;
	
	@Autowired
	private PropertyReader propertyReader;
	
	public ReqAuthDetailsHandlerImpl(){
	}
	
	@Override
	public String handleProcess(String upiData) {
		ReqAuthDetails reqAuthDetails = PspClientTool.convertUpiRequest(upiData, ReqAuthDetails.class);
		PayTrans payTrans = reqAuthDetails.getTxn();
		List<StatusCode> scList = new ArrayList<>();
		if (payTrans.getType() == PayConstant.PAY) {
			PayeeType payeeType = reqAuthDetails.getPayees().getPayee().get(0);
			AccountDetails accountDetails = pspMgmtService.getAccountDetailsByVirtualAddr(payeeType.getAddr());
			if (accountDetails == null) {
				scList.add(StatusCode.ADDR_RESL_FAILED);
				prepareFailedPayRespnse( reqAuthDetails , StatusCode.ADDR_RESL_FAILED);
			}
			else {
				preparePayrequest(payeeType, accountDetails, reqAuthDetails);
			}
		}
		else if (payTrans.getType() == PayConstant.COLLECT) {
			AccountDetails payerAccountDetails = pspMgmtService.getAccountDetailsByVirtualAddr(reqAuthDetails.getPayer().getAddr());
			if (payerAccountDetails == null) {
				scList.add(StatusCode.ADDR_RESL_FAILED);
				prepareFailedPayRespnse( reqAuthDetails , StatusCode.ADDR_RESL_FAILED);
			}
			else {
				UpiMessagePacket upiMessagePacket = UpiProcessUtility.prepareUpiMessagePacket(upiData, reqAuthDetails.getTxn().getId());
				pspMgmtService.saveUpiMessagePacket(upiMessagePacket);
				NotificationDetails notificationDetails = prapareNotificationDetails(reqAuthDetails, payerAccountDetails);
				notificationDetails.setUpiMessagePacket(upiMessagePacket);
				pspMgmtService.saveNotificationDetails(notificationDetails);				
				Result result = gcmNotification.send(notificationDetails.getNotificationId(), notificationDetails.getNotificationtType(), notificationDetails.getNotificationMessage(), notificationDetails.getRegistrationId());
				if (result.getMessageId() == null) {
					throw new RuntimeException("*****Failed to send GCM Notification *********"); 
				} 
			}
		}
		return upiClientService.requestToString(prepareAckData(ServiceNames.REQ_AUTH_DETAILS, reqAuthDetails.getHead().getMsgId(), scList));
	}

	private NotificationDetails prapareNotificationDetails(ReqAuthDetails reqAuthDetails, AccountDetails payerAccountDetails){
		CustomerDetails userDetails = pspMgmtService.getUserDetails(payerAccountDetails.getCustomerDetails().getId());
		PayeeType pt = reqAuthDetails.getPayees().getPayee().get(0);
		String message = pt.getName() + " is requesting a payment of " + pt.getAmount().getValue() + " " + pt.getAmount().getCurr() 
				+ " for " + reqAuthDetails.getTxn().getNote();
		NotificationDetails notificationDetails = new NotificationDetails();
		notificationDetails.setGeneratedTime(new Date());
		notificationDetails.setNotificationId(UpiProcessUtility.constructNotificationId());
		notificationDetails.setNotificationMessage(message);
		notificationDetails.setRegistrationId(userDetails.getRnsMpaId());
		notificationDetails.setStatus(NotificationStatus.INITIATED.name());
		notificationDetails.setUserName(userDetails.getUserName());
		notificationDetails.setNotificationtType(PayConstant.COLLECT.name());
		return notificationDetails;
	}
	
	private void preparePayrequest(PayeeType payeeType, AccountDetails accountDetails, ReqAuthDetails reqAuthDetails){
		Date date = new Date();
		String messageId = DtoObjectUtil.constructMessageId();
		HeadType head = DtoObjectUtil.constructHeadType(messageId, date);
		PayTrans payTrans = reqAuthDetails.getTxn();
		//TODO reference Id has to pass from the reqAuthDetails
		PayTrans txn = DtoObjectUtil.constructPayTrans(payTrans.getId(), payTrans.getNote(), null, date, payTrans.getType(), propertyReader.getReferenceUrl(), false);

		AcDto acDto = new AcDto();
		acDto.setAddrType(accountDetails.getAddressType());
		acDto.setAcnum(accountDetails.getAccountNumber());
		acDto.setActype(accountDetails.getAccountType());
		acDto.setIfsc(accountDetails.getIfsc());
		payeeType.setAc(UpiDataPreparationUtility.convertAc(acDto));
		
		PayeesType payeesType = new PayeesType();
		List<PayeeType> payeeTypes = payeesType.getPayee();
		payeeTypes.add(payeeType);
		
		RespType respType = new RespType();
		respType.setReqMsgId(reqAuthDetails.getHead().getMsgId());
		respType.setResult(CommonConstants.SUCCESS);
		
		PayerType payerType = reqAuthDetails.getPayer();
		payeeType.setAmount(payerType.getAmount());
		
		RespAuthDetails respAuthDetails = new RespAuthDetails();
		respAuthDetails.setHead(head);
		respAuthDetails.setTxn(txn);
		respAuthDetails.setPayees(payeesType);
		respAuthDetails.setPayer(payerType);
		respAuthDetails.setResp(respType);
		
		TransactionThread transactionThread = new TransactionThread(respAuthDetails, ServiceNames.REQ_AUTH_DETAILS, upiClientService, null, null);
		new Thread(transactionThread).start();
	}

	private void prepareFailedPayRespnse( ReqAuthDetails reqAuthDetails, StatusCode statusCode){
		Date date = new Date();
		String messageId = DtoObjectUtil.constructMessageId();
		HeadType head = DtoObjectUtil.constructHeadType(messageId, date);
		PayTrans payTrans = reqAuthDetails.getTxn();
		//TODO reference Id has to pass from the reqAuthDetails
		PayTrans txn = DtoObjectUtil.constructPayTrans(payTrans.getId(), payTrans.getNote(), null, date, payTrans.getType(), propertyReader.getReferenceUrl(), false);

		RespType respType = new RespType();
		respType.setReqMsgId(reqAuthDetails.getHead().getMsgId());
		respType.setResult("FAILURE");
		respType.setErrCode(statusCode.getCode());
		
		RespAuthDetails respAuthDetails = new RespAuthDetails();
		respAuthDetails.setHead(head);
		respAuthDetails.setTxn(txn);
		respAuthDetails.setResp(respType);
		respAuthDetails.setPayees(reqAuthDetails.getPayees());
		respAuthDetails.setPayer(reqAuthDetails.getPayer());
		
		TransactionThread transactionThread = new TransactionThread(respAuthDetails, ServiceNames.REQ_AUTH_DETAILS, upiClientService, null, null);
		new Thread(transactionThread).start();
	}
	
}