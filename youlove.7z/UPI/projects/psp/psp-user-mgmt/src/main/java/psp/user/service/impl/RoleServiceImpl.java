/**
 * 
 */
package psp.user.service.impl;

import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import psp.dbservice.model.ActionItem;
import psp.dbservice.model.UserRole;
import psp.dto.ActionItemDto;
import psp.dto.RoleDto;
import psp.dto.RoleSearchDto;
import psp.user.dao.RoleDao;
import psp.user.service.RoleService;
import psp.user.util.UserManagementUtil;

/**
 * @author prasadj
 *
 */
@Component("roleService")
@Transactional (rollbackFor=Exception.class)
public class RoleServiceImpl implements RoleService {

	@Autowired
	private RoleDao roleDao;
	
	public RoleServiceImpl(){
	}

	@Override
	public List<RoleDto> getAdminRoles() {
		return UserManagementUtil.getUserRoleDtoList(roleDao.getAdminRoles());
	}

	@Override
	public RoleDto getRole(Long roleId) {
		return UserManagementUtil.getUserRoleDto(roleDao.getRole(roleId));
	}

	@Override
	public List<ActionItemDto> getAdminActionItems() {
		return roleDao.getAdminActionItems();
	}

	@Override
	public ActionItemDto getActionItem(Long id) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public RoleDto addRole(RoleDto role) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public RoleDto updateRole(RoleDto role) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<ActionItemDto> getActionItems(Integer category) {
		return roleDao.getActionItems(category);
	}

	@Override
	public RoleDto addRole(RoleDto dto, Long authId) {
		UserRole role = new UserRole(dto.getId(), dto.getName(), dto.getDescription());
		role.setCategory(dto.getCategory());
		List<ActionItemDto> actions = dto.getActions();
		Set<ActionItem> ais = new HashSet<ActionItem>();
		for(ActionItemDto a: actions){
			ais.add(roleDao.getActionItem(a.getId()));
		}
		role.setActions(ais);
		UserRole ur = roleDao.addRole(role);
		RoleDto newDto = UserManagementUtil.getUserRoleDto(ur);
		return newDto;
	}

	@Override
	public RoleDto updateRole(RoleDto role, Long authId) {
		UserRole model = roleDao.getRole(role.getId());
		model.setName(role.getName());
		model.setDescription(role.getDescription());
		List<ActionItemDto> actions = role.getActions();
		Set<ActionItem> ais = new HashSet<ActionItem>();
		for(ActionItemDto ad: actions){
			ActionItem ai = roleDao.getActionItem(ad.getId());
			if( ai.getCategory() == model.getCategory() ){
				ais.add(ai);
			}
			else {
				//TODO: need to throw exception
			}
		}
		model.setActions(ais);
		UserRole ur = roleDao.updateRole(model);
		RoleDto newDto = UserManagementUtil.getUserRoleDto(ur);
		return newDto;
	}

	@Override
	public List<RoleDto> getRoleByRoleName(String roleName) {
		return UserManagementUtil.getUserRoleDtoList(roleDao.getRoleByRoleName(roleName));
	}

	@Override
	public List<RoleDto> getRoles(RoleSearchDto dto) {
		return roleDao.getRoles(dto);
	}

}