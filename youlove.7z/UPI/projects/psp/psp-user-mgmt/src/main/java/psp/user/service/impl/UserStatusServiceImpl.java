/**
 * 
 */
package psp.user.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import psp.constants.AuthStatusCode;
import psp.constants.CategoryCode;
import psp.constants.UserStatus;
import psp.dbservice.dao.PspDao;
import psp.dbservice.model.Authentication;
import psp.dbservice.model.CustomerDetails;
import psp.dbservice.model.Employee;
import psp.dbservice.model.MerchantUser;
import psp.dbservice.model.UserRole;
import psp.user.dao.RoleDao;
import psp.user.dao.UserDao;
import psp.user.service.UserStatusService;

/**
 * @author varalakshmi
 *
 */
@Component("userStatusService")
@Transactional (rollbackFor=Exception.class)
public class UserStatusServiceImpl implements UserStatusService {

	@Autowired
	private PspDao pspDao;

	@Autowired
	private UserDao userDao;
	
	@Autowired
	private RoleDao roleDao;
	
	public UserStatusServiceImpl(){
	}

	@Override
	public void activateUser(Long id, CategoryCode category, Long authId) {
		Employee employee = null;
		MerchantUser merchant = null;
		Authentication authentication = null;
		CustomerDetails customer = null;
		if(CategoryCode.MERCHANT.equals(category)){
			merchant = userDao.getMerchantByMerchantId(id);
			authentication = pspDao.getAuthenticationById(merchant.getAuthId());
		}
		else if(CategoryCode.ADMIN.equals(category)){
			employee = userDao.getEmployeeByEmployeeId(id);
			authentication = pspDao.getAuthenticationById(employee.getAuthId());
		}
		else{
			customer = userDao.getCustomerByCustomerId(id);
			authentication = pspDao.getAuthenticationById(customer.getAuthId());
		}
		if(authentication.getUserStatus() != UserStatus.ACTIVE.getValue() ){
			authentication.setUserStatus(UserStatus.ACTIVE.getValue());
			authentication.setPwAttempts(0);
			pspDao.updateAuthentication(authentication);
			//TODO audit log need to update
		}
		else {
			throw new RuntimeException("User already activated"); //TODO Need to define constant
		}
		
	}
	

	@Override
	public void suspendUser(Long id, CategoryCode category, Long authId) {
		Employee employee = null;
		MerchantUser merchant = null;
		Authentication authentication = null;
		CustomerDetails customer = null;
		if(CategoryCode.MERCHANT.equals(category)){
			merchant = userDao.getMerchantByMerchantId(id);
			authentication = pspDao.getAuthenticationById(merchant.getAuthId());
		}
		else if(CategoryCode.ADMIN.equals(category)){
			employee = userDao.getEmployeeByEmployeeId(id);
			authentication = pspDao.getAuthenticationById(employee.getAuthId());
		}
		else{
			customer = userDao.getCustomerByCustomerId(id);
			authentication = pspDao.getAuthenticationById(customer.getAuthId());
		}
		if(authentication.getUserStatus() != UserStatus.SUSPEND.getValue() ){
			authentication.setUserStatus(UserStatus.SUSPEND.getValue());
			authentication.setPwAttempts(0); //TODO Need to discuss
			pspDao.updateAuthentication(authentication);
			//TODO audit log need to update
		}
		else {
			throw new RuntimeException("User already suspended"); //TODO Need to define constant
		}
		
	}

	@Override
	public void resetUserPassword(Long id, CategoryCode category, Long authId) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public Boolean assignAdminRole(Long userId, Long roleId, Long authId) {
		Employee emp = userDao.getEmployeeByEmployeeId(userId);
		Authentication auth = pspDao.getAuthenticationById(emp.getAuthId());
		UserRole role = roleDao.getRole(roleId);
		if(role.getCategory() == auth.getCategory()){
			auth.setRoleId(roleId);
		}
		else {
			return false;
		}
		pspDao.updateAuthentication(auth);
		
		//TODO need to prepare audit log
		return true;
	}

	@Override
	public Boolean assignMerchantRole(Long userId, Long roleId, Long authId) {
		MerchantUser merchant = userDao.getMerchantByMerchantId(userId);
		Authentication auth = pspDao.getAuthenticationById(merchant.getAuthId());
		UserRole role = roleDao.getRole(roleId);
		if(role.getCategory() == auth.getCategory()){
			auth.setRoleId(roleId);
		}
		else {
			return false;
		}
		pspDao.updateAuthentication(auth);
		
		//TODO need to prepare audit log
		return true;
	}
	
}