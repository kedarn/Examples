/**
 * 
 */
package psp.constants;


/**
 * @author hemanthk
 *
 */
public enum BankCodes {
	
	
	AXIS(1,"AXIS"),
	ICICI(2,"ICICI");
	
	
	private final int value;
	
	private final String name;
	
	private BankCodes(int value, String name) {
		this.value = value;
		this.name = name;
	}

	public int getValue() {
		return value;
	}
	
	public String getName() {
		return name;
	}

	public static BankCodes getStatus(int value){
		if(AXIS.value == value){
			return AXIS;
		}
		else if(AXIS.value == value){
			return AXIS;
		}
		else {
			return null;
		}
	}
}
