/**
 * 
 */
package psp.user.service.impl;

import java.text.MessageFormat;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import psp.common.PropertyReader;
import psp.constants.AuditLogConstants;
import psp.constants.AuthStatusCode;
import psp.constants.CategoryCode;
import psp.constants.CommonConstants;
import psp.constants.DateUtil;
import psp.constants.PortalModule;
import psp.constants.PortalOperations;
import psp.constants.UserStatus;
import psp.dbservice.dao.PspDao;
import psp.dbservice.model.Address;
import psp.dbservice.model.Authentication;
import psp.dbservice.model.CustomerDetails;
import psp.dbservice.model.DeviceDetails;
import psp.dbservice.model.Employee;
import psp.dbservice.model.MerchantAccount;
import psp.dbservice.model.MerchantUser;
import psp.dbservice.model.UserRole;
import psp.dbservice.util.DbServiceUtil;
import psp.dto.AuditLogDto;
import psp.dto.MerchantDto;
import psp.dto.UserProfileDto;
import psp.dto.UserSearchDto;
import psp.notification.model.EmailMessage;
import psp.notification.service.EmailService;
import psp.user.dao.CommonDao;
import psp.user.dao.RoleDao;
import psp.user.dao.UserDao;
import psp.user.service.CommonService;
import psp.user.service.UserService;
import psp.user.util.EmailMessageTemplates;
import psp.user.util.UserAuditLogUpdateUtility;
import psp.user.util.UserManagementUtil;
/**
 * @author prasadj
 *
 */
@Component("userService")
@Transactional (rollbackFor=Exception.class)
public class UserServiceImpl implements UserService, CommonConstants {

	@Autowired
	private PspDao pspDao;

	@Autowired
	private UserDao userDao;

	@Autowired
	private RoleDao roleDao;
	
	@Autowired
	private CommonDao commonDao;
	
	@Autowired
	private PropertyReader propertyReader;
	
	@Autowired
	private EmailService emailService;
	
	@Autowired
	private CommonService commonService;
	
	public UserServiceImpl(){
	}

	@Override
	public UserProfileDto getCustomer(Long customerId) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public UserProfileDto getCustomer(String userName) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public CustomerDetails getCustomerByAuthId(Long authId) {
		CustomerDetails customerDto = userDao.getCustomerDetailsbyauthId(authId);
		return customerDto;
	}

	@Override
	public UserProfileDto updateCustomer(UserProfileDto customerDto, Long authId) {
		CustomerDetails customer = userDao.getCustomerByCustomerId(customerDto.getId());
		Address address = null;
		if(customer.getAddressId() != null){
			address = commonDao.getAddressById(customer.getAddressId());
			UserManagementUtil.updateUserAddressModel(address, customerDto);
			commonDao.updateAddress(address);
		}else{		
			if (customerDto.getLine1() != null && !"".equals(customerDto.getLine1())) {
				address = UserManagementUtil.createUserAddressModel(customerDto);
				commonDao.saveAddress(address);
			}
		}
		if(address != null){
			UserManagementUtil.updateCustomerModel(customer, customerDto, address.getId());
		}else{
			UserManagementUtil.updateCustomerModel(customer, customerDto, null);
		}
		userDao.updateCustomer(customer);
		UserProfileDto newDto = getCustomerDetailsByCustomerId(customer.getId());
		return newDto;
	}
	
	
	@Override
	public String getFullNameByCustomerId(Long customerId) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<UserProfileDto> getCustomerProfileSummaryList(UserSearchDto customerSearchDto) {
		return userDao.getCustomerProfileSummaryList(customerSearchDto);
	}

	@Override
	public MerchantDto addMerchant(MerchantDto merchantDto) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public MerchantDto getMerchant(Long merchantId) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public MerchantDto getMerchant(String userName) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public MerchantDto updateMerchant(MerchantDto merchantDto) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getFullNameByMerchantId(Long merchantId) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public UserProfileDto getMerchantByAuthId(Long authId) {
		MerchantUser merchant = userDao.getMerchantByAuthId(authId);
		return convertMerchantModelsToDto(merchant);
	}

	@Override
	public List<UserProfileDto> getEmployeeProfileSummaryList(UserSearchDto employeeSearchDto) {
		return userDao.getEmployeeProfileSummaryList(employeeSearchDto);
	}

	@Override
	public UserProfileDto addEmployee(UserProfileDto employeeDto) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public UserProfileDto getEmployee(Long employeeId) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public UserProfileDto getEmployee(String userName) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public UserProfileDto updateEmployee(UserProfileDto employeeDto) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getFullNameByEmployeeId(Long employeeId) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public UserProfileDto getEmployeeByAuthId(Long authId) {
		Employee employee = userDao.getEmployeeByAuthId(authId);
		return convertEmpModelsToDto(employee);
	}

	@Override
	public List<UserProfileDto> getMerchantProfileSummaryList(UserSearchDto merchantSearchDto) {
		return userDao.getMerchantProfileSummaryList(merchantSearchDto);
	}

	@Override
	public UserProfileDto getEmployeeDetailsByEmployeeId(Long employeeId) {
		Employee employee =  userDao.getEmployeeByEmployeeId(employeeId);
		return convertEmpModelsToDto(employee);
	}
	
	private UserProfileDto convertEmpModelsToDto(Employee employee) {
		UserProfileDto dto = new UserProfileDto();

		Authentication authentication = pspDao.getAuthenticationById(employee.getAuthId());
		if(authentication.getRoleId() != null){
			UserRole role = roleDao.getRole(authentication.getRoleId());
			if(role != null){
				dto.setRoleName(role.getName());
			}
		}
		Address address = commonDao.getAddressById(employee.getAddressId());
		dto.setId(employee.getId());
		dto.setLoginName(authentication.getUserName());
		dto.setAuthId(authentication.getId());
		dto.setFirstName(employee.getFirstName());
		dto.setMiddleName(employee.getMiddleName());
		dto.setLastName(employee.getLastName());
		dto.setEmail(employee.getEmail());
		dto.setDateOfBirth(employee.getDateOfBirth());
		dto.setPhoneNumber(employee.getPhoneNumber());
		dto.setAltPhoneNumber(employee.getAltPhoneNumber());
		dto.setAddressId(employee.getAddressId());
		dto.setLine1(address.getLine1());
		dto.setLine2(address.getLine2());
		dto.setPincode(address.getPinCode());
		dto.setDateOfBirthStr(DateUtil.convertDateToString(employee.getDateOfBirth()));
		dto.setCountryName(address.getCountry());
		dto.setDistrictName(address.getDistrict());
		dto.setStateName(address.getState());
		dto.setUserStatus(authentication.getUserStatus());
		if(authentication.getUserStatus() != null){
			dto.setUserStatusStr(UserStatus.getUserStatus(authentication.getUserStatus()).getName());
		}
		dto.setPwdStatus(authentication.getPwdStatus());
		if(authentication.getPwdStatus() != null){
			dto.setPwdStatusStr(AuthStatusCode.getStatus(authentication.getPwdStatus()).getName());
		}
		return dto;
	}

	@Override
	public UserProfileDto addEmployee(UserProfileDto employeeDto, Long authId) {
		employeeDto.setCategory(CategoryCode.ADMIN.getValue());
		Authentication authentication = UserManagementUtil.createEmployeeAuthenticationModel(employeeDto);
		pspDao.saveAuthentication(authentication);
		Address address = UserManagementUtil.createUserAddressModel(employeeDto);
		commonDao.saveAddress(address);
		Employee employee = UserManagementUtil.createEmployeeModel(employeeDto, authentication.getId(), address.getId());
	    userDao.saveEmployee(employee);
	    
	    String email = employee.getEmail();
		String url = propertyReader.getChangePwdUrl();
		String fullName = userDao.getFullNameByAuthId(authentication.getId());
		String subject = "New Employee Activation Link";
		String url_link = url + EMPLOYEE + NEW_EMPLOYEE + QUESTION_MARK + CODE + EQUAL_SYMBOL + authentication.getNewUserCode();
		String messageBody = MessageFormat.format(EmailMessageTemplates.NEW_USER_ACTIVATION_CONTENT, fullName, url_link);
		EmailMessage emailMessage = new EmailMessage(email, messageBody, subject);
		emailService.sendEmail(emailMessage);
		UserProfileDto newDto = getEmployeeByAuthId(employee.getAuthId());
		
		AuditLogDto auditLogDto = new AuditLogDto();
		auditLogDto.setAuthId(authId);
		auditLogDto.setRecordId(authentication.getId());
		auditLogDto.setOperation(PortalOperations.CREATE);
		auditLogDto.setModule(PortalModule.EMPLOYEE_MANAGEMNET.getValue());
		auditLogDto.setInfo(MessageFormat.format(AuditLogConstants.EMPLOYEE_CREATION, fullName));
		commonService.addAuditLog(auditLogDto);
		
		return newDto;
	}

	@Override
	public UserProfileDto updateEmployee(UserProfileDto employeeDto, Long authId) {
		Employee employee = userDao.getEmployeeByEmployeeId(employeeDto.getId());
		Address orgAddr = commonDao.getAddressById(employee.getAddressId());
		UserProfileDto oldDto = getEmployeeByAuthId(employee.getAuthId());
		UserManagementUtil.updateUserAddressModel(orgAddr, employeeDto);
		commonDao.updateAddress(orgAddr);
		UserManagementUtil.updateEmployeeModel(employee, employeeDto);
		userDao.updateEmployee(employee);
		UserProfileDto newDto = getEmployeeByAuthId(employee.getAuthId());
		
		AuditLogDto auditLogDto = new AuditLogDto();
		auditLogDto.setAuthId(authId);
		auditLogDto.setRecordId(employee.getId());
		auditLogDto.setOperation(PortalOperations.UPDATE);
		auditLogDto.setModule(PortalModule.EMPLOYEE_MANAGEMNET.getValue());
		StringBuilder sb = new StringBuilder();
		sb.append(MessageFormat.format(AuditLogConstants.EMPLOYEE_UPDATE, userDao.getFullNameByAuthId(employee.getAuthId())));
		UserAuditLogUpdateUtility.updateProfiles(oldDto, newDto, sb);
		auditLogDto.setInfo(sb.toString());
		commonService.addAuditLog(auditLogDto);
		return newDto;
	}

	@Override
	public UserProfileDto addMerchant(UserProfileDto merchantDto, Long authId) {
		Authentication authentication = UserManagementUtil.createMerchantAuthenticationModel(merchantDto);
		UserRole role = roleDao.getMerchantRole();
		authentication.setRoleId(role.getId());
		pspDao.saveAuthentication(authentication);
		Address address = UserManagementUtil.createMerchantAddressModel(merchantDto);
		commonDao.saveAddress(address);
		MerchantUser merchant = UserManagementUtil.createMerchantModel(merchantDto, authentication.getId(), address.getId());
	    userDao.saveMerchant(merchant);
	    
	    String email = merchant.getEmail();
		String url = propertyReader.getChangePwdUrl();
		String fullName = userDao.getFullNameByAuthId(authentication.getId());
		String subject = EmailMessageTemplates.NEW_MERCHANT_ACTIVATION_SUBJECT;
		String url_link = url + MERCHANT + NEW_MERCHANT + QUESTION_MARK + CODE + EQUAL_SYMBOL + authentication.getNewUserCode();
		String messageBody = MessageFormat.format(EmailMessageTemplates.NEW_USER_ACTIVATION_CONTENT, fullName, url_link);
		EmailMessage emailMessage = new EmailMessage(email, messageBody, subject);
		emailService.sendEmail(emailMessage);
		UserProfileDto newDto = getMerchantByAuthId(merchant.getAuthId());
	    System.out.println(url_link);
		
	    AuditLogDto auditLogDto = new AuditLogDto();
		auditLogDto.setAuthId(authId);
		auditLogDto.setRecordId(authentication.getId());
		auditLogDto.setOperation(PortalOperations.CREATE);
		auditLogDto.setModule(PortalModule.MERCHANT_MANAGEMNET.getValue());
		auditLogDto.setInfo(MessageFormat.format(AuditLogConstants.MERCHANT_CREATION, fullName));
		commonService.addAuditLog(auditLogDto);
		
		return newDto;
	}
	
	private UserProfileDto convertMerchantModelsToDto(MerchantUser merchant) {
		UserProfileDto dto = new UserProfileDto();

		Authentication authentication = pspDao.getAuthenticationById(merchant.getAuthId());
		if(authentication.getRoleId() != null){
			UserRole role = roleDao.getRole(authentication.getRoleId());
			if(role != null){
				dto.setRoleName(role.getName());
			}
		}
		Address address = commonDao.getAddressById(merchant.getAddressId());
		dto.setId(merchant.getId());
		dto.setLoginName(authentication.getUserName());
		dto.setAuthId(authentication.getId());
		dto.setFirstName(merchant.getFirstName());
		dto.setMiddleName(merchant.getMiddleName());
		dto.setLastName(merchant.getLastName());
		dto.setEmail(merchant.getEmail());
		dto.setPhoneNumber(merchant.getPhoneNumber());
		dto.setAddressId(merchant.getAddressId());
		dto.setLine1(address.getLine1());
		dto.setLine2(address.getLine2());
		dto.setPincode(address.getPinCode());
		dto.setCountryName(address.getCountry());
		dto.setDistrictName(address.getDistrict());
		dto.setStateName(address.getState());
		dto.setEstablishDate(merchant.getEstablishDate());
		dto.setEstablishDateStr(DateUtil.convertDateToString(merchant.getEstablishDate()));
		dto.setRegistrationDate(merchant.getRegistrationDate());
		dto.setName(merchant.getName());
		dto.setPwdStatus(authentication.getPwdStatus());
		if(authentication.getPwdStatus() != null){
			dto.setPwdStatusStr(AuthStatusCode.getStatus(authentication.getPwdStatus()).getName());
		}
		dto.setUserStatus(authentication.getUserStatus());
		if(authentication.getUserStatus() != null){
			dto.setUserStatusStr(UserStatus.getUserStatus(authentication.getUserStatus()).getName());
		}
		return dto;
	}

	@Override
	public UserProfileDto getMerchantDetailsByMerchantId(Long merchantId) {
		MerchantUser merchant =  userDao.getMerchantByMerchantId(merchantId);
		return convertMerchantModelsToDto(merchant);
	}
	
	

	@Override
	public UserProfileDto updateMerchant(UserProfileDto merchantDto, Long authId) {
		MerchantUser merchant = userDao.getMerchantByMerchantId(merchantDto.getId());
		Address orgAddr = commonDao.getAddressById(merchant.getAddressId());
		UserProfileDto oldDto = getMerchantByAuthId(merchant.getAuthId());
		UserManagementUtil.updateMerchantAddressModel(orgAddr, merchantDto);
		commonDao.updateAddress(orgAddr);
		UserManagementUtil.updateMerchantModel(merchant, merchantDto);
		userDao.updateMerchant(merchant);
		UserProfileDto newDto = getMerchantByAuthId(merchant.getAuthId());
		
		AuditLogDto auditLogDto = new AuditLogDto();
		auditLogDto.setAuthId(authId);
		auditLogDto.setRecordId(merchant.getId());
		auditLogDto.setOperation(PortalOperations.UPDATE);
		auditLogDto.setModule(PortalModule.MERCHANT_MANAGEMNET.getValue());
		StringBuilder sb = new StringBuilder();
		sb.append(MessageFormat.format(AuditLogConstants.MERCHANT_UPDATE, userDao.getFullNameByAuthId(merchant.getAuthId())));
		UserAuditLogUpdateUtility.updateProfiles(oldDto, newDto, sb);
		auditLogDto.setInfo(sb.toString());
		commonService.addAuditLog(auditLogDto);
		return newDto;
	}

	@Override
	public void saveMerchantAccount(MerchantAccount merchantAccount) {
		userDao.saveMerchantAccount(merchantAccount);
	}

	@Override
	public MerchantAccount updateMerchantAccount(MerchantAccount merchant) {
		userDao.updateMerchantAccount(merchant);
		return userDao.getMerchantAccountByMerchantId(merchant.getMerchantId());
	}
	
	@Override
	public MerchantAccount getMerchantAccountByMerchantId(Long merchantId){
		return userDao.getMerchantAccountByMerchantId(merchantId);
	}

	@Override
	public UserProfileDto getuserDetailsbyauthID(Long authID){
		CustomerDetails customer = userDao.getCustomerDetailsbyauthId(authID);
		return convertCustomerModelsToDto(customer);
	}
	
	@Override
	public boolean resetUserPassword(Long authID) {
		boolean respBool = false;
		try{
			CustomerDetails customerDto = userDao.getCustomerDetailsbyauthId(authID);
			Authentication authentication = pspDao.getAuthenticationById(authID);
			String email = customerDto.getEmail();
			String url = propertyReader.getChangePwdUrl();
			String fullName = userDao.getFullNameByAuthId(authID);
			String subject = "Reset password Activation Link";
			String activationCode =  UserManagementUtil.generateNewUserCode(authentication.getUserName());
			String url_link = url + CUSTOMER + RESET_CUSTOMER_PASSWORD + QUESTION_MARK + CODE + EQUAL_SYMBOL + activationCode;
			System.out.println("Customer password reactivation link :: " + url_link);
			String messageBody = MessageFormat.format(EmailMessageTemplates.NEW_USER_ACTIVATION_CONTENT, fullName, url_link);
			EmailMessage emailMessage = new EmailMessage(email, messageBody, subject);
			emailService.sendEmail(emailMessage);
			authentication.setPwAttempts(0);
			authentication.setNewUserCode(activationCode);
			pspDao.updateAuthentication(authentication);
			respBool = true;
		}
		catch(Exception ex){
			respBool = false;
		}
		
		return true;
	}

	@Override
	public UserProfileDto getUserProfile(Long id, Integer category) {
		if(CategoryCode.ADMIN.getValue() == category || CategoryCode.SUPER_ADMIN.getValue() == category) {
			UserProfileDto employee = getEmployeeDetailsByEmployeeId(id);
			return employee;
			/*if(null != employee) {
				return UserManagementUtil.prepareUserProfileDto(employee);	
			}*/
		}
		else if(CategoryCode.MERCHANT.getValue() == category) {
			UserProfileDto merchant = getMerchantDetailsByMerchantId(id);
			return merchant;
			/*if(null != merchant) {
				return UserManagementUtil.prepareUserProfileDto(merchant);	
			}*/
		}
		else if(CategoryCode.CUSTOMER.getValue() == category) {
			UserProfileDto customer = getCustomerDetailsByCustomerId(id);
			return customer;
			/*if(null != customer) {
				return UserManagementUtil.prepareUserProfileDto(customer);	
			}*/
		}
		return null;
	}

	@Override
	public UserProfileDto getCustomerDetailsByCustomerId(Long id) {
		CustomerDetails customer =  pspDao.getCustomerDetails(id);
		DeviceDetails deviceDetails = pspDao.getDeviceDetailsByUserId(customer.getId());
		Authentication authentication = pspDao.getAuthenticationById(customer.getAuthId());
		UserProfileDto userProfileDto =  DbServiceUtil.prepareUserProfileDto(customer, deviceDetails, authentication);
		Address address = null;
		if(customer.getAddressId() != null){
			address = commonDao.getAddressById(customer.getAddressId());
		}
		if(address != null){
			userProfileDto.setLine1(address.getLine1());
			userProfileDto.setLine2(address.getLine2());
			userProfileDto.setDistrictName(address.getDistrict());
			userProfileDto.setStateName(address.getState());
			userProfileDto.setCountryName(address.getCountry());
			userProfileDto.setPincode(address.getPinCode());
		}
		return userProfileDto;
	}
	
	
	private UserProfileDto convertCustomerModelsToDto(CustomerDetails customer) {
		UserProfileDto dto = new UserProfileDto();
		//Address address = commonDao.getAddressById(customer.getAddressId());
		dto.setId(customer.getId());
		dto.setLoginName(customer.getUserName());
		dto.setAuthId(customer.getId());
		dto.setFirstName(customer.getFirstName());
		dto.setMiddleName(customer.getMiddleName());
		dto.setLastName(customer.getLastName());
		dto.setEmail(customer.getEmail());
		dto.setDateOfBirth(customer.getDateOfBirth());
		dto.setPhoneNumber(customer.getMobileNumber());
		dto.setAadhaarNumber(customer.getAadhaarNumber());
		dto.setRegistrationDate(customer.getCreatedDate());
		//dto.setAddressId(customer.getAddressId());
		//dto.setLine1(customer.getLine1());
		//dto.setLine2(customer.getLine2());
		//dto.setPincode(customer.getPinCode());
		dto.setDateOfBirthStr(DateUtil.convertDateToString(customer.getDateOfBirth()));
		//dto.setCountryName(customer.getCountry());
		//dto.setDistrictName(customer.getDistrict());
		//dto.setStateName(customer.getState());
		return dto;
	}
	
	
	private CustomerDetails convertDtoToCustomerModel(UserProfileDto dto, UserProfileDto oldDto) {
		CustomerDetails customer = new CustomerDetails();
		//Address address = commonDao.getAddressById(customer.getAddressId());
		customer.setId(dto.getId());
		customer.setUserName(oldDto.getLoginName());
		customer.setAuthId(dto.getId());
		customer.setFirstName(dto.getFirstName());
		customer.setMiddleName(dto.getMiddleName());
		customer.setLastName(dto.getLastName());
		customer.setEmail(dto.getEmail());
		customer.setDateOfBirth(DateUtil.convertStringToDate(dto.getDateOfBirthStr()));
		customer.setMobileNumber(oldDto.getPhoneNumber());
		customer.setAadhaarNumber(dto.getAadhaarNumber());
		customer.setCreatedDate(oldDto.getRegistrationDate());
		//dto.setAddressId(customer.getAddressId());
		//dto.setLine1(customer.getLine1());
		//dto.setLine2(customer.getLine2());
		//dto.setPincode(customer.getPinCode());
		//customer.setDateOfBirthStr(DateUtil.convertDateToString(dto.getDateOfBirth()));
		//dto.setCountryName(customer.getCountry());
		//dto.setDistrictName(customer.getDistrict());
		//dto.setStateName(customer.getState());
		return customer;
	}

}