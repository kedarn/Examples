/**
 * 
 */
package psp.dto;

import java.io.Serializable;
import java.util.Date;
import psp.constants.LoginCode;
import psp.user.util.UserDateUtil;

/**
 * @author prasadj
 *
 */
public class LoginDto implements Serializable {

	private static final long serialVersionUID = 1L;

	private String userName;
	
	private String password;
	
	private Integer category;
	
	private Date lastLoginTime;
	
	private String lastLoginTimeStr;
	
	private Long authId;
	
	private RoleDto role;
	
	private Integer status;
	
	private LoginCode loginStatus;
	
	private String fullName;
	
	private Long merchantId;
	
	private String merchantName;
	
	private String customerName;
	
	private String employeeName;
	
	private Long userId;  // It
	
	public LoginDto(){
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public Integer getCategory() {
		return category;
	}

	public void setCategory(Integer category) {
		this.category = category;
	}

	public Date getLastLoginTime() {
		return lastLoginTime;
	}

	public void setLastLoginTime(Date lastLoginTime) {
		this.lastLoginTime = lastLoginTime;
		if(lastLoginTime != null){
			lastLoginTimeStr = UserDateUtil.convertDateToTimeString(lastLoginTime);
		}
		else {
			lastLoginTimeStr = "";
		}
	}

	public String getLastLoginTimeStr() {
		return lastLoginTimeStr;
	}

	public void setLastLoginTimeStr(String lastLoginTimeStr) {
		this.lastLoginTimeStr = lastLoginTimeStr;
	}

	public Long getAuthId() {
		return authId;
	}

	public void setAuthId(Long authId) {
		this.authId = authId;
	}

	public RoleDto getRole() {
		return role;
	}

	public void setRole(RoleDto role) {
		this.role = role;
	}

	public LoginCode getLoginStatus() {
		return loginStatus;
	}

	public void setLoginStatus(LoginCode loginStatus) {
		this.loginStatus = loginStatus;
	}

	public Integer getStatus() {
		return status;
	}

	public void setStatus(Integer status) {
		this.status = status;
	}

	public String getFullName() {
		return fullName;
	}

	public void setFullName(String fullName) {
		this.fullName = fullName;
	}

	public Long getMerchantId() {
		return merchantId;
	}

	public void setMerchantId(Long merchantId) {
		this.merchantId = merchantId;
	}

	public String getMerchantName() {
		return merchantName;
	}

	public void setMerchantName(String merchantName) {
		this.merchantName = merchantName;
	}

	public String getCustomerName() {
		return customerName;
	}

	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}

	public String getEmployeeName() {
		return employeeName;
	}

	public void setEmployeeName(String employeeName) {
		this.employeeName = employeeName;
	}

	public Long getUserId() {
		return userId;
	}

	public void setUserId(Long userId) {
		this.userId = userId;
	}
	
}
