/**
 * 
 */
package psp.constants;

/**
 * @author hemanthk
 *
 */
public enum NewUserPwChangeStatus {

	SUCCESS,
	FAILED,
	ALREADY_ACTIVE;
}
