package psp.constants;

/**
 * The Interface UserConstants.
 */
public interface UserConstants {
	
	Integer DEFAULT_ATTEMPTS = 0;
	
	Integer MAX_PWD_ATTEMPTS = 3;
	
	//UserStatusCode DEFAULT_STATUS = UserStatusCode.NEW_USER;
	
	String CODE_MISMATCHED = "code is mismatched"; 
	
	String MALE = "Male";
	
	String FEMALE = "Female";
	
	String C_TYPR_GROUP= "Group";
	
	String C_TYPR_INDIVIDUAL= "Individual";
	
	String F = "F";
	
	String G = "G";
	
	String USER_ALREADY_ACTIVATED = "user.already.activated";
	
	String USER_ALREADY_BLOCKED = "user.already.blocked";
}
