/**
 * 
 */
package psp.user.service.impl;

import java.text.MessageFormat;
import java.util.Date;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import psp.common.PropertyReader;
import psp.constants.AuditLogConstants;
import psp.constants.AuthStatusCode;
import psp.constants.CategoryCode;
import psp.constants.CommonConstants;
import psp.constants.ForgotPasswordCode;
import psp.constants.LoginCode;
import psp.constants.NewUserPwChangeStatus;
import psp.constants.PortalModule;
import psp.constants.PortalOperations;
import psp.constants.ResendNotificationCode;
import psp.constants.UserConstants;
import psp.constants.UserStatus;
import psp.dbservice.dao.PspDao;
import psp.dbservice.mgmt.PspMgmtService;
import psp.dbservice.model.Authentication;
import psp.dbservice.model.CustomerDetails;
import psp.dbservice.model.Employee;
import psp.dbservice.model.MerchantUser;
import psp.dbservice.model.PasswordHistory;
import psp.dto.AuditLogDto;
import psp.dto.AuthenticationDto;
import psp.dto.LoginDto;
import psp.dto.NewUserDto;
import psp.dto.RoleDto;
import psp.notification.model.EmailMessage;
import psp.notification.service.EmailService;
import psp.user.dao.UserDao;
import psp.user.service.CommonService;
import psp.user.service.LoginService;
import psp.user.service.RoleService;
import psp.user.util.AutoUnlockUserTimerTask;
import psp.user.util.EmailMessageTemplates;
import psp.user.util.PasswordEncryptor;
import psp.user.util.UserManagementUtil;

/**
 * @author prasadj
 *
 */
@Component("loginService")
@Transactional (rollbackFor=Exception.class)
public class LoginServiceImpl implements LoginService,CommonConstants {
	
	private static final Logger LOGGER = Logger.getLogger(LoginServiceImpl.class.getName());

	@Autowired
	private RoleService roleService;

	@Autowired
	private UserDao userDao;

	@Autowired
	private PspDao pspDao;
	
	@Autowired
	private PropertyReader propertyReader;
	
	@Autowired
	private EmailService emailService;
	
	@Autowired
	private CommonService commonService;
	
	@Autowired
	private PspMgmtService pspMgmtService;
	
	public LoginServiceImpl(){
	}
	
	
	@Override
	public LoginDto login(String loginId, String password, Integer categoryId) {
		LoginDto loginDto = new LoginDto();
		Authentication authentication = pspDao.getAuthenticationByLoginName(loginId);
		boolean flag=false;
		if(null != authentication && authentication.getCategory() != null) {
			if(authentication.getCategory().intValue() == categoryId.intValue() ) {
				if(CategoryCode.ADMIN.getValue() == categoryId || CategoryCode.MERCHANT.getValue() == categoryId) {
					if(UserStatus.ACTIVE.getValue() != authentication.getUserStatus().intValue()) {
						loginDto.setLoginStatus(LoginCode.IN_ACTIVE);	
						return loginDto;
					}
				}
				else if(CategoryCode.CUSTOMER.getValue() == categoryId) {
					if(UserStatus.DELETE.getValue() == authentication.getUserStatus().intValue()
							|| UserStatus.SUSPEND.getValue() == authentication.getUserStatus().intValue()) {
						loginDto.setLoginStatus(LoginCode.IN_ACTIVE);	
						return loginDto;
					}
				}
				if(authentication.getPwdStatus() == AuthStatusCode.ACTIVE.getValue()){
					if(authentication.getPwAttempts() < UserConstants.MAX_PWD_ATTEMPTS){
						flag = PasswordEncryptor.checkPassword(password, authentication.getPassword());
						if(flag){
							loginDto.setAuthId(authentication.getId());
							
								loginDto.setLoginStatus(LoginCode.LOGIN_SUCCESS);
								loginDto.setCategory(authentication.getCategory());
								loginDto.setLastLoginTime(authentication.getLastLoginTime());
								loginDto.setStatus(authentication.getPwdStatus());
								loginDto.setUserName(authentication.getUserName());
								loginDto.setFullName(userDao.getFullNameByAuthId(authentication.getId()));
								RoleDto roleDto = roleService.getRole(authentication.getRoleId());
								loginDto.setRole(roleDto);
							if(CategoryCode.MERCHANT.getValue() == categoryId.intValue()) {
								MerchantUser merchantUser =userDao.getMerchantByAuthId(authentication.getId());
									loginDto.setMerchantId(merchantUser.getId());
									loginDto.setMerchantName(merchantUser.getName());
									loginDto.setUserId(merchantUser.getId());
							}else if (CategoryCode.ADMIN.getValue() == categoryId.intValue()  || CategoryCode.SUPER_ADMIN.getValue() == categoryId.intValue()){
								Employee employee = userDao.getEmployeeByAuthId(authentication.getId());
								loginDto.setUserId(employee.getId());
							}else{
								CustomerDetails userProfileDto = userDao.getCustomerDetailsbyauthId(authentication.getId());
								loginDto.setUserId(userProfileDto.getId());
							}	
							authentication.setPwAttempts(0);
							Date date = new Date();
							authentication.setLastLoginTime(date);
							pspDao.updateAuthentication(authentication);
							loginDto.setLoginStatus(LoginCode.LOGIN_SUCCESS);
							
							AuditLogDto auditLogDto = new AuditLogDto();
							auditLogDto.setAuthId(authentication.getId());
							auditLogDto.setOperation(PortalOperations.LOGIN_LOGOUT);
							if(authentication.getCategory().intValue() == CategoryCode.CUSTOMER.getValue()){
								auditLogDto.setModule(PortalModule.CUSTOMER_MANAGEMNET.getValue());
							} else {
								auditLogDto.setModule(PortalModule.EMPLOYEE_MANAGEMNET.getValue());
							}
							auditLogDto.setInfo(MessageFormat.format(AuditLogConstants.USER_LOGIN, authentication.getLastLoginTime()));
							commonService.addAuditLog(auditLogDto);
							
						} else {
							if(authentication.getPwAttempts() < UserConstants.MAX_PWD_ATTEMPTS ){
								Integer pwAttempts = authentication.getPwAttempts() + 1;
								authentication.setPwAttempts(pwAttempts);
								if(pwAttempts == UserConstants.MAX_PWD_ATTEMPTS) {
									authentication.setPwdStatus(AuthStatusCode.LOCKED.getValue());									
									loginDto.setLoginStatus(LoginCode.LOCKED);
									AutoUnlockUserTimerTask autoUnlockUserTimerTask = new AutoUnlockUserTimerTask(loginId,new Date(),pspMgmtService,propertyReader);
									autoUnlockUserTimerTask.startTimer();
								}
								else {
									loginDto.setLoginStatus(LoginCode.PWD_INCREMENTED);
								}
								pspDao.updateAuthentication(authentication);
							} else {
								loginDto.setLoginStatus(LoginCode.LOCKED);
							}
						}
					}else {
						loginDto.setLoginStatus(LoginCode.LOCKED);
						
					}
				} else if(authentication.getPwdStatus() == AuthStatusCode.LOCKED.getValue()){
						loginDto.setLoginStatus(LoginCode.LOCKED);
				  } 
				else {
						loginDto.setLoginStatus(LoginCode.IN_ACTIVE);	
					}
			}else{
				loginDto.setLoginStatus(LoginCode.INVALID_CATEGORY_ROLE);
			}
		}
		else {
			loginDto.setLoginStatus(LoginCode.USER_NOT_EXISTS);
		}
		return loginDto;
	}
	@Override
	public ResendNotificationCode resendNotification(String loginId, Integer categoryId, Long authId) {
		Authentication authentication = pspDao.getAuthenticationByLoginName(loginId);
		if( authentication != null ){
			if( authentication.getCategory().intValue() == categoryId.intValue() ){
				if(authentication.getPwdStatus() == AuthStatusCode.RESET.getValue() || authentication.getPwdStatus() == AuthStatusCode.NEW_USER.getValue()){
					String email = null;
					String url = propertyReader.getChangePwdUrl();
					String fullName = userDao.getFullNameByAuthId(authentication.getId());
					if(CategoryCode.CUSTOMER.getValue() == categoryId.intValue()){
						CustomerDetails customer = userDao.getCustomerDetailsbyauthId(authentication.getId());
						email = customer.getEmail();
						url += CUSTOMER;
					}else if(CategoryCode.ADMIN.getValue() == categoryId.intValue()){
						Employee employee = userDao.getEmployeeByAuthId(authentication.getId());
						email = employee.getEmail();
						url += ADMIN ;
					}
					else{
						MerchantUser merchant = userDao.getMerchantByAuthId(authentication.getId());
						email = merchant.getEmail();
						url += MERCHANT ;
					}
					
					String newUserCode = UserManagementUtil.generateNewUserCode(authentication.getUserName());
					authentication.setNewUserCode(newUserCode);
					authentication.setPassword(CommonConstants.EMPTY_STR);
					pspDao.updateAuthentication(authentication);
					String url_link = null;
					if(authentication.getPwdStatus().intValue() == AuthStatusCode.NEW_USER.getValue()){
						String subject = "";
						if(categoryId.intValue() == CategoryCode.CUSTOMER.getValue()) {
							subject = EmailMessageTemplates.NEW_CUSTOMER_ACTIVATION_SUBJECT;
							url_link = url + NEW_CUSTOMER + QUESTION_MARK + CODE + EQUAL_SYMBOL + newUserCode;
						}
						else if(CategoryCode.ADMIN.getValue() == categoryId.intValue()){
							subject = EmailMessageTemplates.NEW_EMPLOYEE_ACTIVATION_SUBJECT;
							url_link = url + NEW_EMPLOYEE + QUESTION_MARK + CODE + EQUAL_SYMBOL + newUserCode;
						}
						else{
							subject = EmailMessageTemplates.NEW_MERCHANT_ACTIVATION_SUBJECT;
							url_link = url + NEW_MERCHANT + QUESTION_MARK + CODE + EQUAL_SYMBOL + newUserCode;
						}
						String messageBody = MessageFormat.format(EmailMessageTemplates.NEW_USER_ACTIVATION_CONTENT, fullName, url_link );
						EmailMessage emailMessage = new EmailMessage(email, messageBody, subject);
						emailService.sendEmail(emailMessage);

						/*AuditLogDto auditLogDto = new AuditLogDto();
						auditLogDto.setAuthId(authId);
						auditLogDto.setRecordId(authentication.getId());
						auditLogDto.setOperation(MfsOperation.STATUS_CAHNGE);
						auditLogDto.setModule(MfsModule.COMMON_SETTINGS.getValue());
						auditLogDto.setInfo(MessageFormat.format(AuditLogConstants.RESEND_NOTIFICATION_NEWUSER, fullName));
						auditLogRepository.addAuditLog(auditLogDto);*/

						return ResendNotificationCode.SUCCESS;
					}
					else if(authentication.getPwdStatus() == AuthStatusCode.RESET.getValue()){
						String subject = EmailMessageTemplates.PASSWORD_ACTIVATION_SUBJECT;
						url_link = url + RESET_PWD + QUESTION_MARK + CODE + EQUAL_SYMBOL + newUserCode;
						String messageBody = MessageFormat.format(EmailMessageTemplates.PASSWORD_ACTIVATION_CONTENT, fullName, url_link);
						EmailMessage emailMessage = new EmailMessage(email, messageBody, subject);
						emailService.sendEmail(emailMessage);

						/*AuditLogDto auditLogDto = new AuditLogDto();
						auditLogDto.setAuthId(authId);
						auditLogDto.setRecordId(authentication.getId());
						auditLogDto.setOperation(MfsOperation.STATUS_CAHNGE);
						auditLogDto.setModule(MfsModule.COMMON_SETTINGS.getValue());
						auditLogDto.setInfo(MessageFormat.format(AuditLogConstants.RESEND_NOTIFICATION_RESET, fullName));
						auditLogRepository.addAuditLog(auditLogDto);*/

						return ResendNotificationCode.SUCCESS;
					}
				}
				else if(authentication.getPwdStatus() == AuthStatusCode.LOCKED.getValue()){
					return ResendNotificationCode.BLOCKED_USER;
				}
				else if(authentication.getNewUserCode() == null || CommonConstants.EMPTY_STR.equals(authentication.getNewUserCode())){
					return ResendNotificationCode.ALREADY_ACTIVE;
				}
			}
			else{
				return ResendNotificationCode.WRONG_USER;
			}
		}
		else{
			return ResendNotificationCode.WRONG_USER;
		}
		return ResendNotificationCode.FAILED;
	}

	@Override
	public NewUserPwChangeStatus newUserPasswordChange(NewUserDto user) {
		Authentication authentication = pspDao.getAuthenticationByLoginName(user.getUserName());
		if( authentication != null ){
			authentication.setQuestionId(user.getQuestionId());
			authentication.setAnswer(user.getAnswer());
			authentication.setPassword(PasswordEncryptor.encrypt(user.getPassword()));
			authentication.setNewUserCode(CommonConstants.EMPTY_STR);
			authentication.setPwdStatus(AuthStatusCode.ACTIVE.getValue());
			pspDao.updateAuthentication(authentication);
			
			PasswordHistory newPh = new PasswordHistory();
			newPh.setAuthId(authentication.getId());
			newPh.setPassword(PasswordEncryptor.encrypt(user.getPassword()));
			newPh.setCreationDate(new Date());
			userDao.createPasswordHistory(newPh);

			//Need to prepare audi log
			return NewUserPwChangeStatus.SUCCESS;
		}
		else{
			return NewUserPwChangeStatus.FAILED;
		}
	}

	@Override
	public boolean changePassword(AuthenticationDto authenticationDto) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public ForgotPasswordCode forgotPassword(String loginId,Integer categoryId, Long securityQuestionId, String securityAnswer,
			Long authId, boolean byAdmin) {
		Authentication authentication = pspDao.getAuthenticationByLoginName(loginId);
		ForgotPasswordCode code = null;
		
		if(authentication != null && authentication.getCategory().intValue() == categoryId.intValue() ){
				if(authentication.getPwdStatus() == AuthStatusCode.ACTIVE.getValue() || authentication.getPwdStatus() == AuthStatusCode.RESET.getValue() 
						|| authentication.getPwdStatus() == AuthStatusCode.LOCKED.getValue()){
					if(byAdmin){
						return doForgotPassword(authentication, categoryId);
					}else{
						if(securityQuestionId != null && securityAnswer != null) {
							if(authentication.getQuestionId() == securityQuestionId && authentication.getAnswer().equals(securityAnswer)){
								return doForgotPassword(authentication, categoryId);
							}
							else{
								code = ForgotPasswordCode.WRONG_DATA;
							}
						}
						else{
							code = ForgotPasswordCode.WRONG_DATA;
						}
					}
				}
			}
			else{
				code = ForgotPasswordCode.USER_NOT_EXISTS;
			}
		return code;
	}
	
	private ForgotPasswordCode doForgotPassword(Authentication authentication, Integer categoryId){
		ForgotPasswordCode code = null;
		authentication.setPassword(CommonConstants.EMPTY_STR);
		authentication.setNewUserCode(UserManagementUtil.generateNewUserCode(authentication.getUserName()));
		authentication.setPwdStatus(AuthStatusCode.RESET.getValue());
		authentication.setPwAttempts(0);
		pspDao.updateAuthentication(authentication);
		code = ForgotPasswordCode.SUCCESS;
		String url = propertyReader.getChangePwdUrl();
		String fullName = userDao.getFullNameByAuthId(authentication.getId());
		String subject = EmailMessageTemplates.PASSWORD_ACTIVATION_SUBJECT;
		String email ="";
		if(CategoryCode.CUSTOMER.getValue() == categoryId.intValue()){
			url += CUSTOMERPATH;
			CustomerDetails customerdto = userDao.getCustomerDetailsbyauthId(authentication.getId());
			email=customerdto.getEmail();
		}else if(CategoryCode.MERCHANT.getValue() == categoryId.intValue()){
			url += MERCHANT;
			MerchantUser mer = userDao.getMerchantByAuthId(authentication.getId());
			email =mer.getEmail();
		}
		else if(CategoryCode.ADMIN.getValue() == categoryId.intValue() || CategoryCode.SUPER_ADMIN.getValue() ==categoryId.intValue() ){
			url += ADMIN;
			Employee emp = userDao.getEmployeeByAuthId(authentication.getId());
			email=emp.getEmail();
		}
		String url_link = url + RESET_PWD + QUESTION_MARK + CODE + EQUAL_SYMBOL + authentication.getNewUserCode();
		String messageBody = MessageFormat.format(EmailMessageTemplates.PASSWORD_ACTIVATION_CONTENT, fullName, url_link);
		EmailMessage emailMessage = new EmailMessage(email, messageBody, subject);
		emailService.sendEmail(emailMessage);
		LOGGER.info("user link link link ============="+ url_link);							
		return code;
	}

}