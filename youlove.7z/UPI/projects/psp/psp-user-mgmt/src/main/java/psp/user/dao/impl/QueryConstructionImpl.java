/**
 * 
 */
package psp.user.dao.impl;

import org.springframework.stereotype.Component;

import psp.constants.CategoryCode;
import psp.dto.BillpayerSearchDto;
import psp.dto.RoleSearchDto;
import psp.dto.TransactionSearchDto;
import psp.dto.UserSearchDto;
import psp.user.dao.QueryConstruction;

/**
 * @author prasadj
 *
 */
@Component
public class QueryConstructionImpl implements QueryConstruction {

	private static final String STATUS_APDR = "and a.userStatus = ";
	
	@Override
	public String getMerchantSummarySearch(UserSearchDto userSearchDto ){
		
		StringBuilder sb = new StringBuilder();
		sb.append("select new psp.dto.UserProfileDto(m.id, a.userName,  m.name, m.email, m.phoneNumber, a.userStatus ) ");
		sb.append("from psp.dbservice.model.MerchantUser as m, psp.dbservice.model.Authentication as a ");
		sb.append("where m.authId = a.id" );
		sb.append(" and  a.category = " + CategoryCode.MERCHANT.getValue() + " ");

		if(userSearchDto.getName() != null && !"".equals(userSearchDto.getName())){
			sb.append("and upper(m.name) like upper('%" + userSearchDto.getName() + "%') ");
		}

		if(userSearchDto.getStatus() != null ){
			sb.append(STATUS_APDR + userSearchDto.getStatus() + " ");
		}
		
		return sb.toString();
	}
	
    public String getEmployeeSummarySearch(UserSearchDto userSearchDto ){
    	
        StringBuilder sb = new StringBuilder();
        sb.append("select new psp.dto.UserProfileDto(e.id, a.userName, e.firstName || ' ' || e.middleName || ' ' || e.lastName, e.email, ");
		sb.append("e.phoneNumber, a.userStatus");
		sb.append(") from psp.dbservice.model.Employee as e, psp.dbservice.model.Authentication as a ");
		sb.append(" where a.id = e.authId ");
		sb.append(" and a.id != " + userSearchDto.getSelfAuthId() + " ");
		sb.append(" and a.category = " + CategoryCode.ADMIN.getValue() + " ");
		
		if(userSearchDto.getName() != null && !"".equals(userSearchDto.getName())){
			sb.append("and ( upper(e.firstName) like upper('%" + userSearchDto.getName() + "%') ");
			sb.append("or  upper(e.middleName) like upper('%" + userSearchDto.getName() + "%') ");
			sb.append("or upper(e.lastName) like upper('%" + userSearchDto.getName() + "%')) ");
		}
		
		if(userSearchDto.getStatus() != null ){
			sb.append(STATUS_APDR + userSearchDto.getStatus() + " ");
		}
		
		return sb.toString();
	}
    
    @Override
	public String getCustomerSummarySearch(UserSearchDto userSearchDto){
		
		StringBuilder sb = new StringBuilder();
		
		sb.append("select new psp.dto.UserProfileDto(c.id, a.userName, c.firstName || ' ' || c.middleName || ' ' || c.lastName , c.email, ");
		sb.append("c.mobileNumber, a.userStatus, c.authId) from psp.dbservice.model.CustomerDetails as c, psp.dbservice.model.Authentication as a");
		sb.append(" where c.authId = a.id  ");
		sb.append("and a.category = " + CategoryCode.CUSTOMER.getValue() + " ");

		if(userSearchDto.getName() != null && !"".equals(userSearchDto.getName())){
			sb.append("and ( upper(c.firstName) like upper('%" + userSearchDto.getName() + "%') ");
			sb.append("or  upper(c.middleName) like upper('%" + userSearchDto.getName() + "%') ");
			sb.append("or upper(c.lastName) like upper('%" + userSearchDto.getName() + "%')) ");
		}
		
		if(userSearchDto.getStatus() != null && !"".equals(userSearchDto.getStatus())){
			sb.append(STATUS_APDR + userSearchDto.getStatus() + ") ");
		}

		return sb.toString();
	}
    
    @Override
	public  String getCustomerBillSummarySearch(BillpayerSearchDto billpayerSearchDto){
		StringBuilder sb = new StringBuilder();
		
		sb.append("select new psp.common.model.CustomerBillSummary(bm.customerName, bm.identification, bm.merchantVirtualAddress, bm.billDate, bm.expDate, bm.notificationDate, bm.notificationExpDate) from BillMappingDetails bm ");

		if(billpayerSearchDto.getName() != null && !"".equals(billpayerSearchDto.getName())){
			sb.append(" where upper(bm.customerName) like upper('%" + billpayerSearchDto.getName() + "%') ");
		}

		return sb.toString();
    	
    }
    
    @Override
    public String  searchTransactiondetails(TransactionSearchDto  transactionSearchDto ){
    	StringBuilder sb = new StringBuilder();
		
		sb.append("select new psp.common.model.TransactionSumary(tr.txnId,tr.toAddr, tr.txnInitiationTime, tr.amount, tr.status, tr.reconStatus) from TransactionDetails tr ");

		if(transactionSearchDto.getTransaction_id() != null && !"".equals(transactionSearchDto.getTransaction_id())){
			sb.append(" where upper(tr.txnId) like upper('%" + transactionSearchDto.getTransaction_id() + "%') ");
		}
		return sb.toString();
    }

	@Override
	public String getRoleSummarySearch(RoleSearchDto dto) {
		StringBuilder sb = new StringBuilder();
		sb.append("select new psp.dto.RoleDto(r.id, r.name, r.description, r.category) from psp.dbservice.model.UserRole as r ");
		sb.append("where r.category = " + dto.getCategory() + " ");
		if( dto.getCategory() != 0 ){
			sb.append(" and r.id != " + dto.getCurrentUserRoleId() + " ");
		}
		else{
			sb.append(" or r.id != " + dto.getCurrentUserRoleId() + " ");
		}
		if( dto.getName() != null && !"".equals(dto.getName()) ){
			if( dto.getCategory() != 0 ){
				sb.append(" and upper(r.name) like upper('%" + dto.getName() + "%') ");
			}
			else {
				sb.append(" or upper(r.name) like upper('%" + dto.getName() + "%') ");
			}
		}
		System.out.println(sb.toString());
		return sb.toString();
	}
    
	 @Override
		public String getMerchantAssociatedCustomersSearch(UserSearchDto userSearchDto, Long id){
			
			StringBuilder sb = new StringBuilder();
			boolean flag = false;
			sb.append("select distinct new psp.dbservice.model.CustomerDetails(c.id, c.firstName, c.middleName, c.lastName, c.mobileNumber, c.email, ac.virtualAddress) from CustomerDetails as c, AccountDetails as ac, BillMappingDetails bm where ");

			if(userSearchDto.getName() != null && !"".equals(userSearchDto.getName())){
				flag= true;
				sb.append(" upper(bm.customerName) like upper('%" + userSearchDto.getName() + "%') and ");
			}if(userSearchDto.getPhoneNumber() != null && !"".equals(userSearchDto.getPhoneNumber())){
				flag= true;
				sb.append(" bm.customerName in (select cu.userName from CustomerDetails as cu where cu.mobileNumber = '" + userSearchDto.getPhoneNumber() + "' ) and ");
			}if(userSearchDto.getEmail() != null && !"".equals(userSearchDto.getEmail())){
				flag= true;
				sb.append(" bm.customerName in (select cu.userName from CustomerDetails as cu where cu.email = '" + userSearchDto.getEmail() + "' ) and ");
			}if(flag){
				sb.append(" bm.merchantId = " + id +  " and ac.customerDetails.id = c.id and bm.customerName = c.userName ");
			}
			else if(!flag){
				sb.append(" c.userName in (select bmb.customerName from BillMappingDetails bmb where bmb.merchantId = " + id +  " ) and ac.customerDetails.id = c.id ");
			}
			return sb.toString();
		}
	 
	 
	 @Override
		public String getCustomerAddedMerchantsearch(UserSearchDto userSearchDto, String userName){
			
			StringBuilder sb = new StringBuilder();
			boolean flag = false;
			sb.append("select distinct new psp.mobile.model.response.MerchantDetails(m.id, m.name, ac.virtualAddress, m.firstName, m.middleName, m.lastName, m.email, m.phoneNumber) from MerchantUser as m, MerchantAccount ac, BillMappingDetails bm where ");

			if(userSearchDto.getName() != null && !"".equals(userSearchDto.getName())){
				flag= true;
				sb.append(" bm.merchantId in (select me.id from MerchantUser as me where me.name = '" + userSearchDto.getName() + "' ) and ");
			}if(userSearchDto.getPhoneNumber() != null && !"".equals(userSearchDto.getPhoneNumber())){
				flag= true;
				sb.append(" bm.merchantId in (select me.id from MerchantUser as me where me.phoneNumber = '" + userSearchDto.getPhoneNumber() + "' ) and ");
			}if(userSearchDto.getEmail() != null && !"".equals(userSearchDto.getEmail())){
				flag= true;
				sb.append(" bm.merchantId in (select me.id from MerchantUser as me where me.email = '" + userSearchDto.getEmail() + "' ) and ");
			}if(flag){
				sb.append(" bm.customerName = '" + userName + "' and ac.merchantId = m.id and bm.merchantId = m.id ");
			}else if(!flag){
				sb.append(" m.id in (select bmd.merchantId from BillMappingDetails bmd where bmd.customerName = '" + userName + "') and ac.merchantId = m.id and bm.merchantId = m.id ");
			}
			return sb.toString();
		}
}