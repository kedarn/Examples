/**
 * 
 */
package psp.user.dao;

import java.util.List;

import psp.dbservice.model.Address;
import psp.dbservice.model.CustomerDetails;
import psp.dbservice.model.Employee;
import psp.dbservice.model.MerchantAccount;
import psp.dbservice.model.MerchantUser;
import psp.dbservice.model.PasswordHistory;
import psp.dto.AddressDto;
import psp.dto.UserProfileDto;
import psp.dto.UserProfileDto;
import psp.dto.UserProfileDto;
import psp.dto.UserSearchDto;

/**
 * @author prasadj
 *
 */
public interface UserDao {

	AddressDto getAdressDeatsils(Long addrId);
	   
	void saveAdressDeatsils(Address address);

	void updateAdressDeatsils(Address address);

	String getFullNameByCustomerId(Long customerId);

    List<UserProfileDto> getCustomerProfileSummaryList(UserSearchDto customerSearchDto);
    
	Employee getEmployeeByEmployeeId(Long employeeId);

	Employee getEmployeeByAuthId(Long authId);

    void saveEmployee(Employee employee);
    
    void updateEmployee(Employee employee);
    
	String getFullNameByEmployeeId(Long employeeId);
	
	List<UserProfileDto> getEmployeeProfileSummaryList(UserSearchDto employeeSearchDto);

	MerchantUser getMerchantByMerchantId(Long merchantId);

	MerchantUser getMerchantByAuthId(Long authId);

    void saveMerchant(MerchantUser merchant);
    
    void updateMerchant(MerchantUser merchant);
    
	String getFullNameByMerchantId(Long merchantId);
	
	List<UserProfileDto> getMerchantProfileSummaryList(UserSearchDto employeeSearchDto);

	String getFullNameByAuthId(Long authId);
	
	List<PasswordHistory> getPasswordHistory(Long authId);
	
	void deletePasswordHistory(PasswordHistory ph);
	
	void createPasswordHistory(PasswordHistory ph);
	
	void saveMerchantAccount(MerchantAccount merchantAccount);
	
	void updateMerchantAccount(MerchantAccount merchant);
	
	MerchantAccount getMerchantAccountByMerchantId(Long merchantId);
	
	public CustomerDetails getCustomerDetailsbyauthId(Long authID);
	
	void updateCustomer(CustomerDetails customer);
	
	CustomerDetails getCustomerByCustomerId(Long customerId);
	
}