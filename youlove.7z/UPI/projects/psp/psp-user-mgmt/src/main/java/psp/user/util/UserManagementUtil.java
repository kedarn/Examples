/**
 * 
 */
package psp.user.util;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Set;

import psp.constants.AuthStatusCode;
import psp.constants.BankCodes;
import psp.constants.CategoryCode;
import psp.constants.DateUtil;
import psp.constants.DiscrepancyCodes;
import psp.constants.PspPortalConstants;
import psp.constants.TransactionStatusCode;
import psp.constants.UserStatus;
import psp.dbservice.model.ActionItem;
import psp.dbservice.model.Address;
import psp.dbservice.model.Authentication;
import psp.dbservice.model.CustomerDetails;
import psp.dbservice.model.Employee;
import psp.dbservice.model.MerchantAccount;
import psp.dbservice.model.MerchantUser;
import psp.dbservice.model.UserRole;
import psp.dto.ActionItemDto;
import psp.dto.MerchantAccountDto;
import psp.dto.RoleDto;
import psp.dto.UserProfileDto;


/**
 * @author prasadj
 *
 */
public class UserManagementUtil {
	
	public static final String RANDOM_USER_CODE = "9876543210ZYXWVUTSRQPONMLKJIHGFEDCBAabcdefghijklmnopqrstuvwxyz!@#$&_";
	
	public static final int RANDOM_USER_LENGTH = 20;
	
	private UserManagementUtil(){
	}
	
	public static RoleDto getUserRoleDto(UserRole role){
		RoleDto dto = new RoleDto();
		dto.setDescription(role.getDescription());
		dto.setId(role.getId());
		dto.setName(role.getName());
		dto.setActions(getActionItemDtos(role.getActions()));
		dto.setCategory(role.getCategory());
		return dto;
	}
	
	public static List<RoleDto> getUserRoleDtoList(List<UserRole> roles){
		List<RoleDto> roleDtoList = new ArrayList<RoleDto>();
		if(null != roles) {
			for(UserRole userRole: roles) {
				roleDtoList.add(getUserRoleDto(userRole));
			}
		}
		return roleDtoList;
	}
	
	public static List<ActionItemDto> getActionItemDtos(Set<ActionItem> aiList){
		List<ActionItemDto> actions = new ArrayList<ActionItemDto>();
		if(aiList != null){
			for(ActionItem ai: aiList){
				actions.add(new ActionItemDto(ai.getId(), ai.getName(), ai.getDescription()));
			}
		}
		return actions;
	}
	
	public static List<CategoryCode> categoryList() {
		List<CategoryCode> list = new ArrayList<CategoryCode>();
		list.add(CategoryCode.ADMIN);
		return list;
	}
	
	public static List<UserStatus> getStatuses() {
		List<UserStatus> list = new ArrayList<UserStatus>();
		list.add(UserStatus.ACTIVE);
		list.add(UserStatus.DELETE);
		list.add(UserStatus.SUSPEND);
		return list;
	}
	
	
	public static List<BankCodes> getBanks() {
		List<BankCodes> list = new ArrayList<BankCodes>();
		list.add(BankCodes.AXIS);
		list.add(BankCodes.ICICI);
		return list;
	}
	
	public static List<DiscrepancyCodes> getSearchCodes() {
		List<DiscrepancyCodes> list = new ArrayList<DiscrepancyCodes>();
		list.add(DiscrepancyCodes.TRANSACTION_ID);
		list.add(DiscrepancyCodes.MID);
		return list;
	}
	
	public static List<DiscrepancyCodes> getDiscrepancyType() {
		List<DiscrepancyCodes> list = new ArrayList<DiscrepancyCodes>();
		list.add(DiscrepancyCodes.FEE_AMOUNT);
		list.add(DiscrepancyCodes.REFUND_AMOUNT);
		list.add(DiscrepancyCodes.STATUS);
		return list;
	}
	
	public static List<TransactionStatusCode> getTransactionStatuses() {
		List<TransactionStatusCode> list = new ArrayList<TransactionStatusCode>();
		list.add(TransactionStatusCode.COMPLETED);
		list.add(TransactionStatusCode.FAILED);
		list.add(TransactionStatusCode.INITIATED);
		return list;
	}
	
	public static Authentication createEmployeeAuthenticationModel(UserProfileDto employeeDto){
		Authentication authentication = new Authentication();
		authentication.setCategory(employeeDto.getCategory());
		authentication.setUserName(employeeDto.getLoginName());
		authentication.setPwAttempts(PspPortalConstants.DEFAULT_ATTEMPTS);
		authentication.setPwdStatus(AuthStatusCode.ACTIVE.getValue());
		authentication.setUserStatus(UserStatus.ACTIVE.getValue());
		authentication.setNewUserCode(generateNewUserCode(employeeDto.getLoginName()));
		return authentication;
	}
	
	public static String generateNewUserCode(String username) {
		StringBuilder sb = new StringBuilder();
		String delim = "-";
		sb.append(generateRandomString(20));
		sb.append(delim);
		sb.append(username);
		sb.append(delim);
		sb.append(new Date().getTime());
		return sb.toString();
	}
	
	public static String generateRandomString(int length) {
		
		StringBuilder sb = new StringBuilder(length);
		for (int i = 0; i < length; i++) {
			int ndx = (int) (Math.random() * RANDOM_USER_LENGTH);
			sb.append(RANDOM_USER_CODE.charAt(ndx));
		}
		return sb.toString();
	}
	
	public static Address createUserAddressModel(UserProfileDto employeeDto) {
		Address address = new Address();
		address.setLine1(employeeDto.getLine1());
		address.setLine2(employeeDto.getLine2());
		address.setCountry(employeeDto.getCountryName());
		address.setDistrict(employeeDto.getDistrictName());
		address.setState(employeeDto.getStateName());
		address.setPinCode(employeeDto.getPincode());
		return address;
	}
	
	public static Employee createEmployeeModel(UserProfileDto employeeDto, Long authID, Long addressId){
		Employee employee = new Employee();
		employee.setAuthId(authID);
		employee.setFirstName(employeeDto.getFirstName());
		employee.setMiddleName(employeeDto.getMiddleName());
		employee.setLastName(employeeDto.getLastName());
		employee.setDateOfBirth(employeeDto.getDateOfBirth());
		employee.setAddressId(addressId);
		employee.setCreatedBy(employeeDto.getCreatedby());
		employee.setPhoneNumber(employeeDto.getPhoneNumber());
		employee.setAltPhoneNumber(employeeDto.getAltPhoneNumber());
		employee.setEmail(employeeDto.getEmail());
		employee.setCreationDate(new Date());
		return employee;
	}
	
	public static void updateEmployeeModel(Employee employee, UserProfileDto employeeDto){
		employee.setFirstName(employeeDto.getFirstName());
		employee.setMiddleName(employeeDto.getMiddleName());
		employee.setLastName(employeeDto.getLastName());
		employee.setDateOfBirth(DateUtil.convertStringToDate(employeeDto.getDateOfBirthStr()));
		employee.setPhoneNumber(employeeDto.getPhoneNumber());
		employee.setAltPhoneNumber(employeeDto.getAltPhoneNumber());
		employee.setEmail(employeeDto.getEmail());
	}
	
	public static void updateUserAddressModel(Address address, UserProfileDto employeeDto){
		address.setLine1(employeeDto.getLine1());
		address.setLine2(employeeDto.getLine2());
		address.setCountry(employeeDto.getCountryName());
		address.setState(employeeDto.getStateName());
		address.setDistrict(employeeDto.getDistrictName());
		address.setPinCode(employeeDto.getPincode());
	}
	
	public static Authentication createMerchantAuthenticationModel(UserProfileDto merchantDto){
		Authentication authentication = new Authentication();
		authentication.setCategory(CategoryCode.MERCHANT.getValue());
		authentication.setUserName(merchantDto.getLoginName());
		authentication.setPwAttempts(PspPortalConstants.DEFAULT_ATTEMPTS);
		authentication.setPwdStatus(AuthStatusCode.ACTIVE.getValue());
		authentication.setUserStatus(UserStatus.ACTIVE.getValue());
		authentication.setNewUserCode(generateNewUserCode(merchantDto.getLoginName()));
		return authentication;
	}
	
	public static Address createMerchantAddressModel(UserProfileDto merchantDto) {
		Address address = new Address();
		address.setLine1(merchantDto.getLine1());
		address.setLine2(merchantDto.getLine2());
		address.setCountry(merchantDto.getCountryName());
		address.setDistrict(merchantDto.getDistrictName());
		address.setState(merchantDto.getStateName());
		address.setPinCode(merchantDto.getPincode());
		return address;
	}
	
	public static MerchantUser createMerchantModel(UserProfileDto merchantDto, Long authID, Long addressId){
		MerchantUser merchant = new MerchantUser();
		merchant.setAuthId(authID);
		merchant.setFirstName(merchantDto.getFirstName());
		merchant.setMiddleName(merchantDto.getMiddleName());
		merchant.setLastName(merchantDto.getLastName());
		merchant.setAddressId(addressId);
		merchant.setPhoneNumber(merchantDto.getPhoneNumber());
		merchant.setEmail(merchantDto.getEmail());
		merchant.setName(merchantDto.getName());
		merchant.setEstablishDate(merchantDto.getEstablishDate());
		merchant.setRegistrationDate(new Date());
		return merchant;
	}
	
	public static void updateMerchantAddressModel(Address address, UserProfileDto merchantDto){
		address.setLine1(merchantDto.getLine1());
		address.setLine2(merchantDto.getLine2());
		address.setCountry(merchantDto.getCountryName());
		address.setState(merchantDto.getStateName());
		address.setDistrict(merchantDto.getDistrictName());
		address.setPinCode(merchantDto.getPincode());
	}
	
	public static void updateMerchantModel(MerchantUser merchant, UserProfileDto merchantDto){
		merchant.setFirstName(merchantDto.getFirstName());
		merchant.setMiddleName(merchantDto.getMiddleName());
		merchant.setLastName(merchantDto.getLastName());
		merchant.setPhoneNumber(merchantDto.getPhoneNumber());
	    merchant.setEstablishDate(DateUtil.convertStringToDate(merchantDto.getEstablishDateStr()));
		merchant.setEmail(merchantDto.getEmail());
	}
	
	public static MerchantAccount prepareMerchantAccountModel(MerchantAccountDto merchantAccountDto) {
		MerchantAccount merchantAccount = new MerchantAccount();
		merchantAccount.setAccountNumber(merchantAccountDto.getAccountNumber());
		merchantAccount.setAccountType(merchantAccountDto.getAccountType());
		merchantAccount.setIfsc(merchantAccountDto.getIfsc());
		merchantAccount.setMerchantId(merchantAccountDto.getMerchantId());
		merchantAccount.setName(merchantAccountDto.getName());
		merchantAccount.setVirtualAddress(merchantAccountDto.getName() + "@tarang");
		return merchantAccount;
	}
	
	public static boolean validateCode(String dbcode, String codeFromUrl){
		if(dbcode.equals(codeFromUrl)){
			String[] array = codeFromUrl.split("-");
			if(compareDate(array[2]) > 86400000){
				return false;
			}
			return true;
		}
		else{
			throw new RuntimeException("code is mismatched");
		}
	}
	
	public static long compareDate(String code){
		Long urlTime = Long.valueOf(code).longValue();
		return new Date().getTime() - urlTime;
	}
	
	public static UserProfileDto prepareUserProfileDto(UserProfileDto employee) {
		UserProfileDto userProfileDto = new UserProfileDto();
		userProfileDto.setCountryName(employee.getCountryName());
		userProfileDto.setDistrictName(employee.getDistrictName());
		userProfileDto.setUserID(employee.getId());
		userProfileDto.setStateName(employee.getStateName());
		userProfileDto.setLine1(employee.getLine1());
		userProfileDto.setLine2(employee.getLine2());
		userProfileDto.setPincode(employee.getPincode());
		userProfileDto.setAltPhoneNumber(employee.getAltPhoneNumber());
		userProfileDto.setDateOfBirth(employee.getDateOfBirth());
		userProfileDto.setDateOfBirthStr(DateUtil.convertDateToString(employee.getDateOfBirth()));
		userProfileDto.setEmail(employee.getEmail());
		userProfileDto.setFirstName(employee.getFirstName());
		userProfileDto.setLastName(employee.getLastName());
		userProfileDto.setMiddleName(employee.getMiddleName());
		userProfileDto.setLoginName(employee.getLoginName());
		userProfileDto.setPhoneNumber(employee.getPhoneNumber());		
		return userProfileDto;
	}
	
/*	public static UserProfileDto prepareUserProfileDto(MerchantDto merchant) {
		UserProfileDto userProfileDto = new UserProfileDto();
		userProfileDto.setCountryName(merchant.getCountryName());
		userProfileDto.setDistrictName(merchant.getDistrictName());
		userProfileDto.setStateName(merchant.getStateName());
		userProfileDto.setUserID(merchant.getId());
		userProfileDto.setLine1(merchant.getLine1());
		userProfileDto.setLine2(merchant.getLine2());
		userProfileDto.setPincode(merchant.getPincode());
		userProfileDto.setEmail(merchant.getEmail());
		userProfileDto.setDateOfBirthStr(merchant.getDateOfBirthStr());
		userProfileDto.setFirstName(merchant.getFirstName());
		userProfileDto.setGender(merchant.getGender());
		userProfileDto.setLastName(merchant.getLastName());
		userProfileDto.setMiddleName(merchant.getMiddleName());
		userProfileDto.setLoginName(merchant.getLoginName());
		userProfileDto.setPhoneNumber(merchant.getPhoneNumber());
		userProfileDto.setEstablishDate(merchant.getEstablishDate());
		userProfileDto.setEstablishDateStr(DateUtil.convertDateToString(merchant.getEstablishDate()));
		return userProfileDto;
	}*/
	
	/*public static UserProfileDto prepareUserProfileDto(UserProfileDto customer) {
		UserProfileDto userProfileDto = new UserProfileDto();
		userProfileDto.setEmail(customer.getEmail());
		userProfileDto.setFirstName(customer.getFirstName());
		userProfileDto.setUserID(customer.getId());
		userProfileDto.setLastName(customer.getLastName());
		userProfileDto.setMiddleName(customer.getMiddleName());
		userProfileDto.setLoginName(customer.getUserName());
		userProfileDto.setPhoneNumber(customer.getMobileNumber());		
		return userProfileDto;
	}*/
	
	
	public static void updateCustomerModel(CustomerDetails customer, UserProfileDto customerDto, Long addressId){
		customer.setFirstName(customerDto.getFirstName());
		customer.setMiddleName(customerDto.getMiddleName());
		customer.setLastName(customerDto.getLastName());
		customer.setDateOfBirth(DateUtil.convertStringToDate(customerDto.getDateOfBirthStr()));
		customer.setMobileNumber(customerDto.getPhoneNumber());
		customer.setEmail(customerDto.getEmail());
		customer.setAadhaarNumber(customerDto.getAadhaarNumber());
		customer.setAddressId(addressId);
	}
	
	public static Long getLong(Object value){
		Long c = null;
		if(value != null ){
			c = Long.valueOf(value.toString());
		}
		return c;
	}
	
}