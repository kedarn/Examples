/**
 * 
 */
package psp.dto;

import java.io.Serializable;


/**
 * @author prasadj
 *
 */
public class BankDto implements Serializable {

	private static final long serialVersionUID = 1L;

	private Long merchantId;
	
	private String merchantName;
	
	private String email;
	
	private String ifscCode;
	
	private String accountType;
	
	private String virtualAddress;
	
	private String accountNumber;
	
	private String verifiedStatus;
	
	private Long id;
	
	public BankDto(){
	}
	
	public BankDto(Long merchantId, String merchantName, String email,
			String ifscCode, String accountType, String virtualAddress,
			String accountNumber, String verifiedStatus,Long id) {
		super();
		this.merchantId = merchantId;
		this.merchantName = merchantName;
		this.email = email;
		this.ifscCode = ifscCode;
		this.accountType = accountType;
		this.virtualAddress = virtualAddress;
		this.accountNumber = accountNumber;
		this.verifiedStatus = verifiedStatus;
		this.id=id;
	}
	
	public Long getMerchantId() {
		return merchantId;
	}
	
	public void setMerchantId(Long merchantId) {
		this.merchantId = merchantId;
	}
	
	public String getMerchantName() {
		return merchantName;
	}
	
	public void setMerchantName(String merchantName) {
		this.merchantName = merchantName;
	}
	
	public String getEmail() {
		return email;
	}
	
	public void setEmail(String email) {
		this.email = email;
	}
	
	public String getIfscCode() {
		return ifscCode;
	}
	
	public void setIfscCode(String ifscCode) {
		this.ifscCode = ifscCode;
	}
	
	public String getAccountType() {
		return accountType;
	}
	
	public void setAccountType(String accountType) {
		this.accountType = accountType;
	}
	
	public String getVirtualAddress() {
		return virtualAddress;
	}
	
	public void setVirtualAddress(String virtualAddress) {
		this.virtualAddress = virtualAddress;
	}
	
	public String getAccountNumber() {
		return accountNumber;
	}
	
	public void setAccountNumber(String accountNumber) {
		this.accountNumber = accountNumber;
	}
	
	public String getVerifiedStatus() {
		return verifiedStatus;
	}
	
	public void setVerifiedStatus(String verifiedStatus) {
		this.verifiedStatus = verifiedStatus;
	}
	
	public Long getId() {
		return id;
	}
	
	public void setId(Long id) {
		this.id = id;
	}
	
}