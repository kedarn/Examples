/**
 * 
 */
package psp.user.service;

import java.util.List;

import psp.dto.ActionItemDto;
import psp.dto.RoleDto;
import psp.dto.RoleSearchDto;

/**
 * @author prasadj
 *
 */
public interface RoleService {

	List<RoleDto> getAdminRoles();
	
	RoleDto getRole(Long roleId);
	
	List<ActionItemDto> getAdminActionItems();

	ActionItemDto getActionItem(Long id);

	RoleDto addRole(RoleDto role);
	
	RoleDto updateRole(RoleDto role);
	
	List<ActionItemDto> getActionItems(Integer category);
	
	RoleDto addRole(RoleDto role, Long authId);
	
	RoleDto updateRole(RoleDto role, Long authId);
	
	List<RoleDto> getRoleByRoleName(String roleName);

	List<RoleDto> getRoles(RoleSearchDto dto);
	
}