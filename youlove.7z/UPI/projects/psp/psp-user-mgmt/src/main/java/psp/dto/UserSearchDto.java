/**
 * 
 */
package psp.dto;

import java.io.Serializable;

/**
 * @author prasadj
 *
 */
public class UserSearchDto implements Serializable {

	private static final long serialVersionUID = 1L;

	private String loginName;
	
	private String name;
	
	private String email;
	
	private String phoneNumber;
	
	private Long selfAuthId;
	
	private Integer category;
	
	private Integer status;
	
	public UserSearchDto(){
	}

	public String getLoginName() {
		return loginName;
	}

	public void setLoginName(String loginName) {
		this.loginName = loginName;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getPhoneNumber() {
		return phoneNumber;
	}

	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}

	public Long getSelfAuthId() {
		return selfAuthId;
	}

	public void setSelfAuthId(Long selfAuthId) {
		this.selfAuthId = selfAuthId;
	}

	public Integer getCategory() {
		return category;
	}

	public void setCategory(Integer category) {
		this.category = category;
	}

	public Integer getStatus() {
		return status;
	}

	public void setStatus(Integer status) {
		this.status = status;
	}

}