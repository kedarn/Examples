/**
 * 
 */
package psp.user.service;

import java.util.List;

import psp.dbservice.model.CustomerDetails;
import psp.dbservice.model.MerchantAccount;
import psp.dto.UserProfileDto;
import psp.dto.UserProfileDto;
import psp.dto.MerchantDto;
import psp.dto.UserProfileDto;
import psp.dto.UserSearchDto;

/**
 * @author prasadj
 *
 */
public interface UserService {

	UserProfileDto getCustomer(Long customerId);
	
	UserProfileDto getCustomer(String userName);
	
	CustomerDetails getCustomerByAuthId(Long authId);
	
	UserProfileDto updateCustomer(UserProfileDto customerDto, Long authId );
	
	String getFullNameByCustomerId(Long customerId);
	
	List<UserProfileDto> getCustomerProfileSummaryList(UserSearchDto customerSearchDto);
	
	MerchantDto addMerchant(MerchantDto merchantDto);
	
	MerchantDto getMerchant(Long merchantId);
	
	MerchantDto getMerchant(String userName);
	
	MerchantDto updateMerchant(MerchantDto merchantDto);
	
	String getFullNameByMerchantId(Long merchantId);
	
	List<UserProfileDto> getMerchantProfileSummaryList(UserSearchDto employeeSearchDto);	
	
	UserProfileDto getMerchantByAuthId(Long authId);
	
	UserProfileDto addEmployee(UserProfileDto employeeDto);
	
	UserProfileDto getEmployee(Long employeeId);
	
	UserProfileDto getEmployee(String userName);
	
	UserProfileDto updateEmployee(UserProfileDto employeeDto);

	String getFullNameByEmployeeId(Long employeeId);
	
	UserProfileDto getEmployeeByAuthId(Long authId);
	
	List<UserProfileDto> getEmployeeProfileSummaryList(UserSearchDto employeeSearchDto);
	
	UserProfileDto getEmployeeDetailsByEmployeeId(Long employeeId);
	
	UserProfileDto addEmployee(UserProfileDto employeeDto, Long authId);
	
	UserProfileDto updateEmployee(UserProfileDto employeeDto, Long authId);
	
	UserProfileDto addMerchant(UserProfileDto merchantDto, Long authId);
	
	UserProfileDto getMerchantDetailsByMerchantId(Long merchantId);
	
	UserProfileDto updateMerchant(UserProfileDto merchantDto, Long authId);
	
	void saveMerchantAccount(MerchantAccount merchantAccount);
	
	MerchantAccount updateMerchantAccount(MerchantAccount merchant);
	
	MerchantAccount getMerchantAccountByMerchantId(Long merchantId);
	
	public UserProfileDto getuserDetailsbyauthID(Long authID);
	
	public boolean resetUserPassword(Long authID);	
	
	UserProfileDto getUserProfile(Long authId, Integer category);
	
	UserProfileDto getCustomerDetailsByCustomerId(Long id);
	
}