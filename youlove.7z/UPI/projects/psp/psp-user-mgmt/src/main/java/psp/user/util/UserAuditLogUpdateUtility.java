package psp.user.util;

import psp.constants.PspPortalConstants;
import psp.dto.UserProfileDto;


public class UserAuditLogUpdateUtility implements PspPortalConstants {
	
	public static final String LOGINNAME = "LOGINNAME";
	public static final String NAME = "NAME";
	public static final String EMAIL = "EMAIL";
	public static final String PHONENUMBER = "PHONENUMBER";
	public static final String STATUS = "STATUS";
	public static final String CATEGORY = "CATEGORY";
	public static final String FIRSTNAME = "FIRSTNAME";
	public static final String MIDDLENAME = "MIDDLENAME";
	public static final String LASTNAME = "LASTNAME";
	public static final String DATEOFBIRTH = "DATEOFBIRTH";
	public static final String GENDER = "GENDER";
	public static final String CREATEDBY = "CREATEDBY";
	public static final String ALTERNATEPHONE = "ALTERNATEPHONE";
	public static final String EDUCATION = "EDUCATION";
	
	public static final String ID = "ID";
	public static final String COUNTRY = "COUNTRY";
	public static final String STATE = "STATE";
	public static final String DISTRICT = "DISTRICT";
	public static final String LINE1 = "LINE1";
	public static final String LINE2 = "LINE2";
	public static final String PINCODE = "PINCODE";

	public static final String QUESTION = "QUESTION";
	public static final String ANSWER = "ANSWER";
	
	public static final String ROLENAME = "ROLENAME";
	public static final String ROLEDESCR = "ROLEDESCRIPTION";
	public static final String ACTIONITEM = "ACTIONITEM";


	public static void updateProfiles(UserProfileDto oldObj, UserProfileDto newObj,StringBuilder sb) {

		
		auditLogDataAppending(sb, LOGINNAME, oldObj.getLoginName());
		auditLogDataAppending(oldObj != null ? oldObj.getName() : null, newObj.getName(), sb, NAME);
		auditLogDataAppending(oldObj != null ? oldObj.getEmail() : null, newObj.getEmail(), sb, EMAIL);
		auditLogDataAppending(oldObj != null ? oldObj.getPhoneNumber() : null, newObj.getPhoneNumber(), sb, PHONENUMBER);
		auditLogDataAppending(sb, ID, oldObj.getAuthId());
		auditLogDataAppending(oldObj != null ? oldObj.getFirstName() : null, newObj.getFirstName(), sb, FIRSTNAME);
		auditLogDataAppending(oldObj != null ? oldObj.getMiddleName() : null, newObj.getMiddleName(), sb, MIDDLENAME);
		auditLogDataAppending(oldObj != null ? oldObj.getLastName() : null, newObj.getLastName(), sb, LASTNAME);
		auditLogDataAppending(oldObj != null ? oldObj.getDateOfBirthStr() : null, newObj.getDateOfBirthStr(), sb, DATEOFBIRTH);		
		auditLogDataAppending(oldObj != null ? oldObj.getLine1() : null, newObj.getLine1(), sb, LINE1);
		auditLogDataAppending(oldObj != null ? oldObj.getLine2() : null, newObj.getLine2(), sb, LINE2);
		auditLogDataAppending(oldObj != null ? oldObj.getDistrictName() : null, newObj.getDistrictName(), sb, DISTRICT);		
		auditLogDataAppending(oldObj != null ? oldObj.getStateName() : null, newObj.getStateName(), sb, STATE);
		auditLogDataAppending(oldObj != null ? oldObj.getCountryName() : null, newObj.getCountryName(), sb, COUNTRY);
		auditLogDataAppending(oldObj != null ? oldObj.getPincode() : null, newObj.getPincode(), sb, PINCODE);		
		auditLogDataAppending(oldObj != null ? oldObj.getAltPhoneNumber() : null, newObj.getAltPhoneNumber(), sb, ALTERNATEPHONE);		
		auditLogDataAppending(oldObj != null ? oldObj.getRoleName() : null, newObj.getRoleName(), sb, ROLENAME);
	}
	
	public static boolean auditLogDataComparision(Object oldObj, Object newObj){
		if(oldObj == null && newObj == null){
			return false;
		}
		else if( (oldObj == null && newObj != null) || (oldObj != null && newObj == null) || !newObj.toString().equals(oldObj.toString()) ){
			return true;
		}
		return false;
	}
	
	public static void auditLogDataAppending(Object oldObj, Object newObj, StringBuilder sb, String fieldName){
		if( auditLogDataComparision( oldObj, newObj) ){
			sb.append(fieldName + " " + COLON_STR + COLON_STR + SPACE + 
					oldObj + SPACE + COLON_STR + SPACE + newObj + SEMI_COLON_STR + NEWLINE_CHAR);
		}
	}
	
	public static void auditLogDataAppending(StringBuilder sb, String fieldName, Object data){
		sb.append(fieldName + SPACE + COLON_STR + COLON_STR + SPACE +  data + NEWLINE_CHAR);
	}
	
}