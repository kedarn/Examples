/**
 * 
 */
package psp.user.util;

/**
 * @author prasadj
 *
 */
public interface EmailMessageTemplates {

	String NEW_CUSTOMER_ACTIVATION_SUBJECT = "New User Activation Link";

	String NEW_EMPLOYEE_ACTIVATION_SUBJECT = "New Employee Activation Link";
	
	String NEW_MERCHANT_ACTIVATION_SUBJECT = "New Merchant Activation Link";

	String NEW_USER_ACTIVATION_CONTENT = "Dear {0} <br/> Greetings from the Tarang Team.<br/>This email contains link to generate your password and security question."
			+ " <br/>To access your account, please click on the following link: <br/> <a href>{1}</a> <br/> or copy the link and paste it in your browser's address bar,"
			+ "If you have any questions, please do not hesitate to contact by sending an email to <br/>support@tarangtech.com, or call us at: +91 9999999999.<br/>"
			+ "Thank you, <br/>Tarang Team <br/>www.tarangtech.com ";


	String PASSWORD_ACTIVATION_SUBJECT = "Password Activation Link";

	String PASSWORD_ACTIVATION_CONTENT = "Dear {0} <br/> Greetings from the Tarang Team. <br/> This email contains the link to reset your password. <br/> "
			+ "To access your account, please click on the following link: <br/> {1} <br/> or copy the link and paste it in your browser's address bar, "
			+ "If you have any questions, please do not hesitate to contact by sending an email to <br/> support@tarangtech.com, or call us at: +91 9999999999.<br/>"
			+ "Thank you, <br/>Tarang Team <br/>www.tarangtech.com";

}
