/**
 * 
 */
package psp.user.util;

import java.util.Date;
import java.util.Timer;
import java.util.TimerTask;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.context.WebApplicationContext;
import org.springframework.web.context.support.WebApplicationContextUtils;

import psp.common.PropertyReader;
import psp.constants.AuthStatusCode;
import psp.constants.PropertyName;
import psp.dbservice.mgmt.PspMgmtService;
import psp.dbservice.model.Authentication;
import psp.dbservice.util.DbServiceUtil;

/**
 * @author manasp
 *
 */
public class AutoUnlockUserTimerTask extends TimerTask {

	private static final Logger LOGGER = Logger.getLogger(AutoUnlockUserTimerTask.class.getName());
	
	
	private PropertyReader propertyReader;
	private Timer timer;
	private String loginId ;
	private Date lastloginAttemptTime;
	private boolean isStarted=false;
	private PspMgmtService pspMgmtService;
	 
	
	public  AutoUnlockUserTimerTask(String loginId,Date lastloginAttemptTime,PspMgmtService pspMgmtService ,PropertyReader propertyReader ) {
		this.loginId=loginId;
		this.lastloginAttemptTime=lastloginAttemptTime;
		this.pspMgmtService=pspMgmtService;
		this.propertyReader=propertyReader;
	}
	

	@Override
	public void run() {
		LOGGER.info("Time taken " +(System.currentTimeMillis()-lastloginAttemptTime.getTime()) +  " ms");
		LOGGER.info("Last passowd Attempt failed time for user " + loginId + " is at "  + lastloginAttemptTime +  " ,  Auto Unlock  Timer task started at:" + new Date());
		try {
			Authentication authentication = pspMgmtService.getAuthentication(loginId);
			authentication.setPwAttempts(0);
			authentication.setPwdStatus(AuthStatusCode.ACTIVE.getValue());
			pspMgmtService.updateAuthentication(DbServiceUtil.getAuthenticationDto(authentication));
		}
		catch (Exception e) {
			LOGGER.warn(e.getMessage());
			LOGGER.debug(e.getMessage(), e);
		}
		LOGGER.info("Auto Unlock Timer task finished for user: " +  loginId   + " at" + new Date());
	}


	
	public void startTimer(){
		isStarted=true;
	        timer = new Timer(true);
	        Date unlockDate =  new Date(lastloginAttemptTime.getTime() + (1000*60*60* Integer.parseInt(propertyReader.getValue(PropertyName.USER_AUTOUNLOCK_HOURS))));
	        System.out.println(lastloginAttemptTime.getTime());
	        //Date unlockDate =  new Date(lastloginAttemptTime.getTime() + 1*60*1000);
	        timer.schedule(this, unlockDate); 
	        //timer.scheduleAtFixedRate(this, START_UP_DELAY, START_UP_DELAY); 
	        LOGGER.info("AutoUnlock User TimerTask  scheduled .........for User :" + loginId + "at " + unlockDate);
		
	}
	
	public void stopTimer(){
		if(isStarted){
			timer.cancel();
			LOGGER.info("Auto unlock user Timer stoped...........");
			isStarted = false;
		}
		else {
			LOGGER.info("Auto unlock user Timer stoped already stoped.....");
		}
	}
	
}