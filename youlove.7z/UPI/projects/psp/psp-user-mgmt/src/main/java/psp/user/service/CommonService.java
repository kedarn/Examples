/**
 * 
 */
package psp.user.service;

import java.util.List;

import psp.common.exception.ApplicationException;
import psp.common.model.CustomerBillSummary;
import psp.common.model.TransactionSumary;
import psp.dbservice.model.BillMappingDetails;
import psp.dbservice.model.CustomerDetails;
import psp.dto.AddressDto;
import psp.dto.AuditLogDto;
import psp.dto.AuditLogSearchDto;
import psp.dto.AuthenticationDto;
import psp.dto.AuthorizationDto;
import psp.dto.BillpayerSearchDto;
import psp.dto.SecurityQuestionDto;
import psp.dto.TransactionSearchDto;
import psp.dto.UserSearchDto;
import psp.mobile.model.response.MerchantDetails;

/**
 * @author prasadj
 *
 */
public interface CommonService {

	List<SecurityQuestionDto> getSecurityQuestions();

	AddressDto getAddressDtoById(Long id);

	void saveAddress(AddressDto address);

	void updateAddress(AddressDto address);

	String getSecurityQuestion(Long id);

	List<AuthorizationDto> getAuthorizationList();

	AuthenticationDto getAuthenticationDtoById(Long id);

	AuthenticationDto getAuthenticationByLoginName(String name);

	Long saveBillMappingDetails(BillMappingDetails billMappingDetails);

	List<MerchantDetails> getCustomerAddedMerchants(UserSearchDto searchdto, String userName);

	List<MerchantDetails> getCustomerNotAddedMerchants(String userName);

	List<CustomerBillSummary> getCustomerBillSummariesByMerchantId(
			Long merchantId);

	MerchantDetails getMerchantSummaryByMerchantId(Long merchantId);

	BillMappingDetails getBillMappingDetailsByIdentification(
			String identification);

	List<CustomerBillSummary> searchBillSummarydetails(
			BillpayerSearchDto billpayerSearchDto);

	List<TransactionSumary> searchTransactiondetails(
			TransactionSearchDto transactionSearchDto);


	void updateSecurityQuestions(Long questionId, String answer, Long authId);

	boolean changePassword(String oldPassword, String newPassword, String userName) throws ApplicationException;
	
	List<CustomerDetails> getMerchantAssociatedCustomers(UserSearchDto SearchDto ,Long id);

	void addAuditLog(AuditLogDto dto);
		
	List<AuditLogDto> getAuditLogs(AuditLogSearchDto searchDto);
	
	MerchantDetails getMerchantDetailsByMerchantId(Long merchantId);
}
