/**
 * 
 */
package psp.user.dao.impl;

import org.springframework.stereotype.Component;

import psp.user.dao.LoginDao;

/**
 * @author prasadj
 *
 */
@Component
public class LoginDaoImpl implements LoginDao {


	public LoginDaoImpl(){
	}


	
}