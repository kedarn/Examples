/**
 * 
 */
package psp.user.dao;

import java.util.List;

import psp.common.model.CustomerBillSummary;
import psp.common.model.TransactionSumary;
import psp.dbservice.model.Address;
import psp.dbservice.model.AuditLog;
import psp.dbservice.model.BillMappingDetails;
import psp.dbservice.model.CustomerDetails;
import psp.dto.AddressDto;
import psp.dto.AuditLogDto;
import psp.dto.AuditLogSearchDto;
import psp.dto.AuthorizationDto;
import psp.dto.BillpayerSearchDto;
import psp.dto.SecurityQuestionDto;
import psp.dto.TransactionSearchDto;
import psp.dto.UserSearchDto;
import psp.mobile.model.response.MerchantDetails;

/**
 * @author prasadj
 *
 */
public interface CommonDao {

	List<SecurityQuestionDto> getSecurityQuestions();
	
	Address getAddressById(Long id);

	AddressDto getAddressDtoById(Long id);

	void saveAddress(Address address);
	
	void updateAddress(Address address);
	
	String getSecurityQuestion(Long id);
	
	List<AuthorizationDto> getAuthorizationList();
	
	Long saveBillMappingDetails(BillMappingDetails billMappingDetails);
	
	List<MerchantDetails> getCustomerAddedMerchants(UserSearchDto searchdto, String userName);
	
	List<MerchantDetails> getCustomerNotAddedMerchants(String userName);
	
	List<CustomerBillSummary> getCustomerBillSummariesByMerchantId(Long merchantId);
	
	MerchantDetails getMerchantSummaryByMerchantId(Long merchantId);
	
	BillMappingDetails getBillMappingDetailsByIdentification(String identification);
	
    List<CustomerBillSummary> searchBillSummarydetails(BillpayerSearchDto billpayerSearchDto);
    
    List<TransactionSumary> searchTransactiondetails(TransactionSearchDto transactionSearchDto);

	List<CustomerDetails> getMerchantAssociatedCustomers(UserSearchDto SearchDto, Long id);
    
	void addAuditLog(AuditLog model);
	
	List<AuditLogDto> getAuditLogs(AuditLogSearchDto searchDto);
	
	MerchantDetails getMerchantDetailsByMerchantId(Long merchantId);
	
}
