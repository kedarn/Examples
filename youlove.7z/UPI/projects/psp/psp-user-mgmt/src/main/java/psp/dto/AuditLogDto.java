package psp.dto;

import java.util.Date;

import psp.constants.DateUtil;
import psp.constants.PortalModule;
import psp.constants.PortalOperations;

public class AuditLogDto {

	private Long id;
	
	private Long authId;

	private Long recordId;
	
	private Integer module;
	
	private String moduleStr;

	private PortalOperations operation;
	
	private String operationStr;

	private Date logDate;
	
	private String logDateStr;

	private Integer srno;
	
	private String info;
	
	public AuditLogDto(){
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public Long getAuthId() {
		return authId;
	}

	public void setAuthId(Long authId) {
		this.authId = authId;
	}

	public Long getRecordId() {
		return recordId;
	}

	public void setRecordId(Long recordId) {
		this.recordId = recordId;
	}

	public Integer getModule() {
		return module;
	}

	public void setModule(Integer module) {
		this.module = module;
		if(module != null){
			this.moduleStr = PortalModule.getPortalModule(module).getName();
		}
		else{
			this.moduleStr = "";
		}
	}
	
	public String getModuleStr() {
		return moduleStr;
	}

	public void setModuleStr(String moduleStr) {
		this.moduleStr = moduleStr;
	}
	
	public PortalOperations getOperation() {
		return operation;
	}

	public void setOperation(PortalOperations operation) {
		this.operation = operation;
		if( operation != null ){
			this.operationStr = operation.getName();
		}
		else{
			this.operationStr = "";
		}
	}

	public String getOperationStr() {
		return operationStr;
	}

	public void setOperationStr(String operationStr) {
		this.operationStr = operationStr;
	}

	public Date getLogDate() {
		return logDate;
	}

	public void setLogDate(Date logDate) {
		this.logDate = logDate;
		if( logDate != null){
			this.logDateStr = DateUtil.convertDateToTimeString(logDate);
		}
		else{
			this.logDateStr = "";
		}
	}

	public String getLogDateStr() {
		return logDateStr;
	}

	public void setLogDateStr(String logDateStr) {
		this.logDateStr = logDateStr;
	}

	public Integer getSrno() {
		return srno;
	}

	public void setSrno(Integer srno) {
		this.srno = srno;
	}

	public String getInfo() {
		return info;
	}

	public void setInfo(String info) {
		this.info = info;
	}
}
