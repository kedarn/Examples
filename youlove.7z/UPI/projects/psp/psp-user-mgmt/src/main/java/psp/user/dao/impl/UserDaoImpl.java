/**
 * 
 */
package psp.user.dao.impl;

import java.util.List;

import javax.inject.Inject;

import org.springframework.orm.hibernate4.HibernateTemplate;
import org.springframework.stereotype.Component;

import psp.constants.CategoryCode;
import psp.dbservice.model.Address;
import psp.dbservice.model.CustomerDetails;
import psp.dbservice.model.Employee;
import psp.dbservice.model.MerchantAccount;
import psp.dbservice.model.MerchantUser;
import psp.dbservice.model.PasswordHistory;
import psp.dto.AddressDto;
import psp.dto.UserProfileDto;
import psp.dto.UserSearchDto;
import psp.user.dao.QueryConstruction;
import psp.user.dao.UserDao;

/**
 * @author prasadj
 *
 */
@SuppressWarnings({"unchecked"})
@Component
public class UserDaoImpl implements UserDao {

	@Inject
	private HibernateTemplate hibernateTemplate;

	@Inject
	private QueryConstruction queryConstruction;

	public UserDaoImpl(){
	}

	@Override
	public AddressDto getAdressDeatsils(Long addrId) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void saveAdressDeatsils(Address address) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void updateAdressDeatsils(Address address) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public String getFullNameByCustomerId(Long customerId) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<UserProfileDto> getCustomerProfileSummaryList(UserSearchDto customerSearchDto) {
		return (List<UserProfileDto>)hibernateTemplate.find( queryConstruction.getCustomerSummarySearch(customerSearchDto) );
	}

	@Override
	public Employee getEmployeeByEmployeeId(Long employeeId) {
		return hibernateTemplate.get(Employee.class, employeeId);
	}

	@Override
	public Employee getEmployeeByAuthId(Long authId) {
		List<Employee> empList = (List<Employee>) hibernateTemplate.findByNamedQuery("getEmployeeByAuthId", authId);
		Employee employee = null;
		if(empList != null && !empList.isEmpty()){
			employee = empList.get(0);
		}
		return employee;
	}

	@Override
	public void saveEmployee(Employee employee) {
		hibernateTemplate.save(employee);
	}

	@Override
	public void updateEmployee(Employee employee) {
		hibernateTemplate.update(employee);		
	}

	@Override
	public String getFullNameByEmployeeId(Long employeeId) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<UserProfileDto> getEmployeeProfileSummaryList(UserSearchDto employeeSearchDto) {
		return (List<UserProfileDto>)hibernateTemplate.find( queryConstruction.getEmployeeSummarySearch(employeeSearchDto) );
	}

	@Override
	public MerchantUser getMerchantByMerchantId(Long merchantId) {
		return hibernateTemplate.get(MerchantUser.class, merchantId);
	}

	@Override
	public MerchantUser getMerchantByAuthId(Long authId) {
		List<MerchantUser> merchantUserList = (List<MerchantUser>) hibernateTemplate.findByNamedQuery("getMerchantByAuthId", authId);
		MerchantUser merchant = null;
		if(merchantUserList != null && !merchantUserList.isEmpty()){
			merchant = merchantUserList.get(0);
		}
		return merchant;
	}

	@Override
	public void saveMerchant(MerchantUser merchant) {
		hibernateTemplate.save(merchant);
	}

	@Override
	public void updateMerchant(MerchantUser merchant) {
		hibernateTemplate.update(merchant);
		
	}

	@Override
	public String getFullNameByMerchantId(Long merchantId) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<UserProfileDto> getMerchantProfileSummaryList(UserSearchDto merchantSearchDto) {
		return (List<UserProfileDto>)hibernateTemplate.find( queryConstruction.getMerchantSummarySearch(merchantSearchDto) );
	}

	@Override
	public String getFullNameByAuthId(Long authId) {
		List<Integer> categoryList = (List<Integer>) hibernateTemplate.findByNamedQuery("getUserTypeByAuthId", authId);
		Integer category = null;
		if(categoryList != null && !categoryList.isEmpty()){
			category = categoryList.get(0);
		}
		if(category != null){
			String queryId = null;
			if(category == CategoryCode.CUSTOMER.getValue()){
				queryId = "getCustomerFullNameByAuthId"; // TODO
			}
			else {
				queryId = "getMerchantFullNameByAuthId";
			}
			List<String> names = (List<String>) hibernateTemplate.findByNamedQuery(queryId, authId);
			if(!names.isEmpty()){
				return names.get(0);
			}
		}
		return null;
	}

	@Override
	public List<PasswordHistory> getPasswordHistory(Long authId) {
		return (List<PasswordHistory>) hibernateTemplate.findByNamedQuery("getPasswordHistory", authId);
	}

	@Override
	public void deletePasswordHistory(PasswordHistory ph) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void createPasswordHistory(PasswordHistory ph) {
		hibernateTemplate.save(ph);
		
	}

	@Override
	public void saveMerchantAccount(MerchantAccount merchantAccount) {
		hibernateTemplate.save(merchantAccount);
	}

	@Override
	public void updateMerchantAccount(MerchantAccount merchant) {
		hibernateTemplate.update(merchant);
	}

	@Override
	public MerchantAccount getMerchantAccountByMerchantId(Long merchantId) {
		List<MerchantAccount> merchantAccList = (List<MerchantAccount>) hibernateTemplate.findByNamedQuery("getMerchantAccountByMerchantId", merchantId);
		MerchantAccount merchant = null;
		if(merchantAccList != null && !merchantAccList.isEmpty()){
			merchant = merchantAccList.get(0);
		}
		return merchant;
	}
	
	@Override
	public CustomerDetails getCustomerDetailsbyauthId(Long authID) {
		List<CustomerDetails> customerdetailslist = (List<CustomerDetails>) hibernateTemplate.findByNamedQuery("getUserDetailsByAuthId", authID);
		CustomerDetails customerDto = null;
		if(customerdetailslist != null && !customerdetailslist.isEmpty()){
			customerDto = customerdetailslist.get(0);
		}
		return customerDto;
	}

	@Override
	public void updateCustomer(CustomerDetails customer) {
		hibernateTemplate.update(customer);	
	}

	@Override
	public CustomerDetails getCustomerByCustomerId(Long customerId) {
		return hibernateTemplate.get(CustomerDetails.class, customerId);
	}

}