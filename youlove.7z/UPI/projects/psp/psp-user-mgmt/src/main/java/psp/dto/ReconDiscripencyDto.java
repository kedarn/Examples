package psp.dto;

import java.io.Serializable;

public class ReconDiscripencyDto implements Serializable {

	private static final long serialVersionUID = 1L;

	private String discripencyTypeId;
	private String expectedValue;
	private String receivedValue;
	private String actionTaken;
	private String bankReconTxnId;
	private String rdId;
	private String reconHistoryId;
	private String createdDate;
	private String comments;
	private Long lookUpId;
	private String txnId;
	private String mid;
	private Long errorCode;
	private String errorMsg;

	public String getTxnId() {
		return txnId;
	}

	public void setTxnId(String txnId) {
		this.txnId = txnId;
	}

	public String getMid() {
		return mid;
	}

	public void setMid(String mid) {
		this.mid = mid;
	}

	public Long getLookUpId() {
		return lookUpId;
	}
	
	public void setLookUpId(Long lookUpId) {
		this.lookUpId = lookUpId;
	}

	public String getRdId() {
		return rdId;
	}
	
	public void setRdId(String rdId) {
		this.rdId = rdId;
	}

	public String getReconHistoryId() {
		return reconHistoryId;
	}

	public void setReconHistoryId(String reconHistoryId) {
		this.reconHistoryId = reconHistoryId;
	}

	public String getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(String createdDate) {
		this.createdDate = createdDate;
	}

	public String getDiscripencyTypeId() {
		return discripencyTypeId;
	}

	public void setDiscripencyTypeId(String discripencyTypeId) {
		this.discripencyTypeId = discripencyTypeId;
	}

	public String getExpectedValue() {
		return expectedValue;
	}

	public void setExpectedValue(String expectedValue) {
		this.expectedValue = expectedValue;
	}
	
	public String getReceivedValue() {
		return receivedValue;
	}
	
	public void setReceivedValue(String receivedValue) {
		this.receivedValue = receivedValue;
	}
	
	public String getActionTaken() {
		return actionTaken;
	}

	public void setActionTaken(String actionTaken) {
		this.actionTaken = actionTaken;
	}

	public String getBankReconTxnId() {
		return bankReconTxnId;
	}

	public void setBankReconTxnId(String bankReconTxnId) {
		this.bankReconTxnId = bankReconTxnId;
	}

	public Long getErrorCode() {
		return errorCode;
	}

	public void setErrorCode(Long errorCode) {
		this.errorCode = errorCode;
	}

	public String getErrorMsg() {
		return errorMsg;
	}

	public void setErrorMsg(String errorMsg) {
		this.errorMsg = errorMsg;
	}

	public void setComments(String comments) {
		this.comments = comments;
	}

	public String getComments() {
		return comments;
	}

}