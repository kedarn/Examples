/**
 * 
 */
package psp.dto;

import java.io.Serializable;

/**
 * @author prasadj
 *
 */
public class CustBillSumaryDto implements Serializable {

	private static final long serialVersionUID = 1L;

	private String customerName;
	
	private double amount;
	
	private String identification;
	
	private int billDate;

	private String billDateStr;

	private int notificationDate;
	
	private String notificationDateStr;

	private int notificationExpDate;
	
	private String notificationExpDateStr;

	private int expDate;
	
	private String expDateStr;
	
	private String virtualAddr;
	private String id;
	
	public CustBillSumaryDto(){
	}

	public String getCustomerName() {
		return customerName;
	}

	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}

	public double getAmount() {
		return amount;
	}

	public void setAmount(double amount) {
		this.amount = amount;
	}

	public String getIdentification() {
		return identification;
	}

	public void setIdentification(String identification) {
		this.identification = identification;
	}

	public int getBillDate() {
		return billDate;
	}

	public void setBillDate(int billDate) {
		this.billDate = billDate;
	}

	public String getBillDateStr() {
		return billDateStr;
	}

	public void setBillDateStr(String billDateStr) {
		this.billDateStr = billDateStr;
	}

	public int getNotificationDate() {
		return notificationDate;
	}

	public void setNotificationDate(int notificationDate) {
		this.notificationDate = notificationDate;
	}

	public String getNotificationDateStr() {
		return notificationDateStr;
	}

	public void setNotificationDateStr(String notificationDateStr) {
		this.notificationDateStr = notificationDateStr;
	}

	public int getNotificationExpDate() {
		return notificationExpDate;
	}

	public void setNotificationExpDate(int notificationExpDate) {
		this.notificationExpDate = notificationExpDate;
	}

	public String getNotificationExpDateStr() {
		return notificationExpDateStr;
	}

	public void setNotificationExpDateStr(String notificationExpDateStr) {
		this.notificationExpDateStr = notificationExpDateStr;
	}

	public int getExpDate() {
		return expDate;
	}

	public void setExpDate(int expDate) {
		this.expDate = expDate;
	}

	public String getExpDateStr() {
		return expDateStr;
	}

	public void setExpDateStr(String expDateStr) {
		this.expDateStr = expDateStr;
	}

	public String getVirtualAddr() {
		return virtualAddr;
	}

	public void setVirtualAddr(String virtualAddr) {
		this.virtualAddr = virtualAddr;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}
	
}