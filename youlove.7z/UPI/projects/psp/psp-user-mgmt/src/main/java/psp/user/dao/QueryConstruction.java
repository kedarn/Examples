/**
 * 
 */
package psp.user.dao;

import psp.dto.BillpayerSearchDto;
import psp.dto.RoleSearchDto;
import psp.dto.TransactionSearchDto;
import psp.dto.UserSearchDto;

/**
 * @author prasadj
 *
 */
public interface QueryConstruction {

	String getMerchantSummarySearch(UserSearchDto userSearchDto );
		
	String getEmployeeSummarySearch(UserSearchDto userSearchDto );
	
	String getCustomerSummarySearch(UserSearchDto userSearchDto);

	String getCustomerBillSummarySearch(BillpayerSearchDto billpayerSearchDto);
	
	String  searchTransactiondetails(TransactionSearchDto  transactionSearchDto );
	
	 String getRoleSummarySearch(RoleSearchDto dto);
	 
	 String getMerchantAssociatedCustomersSearch(UserSearchDto userSearchDto,Long id);
	 
	 String getCustomerAddedMerchantsearch(UserSearchDto userSearchDto,String userName);
	 
	 
}