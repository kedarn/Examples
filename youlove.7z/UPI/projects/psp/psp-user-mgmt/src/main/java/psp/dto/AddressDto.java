/**
 * 
 */
package psp.dto;

import java.io.Serializable;

/**
 * @author prasadj
 *
 */
public class AddressDto implements Serializable {

	private static final long serialVersionUID = 1L;

	private Long id;
	
	private String line1;
	
	private String line2;
	
	private String country;
	
	private String state;
	
	private String district;
	
	private String pinCode;
	
	public AddressDto(){
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getLine1() {
		return line1;
	}

	public void setLine1(String line1) {
		this.line1 = line1;
	}

	public String getLine2() {
		return line2;
	}

	public void setLine2(String line2) {
		this.line2 = line2;
	}

	public String getCountry() {
		return country;
	}

	public void setCountry(String country) {
		this.country = country;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public String getDistrict() {
		return district;
	}

	public void setDistrict(String district) {
		this.district = district;
	}

	public String getPinCode() {
		return pinCode;
	}

	public void setPinCode(String pinCode) {
		this.pinCode = pinCode;
	}

}