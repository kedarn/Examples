package psp.user.service.impl;

import java.text.MessageFormat;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import psp.common.PropertyReader;
import psp.constants.AuthStatusCode;
import psp.constants.CommonConstants;
import psp.constants.StatusCode;
import psp.constants.UserStatus;
import psp.dbservice.dao.PspDao;
import psp.dbservice.model.Authentication;
import psp.dbservice.model.CustomerDetails;
import psp.dto.ForgetPasswordDto;
import psp.dto.SecurityQuestionDto;
import psp.notification.model.EmailMessage;
import psp.notification.service.EmailService;
import psp.user.dao.CommonDao;
import psp.user.dao.UserDao;
import psp.user.service.ForgetPasswordService;
import psp.user.util.EmailMessageTemplates;

@Component("forgetPasswordService")
@Transactional (rollbackFor=Exception.class)
public class ForgetPasswordServiceImpl implements ForgetPasswordService, CommonConstants {

	@Autowired
	private PspDao pspDao;
	
	@Autowired
	private CommonDao commonDao;
	
	@Autowired
	private PropertyReader propertyReader;
	
	@Autowired
	private EmailService emailService;
	
	@Autowired
	private UserDao userDao;
	
	@Override
	public ForgetPasswordDto sendSequrityQuestions(String userName) {
		ForgetPasswordDto forgetPasswordDto = new ForgetPasswordDto();
		Authentication authentication = pspDao.getAuthenticationByLoginName(userName);
		if(null != authentication) {
			if(UserStatus.SUSPEND.getValue() == authentication.getUserStatus()) {
				forgetPasswordDto.setMessage(StatusCode.CONTACT_ADMIN_MSG.getCode());
			}
			else {
				if(null != authentication.getQuestionId() && null != authentication.getAnswer()){
					if(AuthStatusCode.RESET.getValue() == authentication.getPwdStatus()) {
						forgetPasswordDto.setMessage(StatusCode.RESEND_RESET_LINK_MSG.getCode());
					}
					else {
						List<SecurityQuestionDto> securityQuestions = commonDao.getSecurityQuestions();
						List<String> questions = new ArrayList<String>();
						if(null != securityQuestions) {
							for(SecurityQuestionDto question: securityQuestions) {
								questions.add(question.getQuestion());
							}
						}
						forgetPasswordDto.setSecurityQuestions(questions);
					}
				}
				else {
					forgetPasswordDto.setMessage(StatusCode.CONTACT_ADMIN_MSG.getCode());
				}
			}
		}
		else {
			forgetPasswordDto.setMessage(StatusCode.USER_IS_NOT_REGISTERED.getCode());
		}
		return forgetPasswordDto;
	}

	@Override
	public ForgetPasswordDto resendPasswordLink(String userName) {
		ForgetPasswordDto forgetPasswordDto = new ForgetPasswordDto();
		Authentication authentication = pspDao.getAuthenticationByLoginName(userName);
		if(null != authentication) {
			if(UserStatus.SUSPEND.getValue() == authentication.getUserStatus()) {
				forgetPasswordDto.setMessage(StatusCode.CONTACT_ADMIN_MSG.getCode());
			}
			else {
				if(AuthStatusCode.RESET.getValue() == authentication.getPwdStatus()) {
						CustomerDetails customerDetails = pspDao.getUserByName(userName);
					 	String email = customerDetails.getEmail();
						String url = propertyReader.getChangePwdUrl();
						String fullName = userDao.getFullNameByAuthId(authentication.getId());
						String subject = "Customer Activation Link";
						String url_link = url + CUSTOMERPATH + NEW_CUSTOMER + QUESTION_MARK + CODE + EQUAL_SYMBOL + authentication.getNewUserCode();
						String messageBody = MessageFormat.format(EmailMessageTemplates.NEW_USER_ACTIVATION_CONTENT, fullName, url_link);
						EmailMessage emailMessage = new EmailMessage(email, messageBody, subject);
						emailService.sendEmail(emailMessage);
				}
				else {
					forgetPasswordDto.setMessage(StatusCode.NOT_IN_RESET_STATE.getCode());
				}
			}
		}
		else {
			forgetPasswordDto.setMessage(StatusCode.USER_IS_NOT_REGISTERED.getCode());
		}
		return forgetPasswordDto;
	}

	@Override
	public ForgetPasswordDto sendPasswordLink(String userName, String reqque, String answer) {
		ForgetPasswordDto forgetPasswordDto = new ForgetPasswordDto();
		Authentication authentication = pspDao.getAuthenticationByLoginName(userName);
		if(null != authentication) {
			if(UserStatus.SUSPEND.getValue() == authentication.getUserStatus()) {
				forgetPasswordDto.setMessage(StatusCode.CONTACT_ADMIN_MSG.getCode());
			}
			else {
				String question = commonDao.getSecurityQuestion(authentication.getQuestionId());
				if(question.equals(reqque) && authentication.getAnswer().equals(answer)) {
						CustomerDetails customerDetails = pspDao.getUserByName(userName);
					 	String email = customerDetails.getEmail();
						String url = propertyReader.getChangePwdUrl();
						String fullName = userDao.getFullNameByAuthId(authentication.getId());
						String subject = "Customer Activation Link";
						String url_link = url + CUSTOMERPATH + NEW_CUSTOMER + QUESTION_MARK + CODE + EQUAL_SYMBOL + authentication.getNewUserCode();
						String messageBody = MessageFormat.format(EmailMessageTemplates.NEW_USER_ACTIVATION_CONTENT, fullName, url_link);
						EmailMessage emailMessage = new EmailMessage(email, messageBody, subject);
						emailService.sendEmail(emailMessage);	
				}
				else {
					forgetPasswordDto.setMessage(StatusCode.INVALID_QUESTION_OR_ANSWER.getCode());
				}
		  }
		}
		else {
			forgetPasswordDto.setMessage(StatusCode.USER_IS_NOT_REGISTERED.getCode());
		}
		return forgetPasswordDto;
	}

}
