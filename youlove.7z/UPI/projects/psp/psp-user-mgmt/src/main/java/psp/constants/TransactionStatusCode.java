/**
 * 
 */
package psp.constants;


/**
 * @author hemanthk
 *
 */
public enum TransactionStatusCode {
	
	
	INITIATED(1,"INITIATED"),
	FAILED(2,"FAILED"),
	COMPLETED(3,"COMPLETED");
	
	
	private final int value;
	
	private final String name;
	
	private TransactionStatusCode(int value, String name) {
		this.value = value;
		this.name = name;
	}

	public int getValue() {
		return value;
	}
	
	public String getName() {
		return name;
	}

	public static TransactionStatusCode getStatus(int value){
		if(INITIATED.value == value){
			return INITIATED;
		}
		else if(COMPLETED.value == value){
			return COMPLETED;
		}
		else if(FAILED.value == value){
			return FAILED;
		}
		else {
			return null;
		}
	}
}
