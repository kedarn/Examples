/**
 * 
 */
package psp.user.service.impl;

import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import psp.common.exception.ApplicationException;
import psp.common.model.CustomerBillSummary;
import psp.common.model.TransactionSumary;
import psp.common.passencrypt.PasswordEncryptor;
import psp.constants.AuthStatusCode;
import psp.constants.CommonConstants;
import psp.constants.PspPortalConstants;
import psp.constants.StatusCode;
import psp.constants.UserConstants;
import psp.dbservice.dao.PspDao;
import psp.dbservice.model.AuditLog;
import psp.dbservice.model.Authentication;
import psp.dbservice.model.BillMappingDetails;
import psp.dbservice.model.CustomerDetails;
import psp.dbservice.model.PasswordHistory;
import psp.dto.AddressDto;
import psp.dto.AuditLogDto;
import psp.dto.AuditLogSearchDto;
import psp.dto.AuthenticationDto;
import psp.dto.AuthorizationDto;
import psp.dto.BillpayerSearchDto;
import psp.dto.SecurityQuestionDto;
import psp.dto.TransactionSearchDto;
import psp.dto.UserSearchDto;
import psp.mobile.model.response.MerchantDetails;
import psp.user.dao.CommonDao;
import psp.user.dao.RoleDao;
import psp.user.dao.UserDao;
import psp.user.service.CommonService;

/**
 * @author prasadj
 *
 */
@Component("commonService")
@Transactional (rollbackFor=Exception.class)
public class CommonServiceImpl implements CommonService {

	@Autowired
	private CommonDao commonDao;

	@Autowired
	private PspDao pspDao;

	@Autowired
	private RoleDao roleDao;
	
	@Autowired
	private UserDao userDao;
	
	@Override
	public List<SecurityQuestionDto> getSecurityQuestions() {
		return commonDao.getSecurityQuestions();
	}

	@Override
	public AddressDto getAddressDtoById(Long id) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void saveAddress(AddressDto address) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void updateAddress(AddressDto address) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public String getSecurityQuestion(Long id) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<AuthorizationDto> getAuthorizationList() {
		return commonDao.getAuthorizationList();
	}

	@Override
	public AuthenticationDto getAuthenticationDtoById(Long id) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public AuthenticationDto getAuthenticationByLoginName(String name) {
		// TODO Auto-generated method stub
		return null;
	}
	
	@Override
	public Long saveBillMappingDetails(BillMappingDetails billMappingDetails) {
		return commonDao.saveBillMappingDetails(billMappingDetails);
	}

	@Override
	public List<MerchantDetails> getCustomerAddedMerchants(UserSearchDto searchdto, String userName) {
		return commonDao.getCustomerAddedMerchants(searchdto, userName);
	}

	@Override
	public List<MerchantDetails> getCustomerNotAddedMerchants(String userName) {
		return commonDao.getCustomerNotAddedMerchants(userName);
	}

	@Override
	public List<CustomerBillSummary> getCustomerBillSummariesByMerchantId(Long merchantId) {
		return commonDao.getCustomerBillSummariesByMerchantId(merchantId);
	}

	@Override
	public MerchantDetails getMerchantSummaryByMerchantId(Long merchantId) {
		return commonDao.getMerchantSummaryByMerchantId(merchantId);
	}

	@Override
	public BillMappingDetails getBillMappingDetailsByIdentification(String identification) {
		return commonDao.getBillMappingDetailsByIdentification(identification);
	}
	
	@Override
	public List<CustomerBillSummary> searchBillSummarydetails(BillpayerSearchDto billpayerSearchDto) {
		return commonDao.searchBillSummarydetails(billpayerSearchDto);
	}
	
	@Override
	public List<TransactionSumary> searchTransactiondetails(TransactionSearchDto transactionSearchDto){
		return commonDao.searchTransactiondetails(transactionSearchDto);
	}

	@Override
	public void updateSecurityQuestions(Long questionId, String answer, Long authId) {
		Authentication authentication = pspDao.getAuthenticationById(authId);
		if(authentication != null){
			authentication.setQuestionId(questionId);
			authentication.setAnswer(answer);
			pspDao.updateAuthentication(authentication);
		}
		
	}

	@Override
	public boolean changePassword(String oldPassword, String newPassword, String userName) throws ApplicationException {
		Authentication authentication = pspDao.getAuthenticationByLoginName(userName);
		if (authentication != null) {
			if (oldPassword!=null && PasswordEncryptor.checkPassword(oldPassword, authentication.getPassword())) {
				List<PasswordHistory> phs = userDao.getPasswordHistory(authentication.getId());
				if(phs != null && !phs.isEmpty()){
					for(PasswordHistory ph: phs) {
						if(PasswordEncryptor.checkPassword(newPassword, ph.getPassword())){
							throw new ApplicationException(StatusCode.NEW_PASWORD_ALREADY_USED);
						}
					}
				}
				PasswordHistory newPh = new PasswordHistory();
				newPh.setAuthId(authentication.getId());
				newPh.setPassword(PasswordEncryptor.encrypt(newPassword));
				newPh.setCreationDate(new Date());
				userDao.createPasswordHistory(newPh);
				
				authentication.setPassword(PasswordEncryptor.encrypt(newPassword));
				authentication.setPwAttempts(UserConstants.DEFAULT_ATTEMPTS);
				authentication.setLastLoginTime(new Date());
				pspDao.updateAuthentication(authentication);
				
				return true;
			}	 else if(oldPassword==null){// This is Reset password page.
				
				List<PasswordHistory> phs = userDao.getPasswordHistory(authentication.getId());
				if(phs != null && !phs.isEmpty()){
					for(PasswordHistory ph: phs) {
						if(PasswordEncryptor.checkPassword(newPassword, ph.getPassword())){
							throw new ApplicationException(StatusCode.NEW_PASWORD_ALREADY_USED);
						}
					}
				}
				PasswordHistory newPh = new PasswordHistory();
				newPh.setAuthId(authentication.getId());
				newPh.setPassword(PasswordEncryptor.encrypt(newPassword));
				newPh.setCreationDate(new Date());
				userDao.createPasswordHistory(newPh);
				
				authentication.setPassword(PasswordEncryptor.encrypt(newPassword));
				authentication.setPwAttempts(UserConstants.DEFAULT_ATTEMPTS);
				authentication.setPwdStatus(AuthStatusCode.ACTIVE.getValue());
				authentication.setLastLoginTime(new Date());
				authentication.setNewUserCode(CommonConstants.EMPTY_STR);
				pspDao.updateAuthentication(authentication);
				
				return true;
			}else {
				if (authentication.getPwAttempts() < UserConstants.MAX_PWD_ATTEMPTS) {
					Integer pwAttempts = authentication.getPwAttempts() + 1;
					authentication.setPwAttempts(pwAttempts);
					if (pwAttempts == UserConstants.MAX_PWD_ATTEMPTS) {
						authentication.setPwdStatus(AuthStatusCode.LOCKED.getValue());
						pspDao.updateAuthentication(authentication);
						return false;
					}
					pspDao.updateAuthentication(authentication);
				}
			}
		} else {
			return false;
		}
		return false;
	}

	@Override
	public List<CustomerDetails> getMerchantAssociatedCustomers(UserSearchDto SearchDto, Long id) {
		return commonDao.getMerchantAssociatedCustomers(SearchDto,id);
	}
	
	@Override
	public void addAuditLog(AuditLogDto dto) {
		String info = dto.getInfo();
		Date date = new Date();
		Integer srno = null;
		int i = 1;
		while ( info.length() > 2000 ){
			String subinfo = info.substring(0, 1980) + "...Continue";
			info = info.substring(1980);
			commonDao.addAuditLog(updateAuditLog( date, subinfo, i, dto));
			srno = ++i;
		}
		
		commonDao.addAuditLog(updateAuditLog( date, info, srno, dto));
		
	}
	
	private AuditLog updateAuditLog( Date date, String info, Integer srno, AuditLogDto dto){
		AuditLog auditLog = new AuditLog();
		auditLog.setModule(dto.getModule());
		auditLog.setOperation(dto.getOperation().getValue());
		auditLog.setAuthId(dto.getAuthId());
		auditLog.setRecordId(dto.getRecordId());
		auditLog.setLogDate(date);
		auditLog.setInfo(info);
		auditLog.setSrno(srno);
		return auditLog;
	}

	@Override
	public List<AuditLogDto> getAuditLogs(AuditLogSearchDto searchDto) {
		return commonDao.getAuditLogs(searchDto);
	}

	@Override
	public MerchantDetails getMerchantDetailsByMerchantId(Long merchantId) {
		return commonDao.getMerchantDetailsByMerchantId(merchantId);
	}
}
