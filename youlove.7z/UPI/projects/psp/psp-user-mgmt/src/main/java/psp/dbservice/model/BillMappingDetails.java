package psp.dbservice.model;

public class BillMappingDetails implements java.io.Serializable {

	private static final long serialVersionUID = 1L;
	
	private Long id;
	
	private String customerName;
	
	private Long merchantId;
	
	private String merchantVirtualAddress;
	
	private String identification;
	
	private int billDate;
	
	private int notificationDate;
	
	private int expDate;
	
	private int notificationExpDate;
	
	public BillMappingDetails() {
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getCustomerName() {
		return customerName;
	}

	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}

	public Long getMerchantId() {
		return merchantId;
	}

	public void setMerchantId(Long merchantId) {
		this.merchantId = merchantId;
	}

	public String getMerchantVirtualAddress() {
		return merchantVirtualAddress;
	}

	public void setMerchantVirtualAddress(String merchantVirtualAddress) {
		this.merchantVirtualAddress = merchantVirtualAddress;
	}

	public String getIdentification() {
		return identification;
	}

	public void setIdentification(String identification) {
		this.identification = identification;
	}

	public int getBillDate() {
		return billDate;
	}

	public void setBillDate(int billDate) {
		this.billDate = billDate;
	}

	public int getNotificationDate() {
		return notificationDate;
	}

	public void setNotificationDate(int notificationDate) {
		this.notificationDate = notificationDate;
	}

	public int getExpDate() {
		return expDate;
	}

	public void setExpDate(int expDate) {
		this.expDate = expDate;
	}

	public int getNotificationExpDate() {
		return notificationExpDate;
	}

	public void setNotificationExpDate(int notificationExpDate) {
		this.notificationExpDate = notificationExpDate;
	}

}
