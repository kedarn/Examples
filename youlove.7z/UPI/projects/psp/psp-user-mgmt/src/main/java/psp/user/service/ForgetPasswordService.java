package psp.user.service;

import psp.dto.ForgetPasswordDto;

public interface ForgetPasswordService {

	ForgetPasswordDto sendSequrityQuestions(String userName);
	
	ForgetPasswordDto resendPasswordLink(String userName);
	
	ForgetPasswordDto sendPasswordLink(String userName, String question, String answer);

}
