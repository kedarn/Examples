/**
 * 
 */
package psp.user.dao.impl;

import java.util.ArrayList;
import java.util.List;

import javax.inject.Inject;

import org.springframework.orm.hibernate4.HibernateTemplate;
import org.springframework.stereotype.Component;

import psp.constants.CategoryCode;
import psp.dbservice.model.ActionItem;
import psp.dbservice.model.UserRole;
import psp.dto.ActionItemDto;
import psp.dto.RoleDto;
import psp.dto.RoleSearchDto;
import psp.user.dao.QueryConstruction;
import psp.user.dao.RoleDao;

/**
 * @author prasadj
 *
 */
@SuppressWarnings("unchecked")
@Component
public class RoleDaoImpl implements RoleDao {

	@Inject
	private HibernateTemplate hibernateTemplate;
	
	@Inject
	private QueryConstruction queryConstruction;
	
	public RoleDaoImpl(){
	}
	
	
	@Override
	public List<RoleDto> getRoles(RoleSearchDto dto) {
		String query = queryConstruction.getRoleSummarySearch(dto);
		return (List<RoleDto>) hibernateTemplate.getSessionFactory().getCurrentSession().createQuery(query).list();
	}

	@Override
	public List<UserRole> getAdminRoles() {
		return (List<UserRole>) hibernateTemplate.findByNamedQuery("getAdminRoles", CategoryCode.ADMIN.getValue());
	}
	
	@Override
	public UserRole getRole(Long roleId) {
		return hibernateTemplate.get(UserRole.class, roleId);
	}
	
	@Override
	public List<ActionItemDto> getAdminActionItems() {
		return (List<ActionItemDto>) hibernateTemplate.findByNamedQuery("getAdminActionItems", CategoryCode.ADMIN.getValue());
	}
	@Override
	public ActionItem getActionItem(Long id) {
		return hibernateTemplate.get(ActionItem.class, id);
	}
	@Override
	public UserRole addRole(UserRole role) {
		hibernateTemplate.save(role);
		return role;
	}
	
	@Override
	public UserRole updateRole(UserRole role) {
		hibernateTemplate.update(role);
		return role;
	}

	@Override
	public List<ActionItemDto> getActionItems(Integer category) {
		return (List<ActionItemDto>) hibernateTemplate.findByNamedQuery("getActionItems", category);
	}

	@Override
	public List<UserRole> getRoleByRoleName(String roleName) {
		return (List<UserRole>) hibernateTemplate.findByNamedQuery("getRoleByRoleName", roleName);
	}


	@Override
	public UserRole getMerchantRole() {
		ArrayList<UserRole> list =  (ArrayList<UserRole>) hibernateTemplate.findByNamedQuery("getRoleByCategory", CategoryCode.MERCHANT.getValue());
		return list.get(0);
	}


	@Override
	public UserRole getCustomerRole() {
		ArrayList<UserRole> list =  (ArrayList<UserRole>) hibernateTemplate.findByNamedQuery("getRoleByCategory", CategoryCode.CUSTOMER.getValue());
		return list.get(0);
	}

	
	
}