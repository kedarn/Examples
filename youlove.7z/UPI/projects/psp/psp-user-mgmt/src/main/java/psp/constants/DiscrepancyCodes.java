/**
 * 
 */
package psp.constants;


/**
 * @author hemanthk
 *
 */
public enum DiscrepancyCodes {
	
	
	TRANSACTION_ID(1,"transaction Id"),
	MID(2,"MID"),
	TXN_AMOUNT(3,"TXN_AMOUNT"),
	FEE_AMOUNT(4,"FEE_AMOUNT"),
	REFUND_AMOUNT(5,"REFUND_AMOUNT"),
	STATUS(6,"STATUS");
	
	
	
	private final int value;
	
	private final String name;
	
	private DiscrepancyCodes(int value, String name) {
		this.value = value;
		this.name = name;
	}

	public int getValue() {
		return value;
	}
	
	public String getName() {
		return name;
	}

	public static DiscrepancyCodes getStatus(int value){
		if(TRANSACTION_ID.value == value){
			return TRANSACTION_ID;
		}
		else if(MID.value == value){
			return MID;
		}
		else if(TXN_AMOUNT.value == value){
			return TXN_AMOUNT;
		}
		else if(FEE_AMOUNT.value == value){
			return FEE_AMOUNT;
		}
		else {
			return null;
		}
	}
}
