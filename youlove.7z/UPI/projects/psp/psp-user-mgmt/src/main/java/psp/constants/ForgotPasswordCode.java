/**
 * 
 */
package psp.constants;

/**
 * @author shiva
 *
 */
public enum ForgotPasswordCode {

	SUCCESS,
	WRONG_DATA,
	NEW_USER,
	BLOCKED,
	USER_NOT_EXISTS;
	
}