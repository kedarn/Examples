/**
 * 
 */
package psp.user.service;

import psp.constants.ForgotPasswordCode;
import psp.constants.NewUserPwChangeStatus;
import psp.constants.ResendNotificationCode;
import psp.dto.AuthenticationDto;
import psp.dto.LoginDto;
import psp.dto.NewUserDto;

/**
 * @author prasadj
 *
 */
public interface LoginService {

	LoginDto login(String loginId, String password, Integer categoryId);
	
	/**
	 * 
	 * @param loginId
	 * @param securityQuestion
	 * @param securityAnswer
	 * @param authId
	 * @param byAdmin
	 */
	ForgotPasswordCode forgotPassword(String loginId, Integer categoryId, Long securityQuestionId, String securityAnswer, Long authId, boolean byAdmin);
	
	ResendNotificationCode resendNotification(String loginId, Integer categoryId, Long authId);
	
	NewUserPwChangeStatus newUserPasswordChange(NewUserDto user);
	
	boolean changePassword(AuthenticationDto authenticationDto);
	
}