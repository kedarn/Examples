/**
 * 
 */
package psp.dbservice.model;

import java.io.Serializable;

/**
 * @author prasadj
 *
 */
public class SecurityQuestion implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private Long id;
	
	private String question;
	
	public SecurityQuestion(){
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getQuestion() {
		return question;
	}

	public void setQuestion(String question) {
		this.question = question;
	}

}