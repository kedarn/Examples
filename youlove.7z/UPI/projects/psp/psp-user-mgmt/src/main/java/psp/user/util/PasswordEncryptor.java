/**
 * 
 */
package psp.user.util;

import org.jasypt.util.password.ConfigurablePasswordEncryptor;

/**
 * @author hemanthk
 *
 */
public class PasswordEncryptor {

	public static final String SHA512 = "SHA-512";
	
	private PasswordEncryptor(){
	}
	
	public static String encrypt(String rawpassword) {
	    ConfigurablePasswordEncryptor encryptor = new ConfigurablePasswordEncryptor();
	    encryptor.setAlgorithm(SHA512);
	    return encryptor.encryptPassword(rawpassword);
	}

    public static boolean checkPassword(String rawpassword, String encpwd) {
        ConfigurablePasswordEncryptor encryptor = new ConfigurablePasswordEncryptor();
        encryptor.setAlgorithm(SHA512);
        return encryptor.checkPassword(rawpassword,encpwd);
    }
}
