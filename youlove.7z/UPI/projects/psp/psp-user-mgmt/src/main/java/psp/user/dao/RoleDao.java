/**
 * 
 */
package psp.user.dao;

import java.util.List;

import psp.dbservice.model.ActionItem;
import psp.dbservice.model.UserRole;
import psp.dto.ActionItemDto;
import psp.dto.RoleDto;
import psp.dto.RoleSearchDto;

/**
 * @author prasadj
 *
 */
public interface RoleDao {

	List<UserRole> getAdminRoles();
	
	UserRole getRole(Long roleId);
	
	List<ActionItemDto> getAdminActionItems();

	ActionItem getActionItem(Long id);

	UserRole addRole(UserRole role);
	
	UserRole updateRole(UserRole role);
	
	List<ActionItemDto> getActionItems(Integer category);
	
	List<UserRole> getRoleByRoleName(String roleName);
	
	List<RoleDto> getRoles(RoleSearchDto dto);
	
	UserRole getMerchantRole();
	
	UserRole getCustomerRole();
	
}