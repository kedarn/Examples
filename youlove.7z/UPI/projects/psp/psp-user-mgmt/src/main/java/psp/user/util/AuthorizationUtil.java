package psp.user.util;

import java.util.ArrayList;
import java.util.List;

import psp.constants.PspPortalConstants;
import psp.dto.ActionItemDto;
import psp.dto.AuthorizationDto;

public class AuthorizationUtil {
	private AuthorizationUtil(){
	}
	
	public static List<AuthorizationDto> getMatchingAuthList(String path, List<AuthorizationDto> list){
		List<AuthorizationDto> subList = new ArrayList<AuthorizationDto>();
		for(AuthorizationDto dto: list){
			if(path.equals(dto.getPathPrifix()) || path.startsWith(dto.getPathPrifix() + PspPortalConstants.SLASH)){
				subList.add(dto);
			}
		}
		return subList;
	}

	public static boolean verifyRoleAction(Long id, List<ActionItemDto> actions){
	
		for(ActionItemDto action: actions){
			if(id.equals(action.getId())){
				return true;
			}
		}
		return false;
	}
}
