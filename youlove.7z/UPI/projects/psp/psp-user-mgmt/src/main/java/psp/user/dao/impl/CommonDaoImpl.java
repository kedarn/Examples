/**
 * 
 */
package psp.user.dao.impl;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.inject.Inject;

import org.hibernate.Query;
import org.hibernate.Session;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.orm.hibernate4.HibernateCallback;
import org.springframework.orm.hibernate4.HibernateTemplate;
import org.springframework.stereotype.Component;

import psp.common.model.CustomerBillSummary;
import psp.common.model.TransactionSumary;
import psp.constants.AuditLogQueryFieldConstants;
import psp.constants.PortalOperations;
import psp.dbservice.model.Address;
import psp.dbservice.model.AuditLog;
import psp.dbservice.model.BillMappingDetails;
import psp.dbservice.model.CustomerDetails;
import psp.dto.AddressDto;
import psp.dto.AuditLogDto;
import psp.dto.AuditLogSearchDto;
import psp.dto.AuthorizationDto;
import psp.dto.BillpayerSearchDto;
import psp.dto.SecurityQuestionDto;
import psp.dto.TransactionSearchDto;
import psp.dto.UserSearchDto;
import psp.mobile.model.response.MerchantDetails;
import psp.user.dao.CommonDao;
import psp.user.dao.QueryConstruction;
import psp.user.util.UserManagementUtil;

/**
 * @author prasadj
 *
 */
@SuppressWarnings("unchecked")
@Component
public class CommonDaoImpl implements CommonDao, AuditLogQueryFieldConstants {

	@Autowired
	private HibernateTemplate hibernateTemplate;
	
	@Inject
	private QueryConstruction queryConstruction;

	public CommonDaoImpl(){
	}

	@Override
	public List<SecurityQuestionDto> getSecurityQuestions() {
		return (List<SecurityQuestionDto>) hibernateTemplate.findByNamedQuery("getAllSecurityQuestions");
	}

	@Override
	public Address getAddressById(Long id) {
		return hibernateTemplate.get(Address.class, id);
	}

	@Override
	public AddressDto getAddressDtoById(Long id) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void saveAddress(Address address) {
		hibernateTemplate.save(address);
	}

	@Override
	public void updateAddress(Address address) {
		hibernateTemplate.update(address);
	}

	@Override
	public String getSecurityQuestion(Long id) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<AuthorizationDto> getAuthorizationList() {
		return (List<AuthorizationDto>) hibernateTemplate.findByNamedQuery("getAuthorizationList");
	}

	@Override
	protected Object clone() throws CloneNotSupportedException {
		// TODO Auto-generated method stub
		return super.clone();
	}

	@Override
	public boolean equals(Object obj) {
		// TODO Auto-generated method stub
		return super.equals(obj);
	}

	@Override
	protected void finalize() throws Throwable {
		// TODO Auto-generated method stub
		super.finalize();
	}

	@Override
	public int hashCode() {
		// TODO Auto-generated method stub
		return super.hashCode();
	}

	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return super.toString();
	}
	
	@Override
	public Long saveBillMappingDetails(BillMappingDetails billMappingDetails) {
		return (Long) hibernateTemplate.save(billMappingDetails);
	}
	
	@Override
	public List<MerchantDetails> getCustomerAddedMerchants(UserSearchDto searchdto, String userName) {
		return  (List<MerchantDetails>) hibernateTemplate.find( queryConstruction.getCustomerAddedMerchantsearch(searchdto, userName));
	}

	@Override
	public List<MerchantDetails> getCustomerNotAddedMerchants(String userName) {
		return (List<MerchantDetails>) hibernateTemplate.findByNamedQuery("getCustomerNotAddedMerchants", userName);
	}

	@Override
	public List<CustomerBillSummary> getCustomerBillSummariesByMerchantId(Long merchantId) {
		return  (List<CustomerBillSummary>) hibernateTemplate.findByNamedQuery("getCustomerBillSummariesByMerchantId", merchantId);
	}

	@Override
	public MerchantDetails getMerchantSummaryByMerchantId(Long merchantId) {
		List<MerchantDetails> merchantsList = (List<MerchantDetails>) hibernateTemplate.findByNamedQuery("getMerchantSummaryByMerchantId", merchantId);
		MerchantDetails merchant = null;
		if(merchantsList != null && !merchantsList.isEmpty()){
			merchant = merchantsList.get(0);
		}
		return merchant;
	}

	@Override
	public BillMappingDetails getBillMappingDetailsByIdentification(String identification) {
		List<BillMappingDetails> billMappingList = (List<BillMappingDetails>) hibernateTemplate.findByNamedQuery("getBillMappingDetailsByIdentification", identification);
		BillMappingDetails billMappingDetails = null;
		if(billMappingList != null && !billMappingList.isEmpty()){
			billMappingDetails = billMappingList.get(0);
		}
		return billMappingDetails;
	}

	@Override
	public  List<CustomerBillSummary> searchBillSummarydetails(BillpayerSearchDto billpayerSearchDto){
		return  (List<CustomerBillSummary>) hibernateTemplate.find(queryConstruction.getCustomerBillSummarySearch(billpayerSearchDto));
	}
	
	@Override
	public List<TransactionSumary> searchTransactiondetails(TransactionSearchDto transactionSearchDto){
		return  (List<TransactionSumary>) hibernateTemplate.find(queryConstruction.searchTransactiondetails(transactionSearchDto));
	}
	
	@Override
	public List<CustomerDetails> getMerchantAssociatedCustomers(UserSearchDto SearchDto, Long id) {
    return  (List<CustomerDetails>) hibernateTemplate.find( queryConstruction.getMerchantAssociatedCustomersSearch(SearchDto, id) );
	}

	@Override
	public void addAuditLog(AuditLog model) {
		hibernateTemplate.save(model);		
	}

	@Override
	public List<AuditLogDto> getAuditLogs(final AuditLogSearchDto searchDto) {
		return (List<AuditLogDto>)hibernateTemplate.execute(new HibernateCallback<List<AuditLogDto>>() {
			public List<AuditLogDto> doInHibernate(Session session) {
                Query q = session.createSQLQuery(getAuditLogsQuery(searchDto));
                if( searchDto.getFromDate() != null ){
                	q.setParameter(FROM_DATE_QFLD, searchDto.getFromDate());
                }
                if( searchDto.getToDate() != null ){
                	q.setParameter(TO_DATE_QFLD, searchDto.getToDate());
                }
                if( searchDto.getModule() != null ){
                	q.setParameter(MODULE_QFLD, searchDto.getModule());
                }
                if( searchDto.getOperation() != null ){
                	q.setParameter(OPERATION_QFLD, searchDto.getOperation());
                }
                if( searchDto.getAuthenticationId() != null ){
                	q.setParameter(AUTH_ID_QFLD, searchDto.getAuthenticationId());
                }
               // q.setParameter(START_QFLD, 0);
                q.setParameter(END_QFLD, AUDIT_ROW_COUNT);
				
				List list = q.list();
                List<AuditLogDto> dtoList = new ArrayList<AuditLogDto>();
                for(Object o: list){
               	 	Object[] row = (Object[])o;
               	 	AuditLogDto da = new AuditLogDto();
               	 	da.setId(UserManagementUtil.getLong(row[0]));
               	 	da.setAuthId(UserManagementUtil.getLong(row[1]));
               	 	da.setModule((Integer)row[2]);
               	 	da.setOperation(PortalOperations.getPortalOperations((Integer)row[3]));
               	 	da.setLogDate((Date)row[4]);
               	 	da.setSrno((Integer)row[5]);
               	 	da.setInfo((String)row[6]);
                   	dtoList.add(da);
                }
                return dtoList;
			}
		});
	}
	
	private String getAuditLogsQuery(AuditLogSearchDto searchDto){
		StringBuilder sb = new StringBuilder();
		
		sb.append(" select al.ID, al.AUTH_ID, al.MODULE, al.OPERATION, ");
		sb.append(" al.LOG_DATE, al.SRNO, al.INFO from AUDIT_LOG al ");
		if( searchDto.getFromDate() != null || searchDto.getToDate() != null 
				|| searchDto.getModule() != null || searchDto.getOperation() != null || searchDto.getAuthenticationId() != null ){
			sb.append(" where ");
		}
		boolean and = false;
		if( searchDto.getFromDate() != null ){
			sb.append(" al.LOG_DATE >= :fromDate ");
			and = true;
		}
		if( searchDto.getToDate() != null ){
			if(and){
				sb.append(AND_QFLD);
			}
			sb.append(" al.LOG_DATE <= :toDate ");
			and = true;
		}
		if( searchDto.getModule() != null ){
			if(and){
				sb.append(AND_QFLD);
			}
			sb.append(" al.MODULE = :module ");
			and = true;
		}
		if( searchDto.getOperation() != null ){
			if(and){
				sb.append(AND_QFLD);
			}
			sb.append(" al.OPERATION = :operation ");
			and = true;
		}
		if( searchDto.getAuthenticationId() != null ){
			if(and){
				sb.append(AND_QFLD);
			}
			sb.append(" al.AUTH_ID = :authId ");
			and = true;
		}
		sb.append(" ORDER BY al.LOG_DATE DESC ");
		sb.append(" LIMIT :end ");
		return sb.toString();
	}

	@Override
	public MerchantDetails getMerchantDetailsByMerchantId(Long merchantId) {
		List<MerchantDetails> merchantsList = (List<MerchantDetails>) hibernateTemplate.findByNamedQuery("getMerchantDetailsByMerchantId", merchantId);
		MerchantDetails merchant = null;
		if(merchantsList != null && !merchantsList.isEmpty()){
			merchant = merchantsList.get(0);
		}
		return merchant;
	}
}
