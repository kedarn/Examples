/**
 * 
 */
package psp.user.dao;

/**
 * @author prasadj
 *
 */
public interface LoginDao {
	
}
