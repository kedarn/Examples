/**
 * 
 */
package psp.constants;


/**
 * @author prasadj
 *
 */
public enum CategoryCode {

	SUPER_ADMIN(1, "Super Admin"),
	ADMIN(2, "Employee"),
	MERCHANT(3, "Merchant"),
	CUSTOMER(4, "Customer");
	
	private final int value;
	
	private final String name;
	
	private CategoryCode(int value, String name) {
		this.value = value;
		this.name = name;
	}

	public int getValue() {
		return value;
	}
	
	public String getName(){
		return name;
	}
	
	public static CategoryCode getCateogry(int value){
		if(SUPER_ADMIN.value == value){
			return SUPER_ADMIN;
		}
		else if(ADMIN.value == value){
			return ADMIN;
		}
		else if(MERCHANT.value == value){
			return MERCHANT;
		}
		else if(CUSTOMER.value == value){
			return CUSTOMER;
		}
		else {
			return null;
		}
	}
	
}