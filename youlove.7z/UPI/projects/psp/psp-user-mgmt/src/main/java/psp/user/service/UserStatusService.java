/**
 * 
 */
package psp.user.service;

import psp.constants.CategoryCode;

public interface UserStatusService {

	void activateUser(Long id, CategoryCode category, Long authId);
	
	void suspendUser(Long id, CategoryCode category, Long authId);

	void resetUserPassword(Long id, CategoryCode category, Long authId);

	Boolean assignAdminRole(Long userId, Long roleId, Long authId);
	
	Boolean assignMerchantRole(Long userId, Long roleId, Long authId);
	

}