package psp.dto;

import java.io.Serializable;

public class ReconHistoryDto implements Serializable {

	private static final long serialVersionUID = 1L;
	
	private String bankName;
	
	private String startDate;
	
	private String reconNoOfTxns;
	
	private String expectedTxns;
	
	private String reconAmt;
	
	private String expectedAmt;
	
	private String chargeBackCount;
	
	private String chargeBackAmt;
	
	private String endDate;
	
	private Long errorCode;
	
	private String errorMsg;
	
	private String status;

	public String getStatus() {
		return status;
	}
	
	public void setStatus(String status) {
		this.status = status;
	}
	
	public Long getErrorCode() {
		return errorCode;
	}
	
	public void setErrorCode(Long errorCode) {
		this.errorCode = errorCode;
	}
	
	public String getErrorMsg() {
		return errorMsg;
	}
	
	public void setErrorMsg(String errorMsg) {
		this.errorMsg = errorMsg;
	}

	public String getBankName() {
		return bankName;
	}
	
	public void setBankName(String bankName) {
		this.bankName = bankName;
	}
	
	public String getStartDate() {
		return startDate;
	}
	
	public void setStartDate(String startDate) {
		this.startDate = startDate;
	}
	
	public String getReconNoOfTxns() {
		return reconNoOfTxns;
	}
	
	public void setReconNoOfTxns(String reconNoOfTxns) {
		this.reconNoOfTxns = reconNoOfTxns;
	}
	
	public String getExpectedTxns() {
		return expectedTxns;
	}
	
	public void setExpectedTxns(String expectedTxns) {
		this.expectedTxns = expectedTxns;
	}
	
	public String getReconAmt() {
		return reconAmt;
	}
	
	public void setReconAmt(String reconAmt) {
		this.reconAmt = reconAmt;
	}
	
	public String getExpectedAmt() {
		return expectedAmt;
	}
	
	public void setExpectedAmt(String expectedAmt) {
		this.expectedAmt = expectedAmt;
	}
	
	public String getChargeBackCount() {
		return chargeBackCount;
	}
	
	public void setChargeBackCount(String chargeBackCount) {
		this.chargeBackCount = chargeBackCount;
	}
	
	public String getChargeBackAmt() {
		return chargeBackAmt;
	}
	
	public void setChargeBackAmt(String chargeBackAmt) {
		this.chargeBackAmt = chargeBackAmt;
	}
	
	public String getEndDate() {
		return endDate;
	}
	
	public void setEndDate(String endDate) {
		this.endDate = endDate;
	}

}