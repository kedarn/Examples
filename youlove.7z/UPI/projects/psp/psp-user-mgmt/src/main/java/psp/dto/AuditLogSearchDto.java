package psp.dto;

import java.util.Date;

import psp.constants.DateUtil;

public class AuditLogSearchDto {

	private Date fromDate;
	
	private String fromDateStr;
	
	private Date toDate;
	
	private String toDateStr;
	
	private Integer module;
	
	private Integer operation;
	
	private Long authenticationId;

	public Date getFromDate() {
		return fromDate;
	}

	public void setFromDate(Date fromDate) {
		this.fromDate = fromDate;
	}
	
	public String getFromDateStr() {
		return fromDateStr;
	}

	public void setFromDateStr(String fromDateStr) {
		if(fromDateStr != null && !"".equals(fromDateStr) ) {
			this.fromDate = DateUtil.convertStringToDate(fromDateStr);
		}
		else {
			this.fromDate = null;
		}
		this.fromDateStr = fromDateStr;
	}

	public Date getToDate() {
		return toDate;
	}
	
	public void setToDate(Date toDate) {
		this.toDate = toDate;
	}

	public String getToDateStr() {
		return toDateStr;
	}

	public void setToDateStr(String toDateStr) {
		if(toDateStr != null && !"".equals(toDateStr) ) {
			this.toDate = DateUtil.convertStringToDate(toDateStr);
		}
		else {
			this.toDate = null;
		}
		this.toDateStr = toDateStr;
	}

	public Integer getModule() {
		return module;
	}

	public void setModule(Integer module) {
		this.module = module;
	}

	public Integer getOperation() {
		return operation;
	}

	public void setOperation(Integer operation) {
		this.operation = operation;
	}

	public Long getAuthenticationId() {
		return authenticationId;
	}

	public void setAuthenticationId(Long authenticationId) {
		this.authenticationId = authenticationId;
	}
}
