/**
 * 
 */
package psp.dto;

import java.io.Serializable;

/**
 * @author prasadj
 *
 */
public class SecurityQuestionDto implements Serializable {

	private static final long serialVersionUID = 1L;

	private Long id;
	
	private String question;
	
	public SecurityQuestionDto(){
	}

	public SecurityQuestionDto(Long id, String question){
		this.id = id;
		this.question = question;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getQuestion() {
		return question;
	}

	public void setQuestion(String question) {
		this.question = question;
	}
	
}