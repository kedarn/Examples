/**
 * 
 */
package psp.user.util;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.concurrent.TimeUnit;

/**
 * @author prasadj
 *
 */
public class UserDateUtil {

	private UserDateUtil(){
	}
	
	public static Date trimDate(Date date){
		return convertStringToDate(convertDateToString(date));
	}

	public static Date trimToSealingDate(Date date){
		Date oldDate = trimDate(date);
		return new Date(oldDate.getTime() + 24 * 60 * 60 * 1000 - 10);
	}

	public static String convertDateToTimeString(Date date){
		String reportDate = null;
		DateFormat df = new SimpleDateFormat("MM/dd/yyyy HH:mm:ss");
		if(date != null) {
			reportDate = df.format(date);
		}
		return reportDate;
	}

	public static String convertDateToString(Date date){
		String reportDate = null;
		DateFormat df = new SimpleDateFormat("MM/dd/yyyy");
		if(date != null) {
			reportDate = df.format(date);
		}
		return reportDate;
	}
	
	public static Date convertStringToDate(String dateStr){
	
		SimpleDateFormat formatter = new SimpleDateFormat("MM/dd/yyyy");
	 
		try {
			if(dateStr != null && !"".equals(dateStr)){
				return formatter.parse(dateStr);
			}
		} 
		catch (Exception e) {
			return null;
		}
		return null;
	}

	public static Date addDays(Date date, Integer days){
		Date newDate = null;
		if(date != null){
			try {
				Calendar cal = Calendar.getInstance();
				cal.setTime(date);
				cal.add(Calendar.DATE, days);
				newDate = cal.getTime();
			}
			catch(Exception ex){
				newDate = null;
			}
		}
		return newDate;
	}
	
	public static Date addMonth(Date date){
		return addMonths(date, 1);
	}

	public static Date addMonths(Date date, Integer months){
		Date newDate = null;
		if(date != null){
			try {
				Calendar cal = Calendar.getInstance();
				cal.setTime(date);
				cal.add(Calendar.MONTH, months);
				newDate = cal.getTime();
			}
			catch(Exception ex){
				newDate = null;
			}
		}
		return newDate;
	}

	public static Date addWeek(Date date){
		return addWeeks(date, 1);
	}

	public static Date addWeeks(Date date, Integer weeks){
		Date newDate = null;
		if(date != null){
			try {
				Calendar cal = Calendar.getInstance();
				cal.setTime(date);
				cal.add(Calendar.DATE, 7 * weeks);
				newDate = cal.getTime();
			}
			catch(Exception ex){
				newDate = null;
			}
		}
		return newDate;
	}

	public static Date convertToDateStrToDate(String dateStr){
		SimpleDateFormat formatter = new SimpleDateFormat("MM/dd/yyyy");
		try {
			if(dateStr != null && !"".equals(dateStr)){
				return addDays(formatter.parse(dateStr), 1);
			}
		} 
		catch (Exception e) {
			return null;
		}
		return null;
	}
	
	public static Date substractDays(Date d, int days){
		return new Date(d.getTime() - (long)days*1000*60*60*24 );
	}

	public static int daysBetween(Date currentDate, Date oldDate){
		if(currentDate.after(oldDate)){
			int daysBetween = 0;
			Date date1 = trimDate(currentDate);
			Date date2 = trimDate(oldDate);
			long diff = date1.getTime() - date2.getTime();
			daysBetween = (int) TimeUnit.DAYS.convert(diff, TimeUnit.MILLISECONDS);
			return daysBetween;
		}
		return 0;
	}
}