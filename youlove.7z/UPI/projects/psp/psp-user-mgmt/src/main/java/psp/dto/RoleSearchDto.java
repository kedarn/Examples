/**
 * 
 */
package psp.dto;

import java.io.Serializable;

/**
 * @author prasadj
 *
 */
public class RoleSearchDto implements Serializable {

	private static final long serialVersionUID = 1L;

	private String name;
	
	private Integer category;

	private Long currentUserRoleId;
	
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Integer getCategory() {
		return category;
	}

	public void setCategory(Integer category) {
		this.category = category;
	}

	public Long getCurrentUserRoleId() {
		return currentUserRoleId;
	}

	public void setCurrentUserRoleId(Long currentUserRoleId) {
		this.currentUserRoleId = currentUserRoleId;
	}
	
}