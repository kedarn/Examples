/**
 * 
 */
package psp.dbservice.model;

import java.io.Serializable;

/**
 * @author prasadj
 *
 */
public class Authorization implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private Long id;
	
	private Long actionId;
	
	private String pathPrifix;
	
	private Integer categoryId;

	private Authorization(){
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public Long getActionId() {
		return actionId;
	}

	public void setActionId(Long actionId) {
		this.actionId = actionId;
	}

	public String getPathPrifix() {
		return pathPrifix;
	}

	public void setPathPrifix(String pathPrifix) {
		this.pathPrifix = pathPrifix;
	}

	public Integer getCategoryId() {
		return categoryId;
	}

	public void setCategoryId(Integer categoryId) {
		this.categoryId = categoryId;
	}
	
}