package psp.user;

import java.util.List;

import junit.framework.Assert;

import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

import psp.common.exception.ApplicationException;
import psp.common.model.CustomerBillSummary;
import psp.constants.StatusCode;
import psp.db.test.AbstractServiceTest;
import psp.dbservice.model.BillMappingDetails;
import psp.dto.AuthorizationDto;
import psp.dto.BillpayerSearchDto;
import psp.dto.UserSearchDto;
import psp.mobile.model.response.MerchantDetails;
import psp.user.service.CommonService;
import psp.user.service.UserService;

public class CommonServiceTest extends AbstractServiceTest {

	@Autowired
	private CommonService commonService;
	
	@Autowired
	private UserService userService;

	@Test
	public void getAuthorizationListTest(){
		List<AuthorizationDto> authList = commonService.getAuthorizationList();
		Assert.assertNotNull(authList);
		Assert.assertEquals(1, authList.size());
		Assert.assertEquals(1002L, authList.get(0).getActionId().longValue());
		Assert.assertEquals("/rolemgmt", authList.get(0).getPathPrifix());
		Assert.assertEquals(1, authList.get(0).getCategoryId().intValue());
	}	
	
	@Test
	public void getCustomerAddedMerchantsTest(){
		List<MerchantDetails> merchants = commonService.getCustomerAddedMerchants(new UserSearchDto(), "tarang1");
		Assert.assertNotNull(merchants);
		Assert.assertEquals(1, merchants.size());
		Assert.assertEquals(201, merchants.get(0).getId().intValue());
		Assert.assertEquals("TarangMerchant", merchants.get(0).getName());
		Assert.assertEquals("tarangmer@tarang", merchants.get(0).getVirtualAddress());
	}
	
	@Test
	public void getCustomerNotAddedMerchantsTest(){
		List<MerchantDetails> merchants = commonService.getCustomerNotAddedMerchants("tarang1");
		Assert.assertNotNull(merchants);
		Assert.assertEquals(1, merchants.size());
		Assert.assertEquals(202, merchants.get(0).getId().intValue());
		Assert.assertEquals("TarangMerchant2", merchants.get(0).getName());
		Assert.assertEquals("tarangmer2@tarang", merchants.get(0).getVirtualAddress());
	}
	
	@Test
	public void getCustomerBillSummariesTest(){
		commonService.getCustomerBillSummariesByMerchantId(201l);
	}
	
	@Test
	public void changePasswordTest() throws ApplicationException {
		 try {
			boolean check =commonService.changePassword("Com@12", "Com@13", "Admin2");
			Assert.assertEquals(true,check);
			commonService.changePassword("Com@12", "Com@12", "Admin3");
		} catch (ApplicationException e) {
			System.out.println("Exception occured........");
			Assert.assertEquals(StatusCode.NEW_PASWORD_ALREADY_USED,e.getStatusCode());
		}
		 
		try { // For resetpassword test
				commonService.changePassword(null, "Com@12", "Admin3");
			} catch (ApplicationException e) {
				Assert.assertEquals(StatusCode.NEW_PASWORD_ALREADY_USED,e.getStatusCode());
			}
		boolean check3=	commonService.changePassword(null, "Com@15", "Admin3");
			Assert.assertEquals(true,check3);
		
		try { // For resetpassword test	
		boolean check4=	commonService.changePassword(null, "Com@15", "Admin3");
		Assert.assertEquals(true,check4);	
		} catch (ApplicationException e) {
				Assert.assertEquals(StatusCode.NEW_PASWORD_ALREADY_USED,e.getStatusCode());
		}
	}
	
	@Test
	public void getMerchantSummaryByMerchantIdTest() {
		MerchantDetails merchantDetailempty =commonService.getMerchantSummaryByMerchantId(109L);
		Assert.assertEquals(null, merchantDetailempty);
		MerchantDetails merchantDetail =commonService.getMerchantSummaryByMerchantId(201L);
		Assert.assertNotNull(merchantDetail);
		Assert.assertEquals("tarangmer@tarang",merchantDetail.getVirtualAddress());
	}
	
	@Test
	public void  getBillMappingDetailsByIdentificationTest(){
	BillMappingDetails billpMappingDetails =	commonService.getBillMappingDetailsByIdentification("1234569");
	Assert.assertEquals(null, billpMappingDetails);
	
	BillMappingDetails billpMappingDetails2 =	commonService.getBillMappingDetailsByIdentification("123456");
	Assert.assertNotNull(billpMappingDetails2);
	Assert.assertEquals("tarang1",billpMappingDetails2.getCustomerName());
	}
	
	@Test
	public void searchBillSummarydetails(){
		BillpayerSearchDto billpaySearchDto = new BillpayerSearchDto();
		billpaySearchDto.setName("tarang1");
		List<CustomerBillSummary> listCustomBillsummary =commonService.searchBillSummarydetails(billpaySearchDto);
		Assert.assertNotNull(listCustomBillsummary);
		
	}
	
	
	

}
