package psp.user;

import org.junit.Test;

import psp.db.test.AbstractServiceTest;
/**
 * 
 */

/**
 * @author prasadj
 *
 */
public class UserServiceTest extends AbstractServiceTest {


	@Test
	public void sampleTest(){
	}	
	
}