/**
 * 
 */
package psp.user;

import junit.framework.Assert;

import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

import psp.constants.ForgotPasswordCode;
import psp.constants.LoginCode;
import psp.constants.NewUserPwChangeStatus;
import psp.db.test.AbstractServiceTest;
import psp.dto.LoginDto;
import psp.dto.NewUserDto;
import psp.user.service.LoginService;

/**
 * @author hemanthk
 *
 */
public class LoginServiceTest extends AbstractServiceTest {

	@Autowired
	private LoginService loginService;

	@Test
	public void methodloginTest() {
		LoginDto loginDto = loginService.login("superadmin", "superadmin", 1);
		Assert.assertNotNull(loginDto);
		
		LoginDto loginDto2 = loginService.login("superadmin", "superadmin", 2);
		Assert.assertEquals(loginDto2.getLoginStatus(), LoginCode.INVALID_CATEGORY_ROLE);
		
		LoginDto loginDto3 = loginService.login("Admin2", "Com@12", 1);
		Assert.assertEquals(LoginCode.LOGIN_SUCCESS, loginDto3.getLoginStatus());
		
		LoginDto loginDto4 = loginService.login("Admin3", "Com@12", 1);
		Assert.assertEquals(LoginCode.LOCKED, loginDto4.getLoginStatus());
		/*
		LoginDto loginDto5 = loginService.login("Admin5", "Com@12", 1);
		Assert.assertEquals(loginDto3.getLoginStatus(), LoginCode.USER_NOT_EXISTS); */
		
		
		/*Assert.assertEquals(1, loginDto.getAuthId().longValue());
		Assert.assertEquals(1, loginDto.getCategory().intValue());
		Assert.assertEquals(1, loginDto.getStatus().intValue());
		Assert.assertEquals("super  admin", loginDto.getFullName());
		Assert.assertEquals(LoginCode.LOGIN_SUCCESS.name(), loginDto.getLoginStatus().name());
		Assert.assertEquals("superadmin", loginDto.getUserName());
		RoleDto role = loginDto.getRole();
		Assert.assertNotNull(role);*/
	}	
	
	@Test
	public void newUserPasswordChangeTest(){
		NewUserDto newUserDto = new NewUserDto();
		newUserDto.setUserName("Admin2");
		newUserDto.setPassword("Com@12");
		NewUserPwChangeStatus  newUserPwChangeStatus = loginService.newUserPasswordChange(newUserDto);
		Assert.assertEquals(NewUserPwChangeStatus.SUCCESS, newUserPwChangeStatus);
		
		NewUserDto newUserDto2 = new NewUserDto();
		newUserDto2.setUserName("Admindummy");
		newUserDto2.setPassword("Com@12");
		NewUserPwChangeStatus  newUserPwChangeStatus2 = loginService.newUserPasswordChange(newUserDto2);
		Assert.assertEquals(NewUserPwChangeStatus.FAILED, newUserPwChangeStatus2);
	}
	
	//@Test
	public void forgotPasswordTest(){
		ForgotPasswordCode forgotPasswordCode = loginService.forgotPassword("Admin2", 1, 1L, "answer1", 0L, false);
		Assert.assertEquals(ForgotPasswordCode.SUCCESS, forgotPasswordCode);
		
		ForgotPasswordCode forgotPasswordCode2 = loginService.forgotPassword("Admin2", 1, 2L, "answer2", 0L, false);
		Assert.assertEquals(ForgotPasswordCode.WRONG_DATA, forgotPasswordCode2);
		
		ForgotPasswordCode forgotPasswordCode3 = loginService.forgotPassword("Admin2", 2, 2L, "answer2", 0L, false);
		Assert.assertEquals(ForgotPasswordCode.USER_NOT_EXISTS, forgotPasswordCode3); 
	}

}