package psp.user.util;

import java.util.List;

import junit.framework.Assert;

import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

import psp.db.test.AbstractServiceTest;
import psp.dto.AuthorizationDto;
import psp.user.service.CommonService;
import psp.user.service.LoginService;

public class AuthorizationUtilTest extends AbstractServiceTest {
	
	@Autowired
	private CommonService commonService;
	
	@Autowired
	private LoginService loginService;
	
	@Test
	public void getMatchingAuthListTest() {
		List<AuthorizationDto> authList = commonService.getAuthorizationList();
		Assert.assertNotNull(authList);
		Assert.assertEquals(1, authList.size());
		List<AuthorizationDto> matchList = AuthorizationUtil.getMatchingAuthList("/rolemgmt", authList);
		Assert.assertNotNull(matchList);
	}

}
