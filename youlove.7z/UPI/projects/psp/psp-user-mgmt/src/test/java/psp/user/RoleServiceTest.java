package psp.user;

import java.util.List;

import junit.framework.Assert;

import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

import psp.constants.CategoryCode;
import psp.db.test.AbstractServiceTest;
import psp.dto.ActionItemDto;
import psp.dto.RoleDto;
import psp.dto.RoleSearchDto;
import psp.user.service.RoleService;

public class RoleServiceTest extends AbstractServiceTest {

	@Autowired
	private RoleService roleService;

	@Test
	public void getAdminRolesTest() {
		
		RoleSearchDto dto = new RoleSearchDto();
		dto.setCategory(CategoryCode.ADMIN.getValue());
		List<RoleDto> roleList = roleService.getRoles(dto);
		Assert.assertNotNull(roleList);
		Assert.assertEquals(1, roleList.size());
		Assert.assertEquals("Admin", roleList.get(0).getName());
		List<ActionItemDto> actionItemsList = roleService.getAdminActionItems();
		Assert.assertNotNull(actionItemsList);
		Assert.assertEquals(4, actionItemsList.size());
	}
	
	@Test
	public void getRoleTest() {
		RoleDto role = roleService.getRole(1L);
		Assert.assertNotNull(role);
		Assert.assertEquals("SuperAdmin", role.getName());
	}

}
