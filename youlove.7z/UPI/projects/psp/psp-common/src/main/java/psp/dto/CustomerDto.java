/**
 * 
 */
package psp.dto;

import java.util.Date;

/**
 * @author prasadj
 *
 */
public class CustomerDto {

	private Long id;
	
	private Date dateOfBirth;
	
	private String mobileNumber;
	
	private String email;
	
	private String aadhaarNumber;
	
	private String userName;
	
	private String fullName;
	
	private String password;
	
	private String firstName;
	
	private String lastName;
	
	private String middleName;
	
	private Date createdDate;
	
	private String rnsMpaId;
	
	private Long authId;

	private DeviceDto deviceDto;
	
	public CustomerDto(){
	}

	public CustomerDto (Long id, String userName, String fullName, String email, String mobileNumber){
		this.id = id;
		this.userName = userName;
		this.fullName = fullName;
		this.email = email;
		this.mobileNumber = mobileNumber;
	}
	
	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public Date getDateOfBirth() {
		return dateOfBirth;
	}

	public void setDateOfBirth(Date dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}

	public String getMobileNumber() {
		return mobileNumber;
	}

	public void setMobileNumber(String mobileNumber) {
		this.mobileNumber = mobileNumber;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getAadhaarNumber() {
		return aadhaarNumber;
	}

	public void setAadhaarNumber(String aadhaarNumber) {
		this.aadhaarNumber = aadhaarNumber;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getFullName() {
		return fullName;
	}

	public void setFullName(String fullName) {
		this.fullName = fullName;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getMiddleName() {
		return middleName;
	}

	public void setMiddleName(String middleName) {
		this.middleName = middleName;
	}

	public Date getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}

	public String getRnsMpaId() {
		return rnsMpaId;
	}

	public void setRnsMpaId(String rnsMpaId) {
		this.rnsMpaId = rnsMpaId;
	}

	public Long getAuthId() {
		return authId;
	}

	public void setAuthId(Long authId) {
		this.authId = authId;
	}

	public DeviceDto getDeviceDto() {
		return deviceDto;
	}

	public void setDeviceDto(DeviceDto deviceDto) {
		this.deviceDto = deviceDto;
	}
	
}