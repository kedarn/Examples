package psp.constants;

public interface AuditLogConstants {

	  String EMPLOYEE_CREATION = "New Employee {0} created";
	  
	  String EMPLOYEE_UPDATE = "Employee {0} updated\n";
	  
	  String MERCHANT_CREATION = "New Merchant {0} created";
	  
	  String MERCHANT_UPDATE = "Merchant {0} updated\n";
	  
	  String USER_LOGIN = "User last login {0}";

	  String USER_LOGOUT = "User logged out at {0}";
}
