/**
 * 
 */
package psp.constants;

/**
 * @author kathubandam
 *
 */
public enum ResendNotificationCode {

	SUCCESS,
	WRONG_USER,
	BLOCKED_USER,
	ALREADY_ACTIVE,
	FAILED;
}
