/**
 * 
 */
package psp.constants;

/**
 * @author manasp
 *
 */
public interface PspPortalConstants {

	String SLASH = "/";
	
	String UPI = "upi";
	
	String PORTAL = "portal";
	
	String ADMIN = "admin";
	
	String MERCHANT = "merchant";
	
	String CUSTOMER = "customer";
	
	String EMPLOYEE = "employee";
	
	String AUTHORIZATION_LIST = "authorizationList";
	
	String DATE_FORMAT = "MM/dd/yyyy";
	
	Integer DEFAULT_ATTEMPTS = 0;
	
	Integer MAX_PWD_ATTEMPTS = 3;
	
	String TIME_FORMAT = "MM/dd/yyyy HH:mm:ss";
	
	String SEMI_COLON_STR = ";";
	
	String SPACE = " ";
	
	String NEWLINE_CHAR = "\n";
	
	String COLON_STR = ":";
	
}
