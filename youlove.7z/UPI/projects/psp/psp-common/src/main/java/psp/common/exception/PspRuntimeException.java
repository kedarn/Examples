/**
 * 
 */
package psp.common.exception;

import psp.constants.StatusCode;

/**
 * @author prasadj
 *
 */
public class PspRuntimeException extends RuntimeException {

	private static final long serialVersionUID = 1L;
	
	private final StatusCode statusCode;
	
	public PspRuntimeException(StatusCode statusCode) {
		super(statusCode.getMessage());	
		this.statusCode = statusCode;
	}

	public PspRuntimeException(StatusCode statusCode, Exception ex) {
		super(statusCode.getMessage(), ex);	
		this.statusCode = statusCode;
	}

	public StatusCode getStatusCode() {
		return statusCode;
	}	
	
}