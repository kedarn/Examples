package psp.dto;

import java.util.List;

public class ForgetPasswordDto {

	private String message;
	
	private List<String> securityQuestions;
	
	public ForgetPasswordDto() {
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public List<String> getSecurityQuestions() {
		return securityQuestions;
	}

	public void setSecurityQuestions(List<String> securityQuestions) {
		this.securityQuestions = securityQuestions;
	}
	
}
