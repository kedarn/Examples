/**
 * 
 */
package psp.constants;

/**
 * @author hemanthk
 *
 */
public enum AuthStatusCode {
	
	NEW_USER(1, "New"),
	ACTIVE(2, "Active"),
	LOCKED(3,"Locked"),
	RESET(4, "Reset");

	
	private final int value;
	
	private final String name;
	
	private AuthStatusCode(int value, String name) {
		this.value = value;
		this.name = name;
	}

	public int getValue() {
		return value;
	}
	
	public String getName() {
		return name;
	}

	public static AuthStatusCode getStatus(int value){
		if(NEW_USER.value == value){
			return NEW_USER;
		}
		else if(ACTIVE.value == value){
			return ACTIVE;
		}
		else if(RESET.value == value){
			return RESET;
		}
		else if(LOCKED.value==value) { 
			return LOCKED;
		}
		else{
			return null;
		}
	}
}


