package psp.constants;

public enum PortalOperations {

	CREATE(1, "Create"),
	UPDATE(2, "Update"),
	STATUS_CAHNGE(3, "Status Change"),
	LOGIN_LOGOUT(4, "Login/Logout");
	
	private final int value;

	private final String name;

	private PortalOperations(int value, String name) {
		this.value = value;
		this.name = name;
	}

	public int getValue() {
		return value;
	}

	public String getName() {
		return name;
	}

	public static PortalOperations getPortalOperations(int value) {
		if (CREATE.value == value) {
			return CREATE;
		} else if (UPDATE.value == value) {
			return UPDATE;
		} else if (STATUS_CAHNGE.value == value) {
			return STATUS_CAHNGE;
		} else if (LOGIN_LOGOUT.value == value) {
			return LOGIN_LOGOUT;
		} else {
			return null;
		}
	}
}
