/**
 * 
 */
package psp.constants;

/**
 * @author prasadj
 *
 */
public interface PropertyName {

	String BANK_PROVIDERS_NUMBER = "bank.providers.number";
	
	String LOGIN_EXPIRY_DURATION = "login.expiry.duration";
	
	String MOBILE_PROCESS_DELAY =	"mobile.process.delay";
	
	String ORG_ID = "psp.server.orgId";
	
	String SELF_REFERENCE_URL = "self.reference.url";
	
	String AUTH_KEY = "gcm.authKey";
	
	String TIME_TO_LIVE = "gcm.timetolive";
	
	String SIGNER_FILE_PATH = "signer.file.path";
	
	String CERTIFIATE_FILE_PATH = "certificate.file.path";
	
	String CHANGE_PWD_BASE_URL = "change.password.base.url";
	
	String MAX_DELAY_INTERVAL = "max.delay.interval";
	
	String LOCAL_OTP_EXP_TIME = "local.otp.exp.time";

	String APPLICATION_BASE_VERSION = "application.base.version";
	
	String APPLICATION_CURRENT_VERSION = "application.current.version";
	
	String JRXML_PATH = "jrxml.path";

	String USER_AUTOUNLOCK_HOURS ="user.autounlock.hours";
	
}