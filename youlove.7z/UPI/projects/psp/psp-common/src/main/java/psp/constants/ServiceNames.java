package psp.constants;

public interface ServiceNames {

	String REQ_AUTH_DETAILS = "ReqAuthDetails";
	
	String REQ_BAL_ENQ = "ReqBalEnq";
	
	String REQ_CHK_TXN = "ReqChkTxn";
	
	String REQ_HBT = "ReqHbt";
	
	String REQ_LIST_ACCOUNT = "ReqListAccount";
	
	String REQ_LIST_ACC_PVD = "ReqListAccPvd";
	
	String REQ_LIST_KEYS = "ReqListKeys";
	
	String REQ_LIST_PSP = "ReqListPsp";
	
	String REQ_LIST_VAE = "ReqListVae";
	
	String REQ_MANAGE_VAE = "ReqManageVae";
	
	String REQ_OTP = "ReqOtp";
	
	String REQ_PAY = "ReqPay";
	
	String REQ_PENDING_MSG = "ReqPendingMsg";
	
	String REQ_REG_MOB = "ReqRegMob";
	
	String REQ_SET_CRE = "ReqSetCre";
	
	String REQ_TXN_CONFIRMATION = "ReqTxnConfirmation";
	
	String REQ_VAL_ADD = "ReqValAdd";
	
	
	String RESP_AUTH_DETAILS = "RespAuthDetails";
	
	String RESP_BAL_ENQ = "RespBalEnq";
	
	String RESP_CHK_TXN = "RespChkTxn";
	
	String RESP_HBT = "RespHbt";
	
	String RESP_LIST_ACCOUNT = "RespListAccount";

	String RESP_LIST_ACC_PVD = "RespListAccPvd";
	
	String RESP_LIST_KEYS = "RespListKeys";
	
	String RESP_LIST_PSP = "RespListPsp";
	
	String RESP_LIST_VAE = "RespListVae";
	
	String RESP_MANAGE_VAE = "RespManageVae";
	
	String RESP_OTP = "RespOtp";
	
	String RESP_PAY = "RespPay";
	
	String RESP_PENDING_MSG = "RespPendingMsg";
	
	String RESP_REG_MOB = "RespRegMob";

	String RESP_SET_CRE = "RespSetCre";
	
	String RESP_TXN_CONFIRMATION = "RespTxnConfirmation";
	
	String RESP_VAL_ADD = "RespValAdd";
	
}