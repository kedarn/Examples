package psp.common;


/**
 * @author prasadj
 *
 */
public interface PropertyReader {

	void load(); 
	
	String getValue(String propKey);
	
	int getBankProvidersNumber();
	
	int getLoginExpiryDuration();
	
	int getMobileProcessDelay();
	
	String getSignerFilePath();
	
	String getCertificateFilePath();
	
	String getOrgId();
	
	String getReferenceUrl();
	
	String getAuthKey();
	
	int getTimeToLive();
	
	String getChangePwdUrl();
	
	int getMaxDelayInterval();
	
	int getLocalOtpExpTime();
	
	String getAppBaseVersion();
	
	String getAppCurrentVersion();
	
	String getJrxmlDefaultLocation();

}