/**
 * 
 */
package psp.dto;

import java.io.Serializable;
import java.util.Date;

/**
 * @author prasadj
 *
 */
public class TransactionSearchDto implements Serializable {

	private static final long serialVersionUID = 1L;
	   
	private String status; 
	
	private String transaction_id;
	
	private Date transactionFromDate;
	
	private Date transactionToDate;
	
	private String transactionFromDateStr;
	
	private String transactionToDateStr;
	
	private String merchantVirtualAddress;
	
	private String transactionType;
	
	private String bankName;
	
	private String customerVirtualAddress;
	
	
	
	public TransactionSearchDto(){
	}


	public String getStatus() {
		return status;
	}


	public void setStatus(String status) {
		this.status = status;
	}


	public String getTransaction_id() {
		return transaction_id;
	}


	public void setTransaction_id(String transaction_id) {
		this.transaction_id = transaction_id;
	}


	public Date getTransactionFromDate() {
		return transactionFromDate;
	}


	public void setTransactionFromDate(Date transactionFromDate) {
		this.transactionFromDate = transactionFromDate;
	}


	public Date getTransactionToDate() {
		return transactionToDate;
	}


	public void setTransactionToDate(Date transactionToDate) {
		this.transactionToDate = transactionToDate;
	}


	public String getTransactionFromDateStr() {
		return transactionFromDateStr;
	}


	public void setTransactionFromDateStr(String transactionFromDateStr) {
		this.transactionFromDateStr = transactionFromDateStr;
	}


	public String getTransactionToDateStr() {
		return transactionToDateStr;
	}


	public void setTransactionToDateStr(String transactionToDateStr) {
		this.transactionToDateStr = transactionToDateStr;
	}


	public static long getSerialversionuid() {
		return serialVersionUID;
	}


	public String getMerchantVirtualAddress() {
		return merchantVirtualAddress;
	}


	public void setMerchantVirtualAddress(String merchantVirtualAddress) {
		this.merchantVirtualAddress = merchantVirtualAddress;
	}


	public String getTransactionType() {
		return transactionType;
	}


	public void setTransactionType(String transactionType) {
		this.transactionType = transactionType;
	}


	public String getBankName() {
		return bankName;
	}


	public void setBankName(String bankName) {
		this.bankName = bankName;
	}


	public String getCustomerVirtualAddress() {
		return customerVirtualAddress;
	}


	public void setCustomerVirtualAddress(String customerVirtualAddress) {
		this.customerVirtualAddress = customerVirtualAddress;
	}



}