package psp.constants;

public enum NotificationType {

	COLLECT,
	TXN;
}
