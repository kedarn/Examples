/**
 * 
 */
package psp.constants;

/**
 * @author prasadj
 *
 */
public interface ReportsConstants {

	String sample = "sample";
	
}