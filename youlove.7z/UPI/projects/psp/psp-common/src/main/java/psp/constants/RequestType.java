package psp.constants;

public enum RequestType {

	COLLECT;
}
