package psp.constants;

public interface QueryFieldConstants {

	String FROM_DATE_QFLD = "fromDate";

	String TO_DATE_QFLD = "toDate";
	
	String MODULE_QFLD = "module";
	
	String OPERATION_QFLD = "operation";

	String AUTH_ID_QFLD = "authId";
	
	String START_QFLD = "start";
	
	String END_QFLD = "end";
	
	String AND_QFLD = " and ";
	
	Integer AUDIT_ROW_COUNT = 50;
	
	String TRANSACTION_ID ="transactionId";
	
	String TRANSACTION_STATUS="tranStatus";
	
	String MERCHANT_VIRTUALADDRESS="merchantVirtualAdress";
	
	String CUSTOMER_VIRTUALADDRESS="customerVirtualAdress";
	
}
