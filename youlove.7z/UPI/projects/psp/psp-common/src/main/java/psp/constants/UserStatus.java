/**
 * 
 */
package psp.constants;

/**
 * @author prasadj
 *
 */
public enum UserStatus {

	ACTIVE(1, "Active"),
	SUSPEND(2, "Suspend"),
	DELETE(3, "Delete");
	
	private final int value;
	
	private final String name;
	
	private UserStatus(int value, String name) {
		this.value = value;
		this.name = name;
	}

	public int getValue() {
		return value;
	}
	
	public String getName() {
		return name;
	}
	
	public static UserStatus getUserStatus(Integer us){
		if (ACTIVE.value == us){
			return ACTIVE;
		}
		else if (DELETE.value == us){
			return DELETE;
		}
		else if (SUSPEND.value == us){
			return SUSPEND;
		}
		else {
			return null;
		}
	}
	
	
	
}