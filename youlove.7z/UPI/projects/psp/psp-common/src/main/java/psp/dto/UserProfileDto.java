/**
 * 
 */
package psp.dto;

import java.util.Date;

import psp.constants.UserStatus;

/**
 * @author hemanthk
 *
 */
public class UserProfileDto {
	
	private Long id;
	
	private String loginName;
		
	private String email;
	
	private String phoneNumber;
			
    private String firstName;
	
	private String middleName;
	
	private String lastName;
	
   	private Date dateOfBirth;
	
	private String line1;
	
	private String line2;

	private String districtName;
	
	private String stateName;
	
	private String countryName;
	
	private String pincode;
		
	private String altPhoneNumber;
		
	private String dateOfBirthStr;
	
	private String aadhaarNumber;
	
	private Integer userStatus;
	
	private String userStatusStr;
	
	private Integer pwdStatus;
	
	private String pwdStatusStr;
	
	private String name;
	
	private Long authId;
	
	private Date establishDate;
	
	private String establishDateStr;
	
	private Long addressId;
	
	private Date registrationDate;
	
	private String roleName;
	
	private Integer category;
	
	private String categoryStr;
	
	private Long createdby;
	
	private String password;
	
	private String rnsMpaId;
	
	private DeviceDto deviceDto;

	private Long userID;
	
	public UserProfileDto() {
	}
	
	public UserProfileDto(Long id, String loginName, String name, String email, String phoneNumber, Integer userStatus) {
		this.id = id;
		this.loginName = loginName;
		this.name = name;
		this.email = email;
		this.phoneNumber = phoneNumber;
		this.userStatus = userStatus;
		if(this.userStatus != null){
			this.userStatusStr = UserStatus.getUserStatus(this.userStatus).getName();
		}
		
	}
	
	public UserProfileDto(Long id, String loginName, String name, String email, String phoneNumber, Integer userStatus, Long authId) {
		this.id = id;
		this.authId = authId;
		this.loginName = loginName;
		this.name = name;
		this.email = email;
		this.phoneNumber = phoneNumber;
		this.userStatus = userStatus;
		if(this.userStatus != null){
			this.userStatusStr = UserStatus.getUserStatus(this.userStatus).getName();
		}
				
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public Integer getPwdStatus() {
		return pwdStatus;
	}

	public void setPwdStatus(Integer pwdStatus) {
		this.pwdStatus = pwdStatus;
	}

	public String getPwdStatusStr() {
		return pwdStatusStr;
	}

	public void setPwdStatusStr(String pwdStatusStr) {
		this.pwdStatusStr = pwdStatusStr;
	}

	public String getLoginName() {
		return loginName;
	}

	public void setLoginName(String loginName) {
		this.loginName = loginName;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getPhoneNumber() {
		return phoneNumber;
	}

	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getMiddleName() {
		return middleName;
	}

	public void setMiddleName(String middleName) {
		this.middleName = middleName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public Date getDateOfBirth() {
		return dateOfBirth;
	}

	public void setDateOfBirth(Date dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}

	public String getLine1() {
		return line1;
	}

	public void setLine1(String line1) {
		this.line1 = line1;
	}

	public String getLine2() {
		return line2;
	}

	public void setLine2(String line2) {
		this.line2 = line2;
	}

	public String getDistrictName() {
		return districtName;
	}

	public void setDistrictName(String districtName) {
		this.districtName = districtName;
	}

	public String getStateName() {
		return stateName;
	}

	public void setStateName(String stateName) {
		this.stateName = stateName;
	}

	public String getCountryName() {
		return countryName;
	}

	public void setCountryName(String countryName) {
		this.countryName = countryName;
	}

	public String getPincode() {
		return pincode;
	}

	public void setPincode(String pincode) {
		this.pincode = pincode;
	}

	public String getAltPhoneNumber() {
		return altPhoneNumber;
	}

	public void setAltPhoneNumber(String altPhoneNumber) {
		this.altPhoneNumber = altPhoneNumber;
	}

	public String getDateOfBirthStr() {
		return dateOfBirthStr;
	}

	public void setDateOfBirthStr(String dateOfBirthStr) {
		this.dateOfBirthStr = dateOfBirthStr;
	}

	public String getAadhaarNumber() {
		return aadhaarNumber;
	}

	public void setAadhaarNumber(String aadhaarNumber) {
		this.aadhaarNumber = aadhaarNumber;
	}
	
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Long getAuthId() {
		return authId;
	}

	public void setAuthId(Long authId) {
		this.authId = authId;
	}

	public Date getEstablishDate() {
		return establishDate;
	}

	public void setEstablishDate(Date establishDate) {
		this.establishDate = establishDate;
	}

	public String getEstablishDateStr() {
		return establishDateStr;
	}

	public void setEstablishDateStr(String establishDateStr) {
		this.establishDateStr = establishDateStr;
	}

	public Long getAddressId() {
		return addressId;
	}

	public void setAddressId(Long addressId) {
		this.addressId = addressId;
	}

	public Date getRegistrationDate() {
		return registrationDate;
	}

	public void setRegistrationDate(Date registrationDate) {
		this.registrationDate = registrationDate;
	}

	public String getRoleName() {
		return roleName;
	}

	public void setRoleName(String roleName) {
		this.roleName = roleName;
	}

	public Integer getCategory() {
		return category;
	}

	public void setCategory(Integer category) {
		this.category = category;
	}

	public String getCategoryStr() {
		return categoryStr;
	}

	public void setCategoryStr(String categoryStr) {
		this.categoryStr = categoryStr;
	}

	public Long getCreatedby() {
		return createdby;
	}

	public void setCreatedby(Long createdby) {
		this.createdby = createdby;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getRnsMpaId() {
		return rnsMpaId;
	}

	public void setRnsMpaId(String rnsMpaId) {
		this.rnsMpaId = rnsMpaId;
	}

	public DeviceDto getDeviceDto() {
		return deviceDto;
	}

	public void setDeviceDto(DeviceDto deviceDto) {
		this.deviceDto = deviceDto;
	}

	public Long getUserID() {
		return userID;
	}

	public void setUserID(Long userID) {
		this.userID = userID;
	}

	public Integer getUserStatus() {
		return userStatus;
	}

	public void setUserStatus(Integer userStatus) {
		this.userStatus = userStatus;
	}

	public String getUserStatusStr() {
		return userStatusStr;
	}

	public void setUserStatusStr(String userStatusStr) {
		this.userStatusStr = userStatusStr;
	}
	
}