/**
 * 
 */
package psp.constants;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

import javax.xml.bind.DatatypeConverter;

/**
 * @author prasadj
 *
 */
public class DateUtil {

	private DateUtil(){
	}
	
	public static String getUpiDateStrFormat(Date date){
		SimpleDateFormat sdf = new SimpleDateFormat(CommonConstants.UPI_XML_DATE_FORMAT);
		return sdf.format(date);
	}
	
	public static Date getUpiDateStrFormat(String dateString){
		Calendar cal = DatatypeConverter.parseDateTime(dateString);
		return cal.getTime();
	}
	
	public static String convertDateToString(Date date){
		String reportDate = null;
		DateFormat df = new SimpleDateFormat(PspPortalConstants.DATE_FORMAT);
		if(date != null) {
			reportDate = df.format(date);
		}
		return reportDate;
	}
	
	public static Date convertStringToDate(String dateStr){
		
		SimpleDateFormat formatter = new SimpleDateFormat(PspPortalConstants.DATE_FORMAT);
	 
		try {
			if(dateStr != null && !"".equals(dateStr)){
				return formatter.parse(dateStr);
			}
		} 
		catch (Exception e) {
			return null;
		}
		return null;
	}
	
	public static String convertDateToTimeString(Date date){
		String reportDate = null;
		DateFormat df = new SimpleDateFormat(PspPortalConstants.TIME_FORMAT);
		if(date != null) {
			reportDate = df.format(date);
		}
		return reportDate;
	}
	
}