/**
 * 
 */
package psp.dto;


/**
 * @author prasadj
 *
 */
public class AuthenticationDto {

	private Long id;
	
	private String userName;
	
	private Integer pwAttempts;
	
	private Integer pwdStatus;
	
	private Integer category;
	
	private String newUserCode;
	
	private String password;
	
	private Long questionId;
	
	private String answer;
	
	private Long roleId;
	
	private String captchaStr;
	
	private Integer userStatus;
	
	public AuthenticationDto(){
	
	}

	public AuthenticationDto(Long id, Integer pwAttempts, String userName, String newUserCode, Integer pwdStatus, Integer userStatus, Integer category, Long questionId, String answer,
								String password, Long roleId){
		this.id = id;
		this.pwAttempts = pwAttempts;
		this.userName = userName;
		this.pwdStatus = pwdStatus;
		this.userStatus = userStatus;
		this.category = category;
		this.newUserCode = newUserCode;
		this.questionId = questionId;
		this.answer = answer;
		this.password = password;
		this.roleId = roleId;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public Integer getPwAttempts() {
		return pwAttempts;
	}

	public void setPwAttempts(Integer pwAttempts) {
		this.pwAttempts = pwAttempts;
	}

	public Integer getCategory() {
		return category;
	}

	public void setCategory(Integer category) {
		this.category = category;
	}

	public void setCategoryId(Integer category) {
		this.category = category;
	}

	public String getNewUserCode() {
		return newUserCode;
	}

	public void setNewUserCode(String newUserCode) {
		this.newUserCode = newUserCode;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public Long getQuestionId() {
		return questionId;
	}

	public void setQuestionId(Long questionId) {
		this.questionId = questionId;
	}

	public String getAnswer() {
		return answer;
	}

	public void setAnswer(String answer) {
		this.answer = answer;
	}

	public Long getRoleId() {
		return roleId;
	}

	public void setRoleId(Long roleId) {
		this.roleId = roleId;
	}

	/**
	 * @return the captchaStr
	 */
	public String getCaptchaStr() {
		return captchaStr;
	}

	/**
	 * @param captchaStr the captchaStr to set
	 */
	public void setCaptchaStr(String captchaStr) {
		this.captchaStr = captchaStr;
	}

	public Integer getPwdStatus() {
		return pwdStatus;
	}

	public void setPwdStatus(Integer pwdStatus) {
		this.pwdStatus = pwdStatus;
	}

	public Integer getUserStatus() {
		return userStatus;
	}

	public void setUserStatus(Integer userStatus) {
		this.userStatus = userStatus;
	}

}