package psp.constants;

public enum PortalModule {

	CUSTOMER_MANAGEMNET(1, "Customer Management"),
	MERCHANT_MANAGEMNET(2, "Merchant Management"),
	EMPLOYEE_MANAGEMNET(3, "Employee Management"),
	ROLE_MANAGEMNET(4, "Role Management"),
	COMMON_SETTINGS(5, "Common User Settings");
	
	private final int value;

	private final String name;

	private PortalModule(int value, String name) {
		this.value = value;
		this.name = name;
	}

	public int getValue() {
		return value;
	}

	public String getName() {
		return name;
	}

	public static PortalModule getPortalModule(int value) {
		
		if (CUSTOMER_MANAGEMNET.value == value) {
			return CUSTOMER_MANAGEMNET;
		} else if (ROLE_MANAGEMNET.value == value) {
			return ROLE_MANAGEMNET;
		} else if (MERCHANT_MANAGEMNET.value == value) {
			return MERCHANT_MANAGEMNET;
		} else if(EMPLOYEE_MANAGEMNET.value == value){
			return EMPLOYEE_MANAGEMNET;
		} else if(COMMON_SETTINGS.value == value){
			return COMMON_SETTINGS;
		} else {
			return null;
		}
	}
}
